# 📱 ANDROID BUILD INSTRUCTIONS

## 🎯 3 CARA INSTALL DI ANDROID

---

## ✅ CARA 1: PWA (PALING MUDAH) - NO CODING!

### Step-by-step:

1. **Deploy ke Vercel (GRATIS):**
```bash
npm install -g vercel
vercel login
vercel --prod
```

2. **Buka di Android Chrome:**
   - Visit: `https://your-app.vercel.app`
   - Chrome auto-detect PWA

3. **Install PWA:**
   - Tap 3-dot menu
   - Tap "Add to Home Screen"
   - App icon muncul di home screen
   - Buka seperti native app!

**DONE! 5 menit selesai!**

---

## 🚀 CARA 2: CAPACITOR (NATIVE ANDROID)

Sudah gua setup! Tinggal build.

### Prerequisites:

1. **Install Android Studio:**
   - Download: https://developer.android.com/studio
   - Install semua components
   - Setup Android SDK

2. **Install Java JDK 17:**
   - Download: https://adoptium.net/
   - Set JAVA_HOME environment variable

### Build Steps:

```bash
# 1. Build web app dulu
npm run build

# 2. Sync ke Android
npx cap sync android

# 3. Open di Android Studio
npx cap open android
```

### Di Android Studio:

1. Wait for Gradle sync (5-10 menit pertama kali)
2. Pilih device:
   - **Emulator:** Create AVD (Android Virtual Device)
   - **Real Device:** Enable USB debugging
3. Click **Run** (▶️ button)
4. App install & run!

### Build APK untuk distribusi:

```bash
# Di Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

# APK location:
android/app/build/outputs/apk/debug/app-debug.apk
```

**Transfer APK ke HP & install!**

---

## 🔧 CARA 3: EXPO (ALTERNATIVE)

Kalau mau yang lebih simple tapi perlu rewrite dikit:

### Setup Expo:

```bash
# 1. Install Expo CLI
npm install -g expo-cli

# 2. Create new Expo project
expo init instagram-automation-mobile
cd instagram-automation-mobile

# 3. Copy src code
# Copy semua dari src/ ke project baru
# Adjust imports (React Native components)

# 4. Run on device
expo start
# Scan QR code dengan Expo Go app
```

**Pros:**
- ✅ Easy development
- ✅ Hot reload
- ✅ Test on device instantly

**Cons:**
- ❌ Perlu rewrite UI ke React Native
- ❌ Lumayan effort

---

## 📲 CARA INSTALL APK DI HP

### Option A: USB Cable

```bash
# 1. Enable USB debugging di HP
Settings > About Phone > Tap "Build Number" 7x
Settings > Developer Options > USB Debugging ON

# 2. Connect HP ke PC
# 3. Copy APK ke HP
adb install app-debug.apk

# 4. Open app!
```

### Option B: Share APK

```bash
# 1. Copy APK dari:
android/app/build/outputs/apk/debug/app-debug.apk

# 2. Upload ke Google Drive / Dropbox
# 3. Download di HP
# 4. Install (Allow "Install from Unknown Sources")
```

---

## 🎮 CARA RUN DI EMULATOR

### Setup Android Emulator:

1. **Open Android Studio**
2. **Tools > Device Manager**
3. **Create Virtual Device:**
   - Phone: Pixel 6
   - System Image: Android 13 (API 33)
   - AVD Name: Pixel_6_API_33
4. **Start Emulator**
5. **Run app:**
```bash
npx cap run android
```

### Emulator Controls:

- **Power:** Power button on side panel
- **Volume:** Volume buttons
- **Rotate:** Ctrl+Left/Right Arrow
- **Home:** Home button
- **Back:** Back button
- **Recent Apps:** Recent apps button

---

## 🔥 RECOMMENDED: PWA vs NATIVE

### Pilih PWA kalau:
- ✅ Mau cepat (5 menit)
- ✅ No Android Studio
- ✅ No coding changes
- ✅ Auto-update
- ✅ Works di semua platform (iOS juga!)

### Pilih Native kalau:
- ✅ Mau publish ke Play Store
- ✅ Butuh offline mode
- ✅ Butuh native features (camera, GPS, dll)
- ✅ Better performance
- ✅ Professional app

---

## 💡 QUICK START (TERCEPAT)

**5 menit setup:**

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Deploy
vercel --prod

# 3. Buka link di Android Chrome
# 4. "Add to Home Screen"
# 5. DONE!
```

**No Android Studio needed!**
**No Java needed!**
**No APK build needed!**

---

## 🐛 TROUBLESHOOTING

### Build failed?

```bash
# Clean & rebuild
cd android
./gradlew clean
cd ..
npm run build
npx cap sync android
```

### Gradle error?

```bash
# Check Java version
java -version
# Should be 17.x

# Set JAVA_HOME
export JAVA_HOME=/path/to/jdk-17
```

### App won't run?

```bash
# Check Android device
adb devices

# Check logs
adb logcat | grep Capacitor
```

### Build too slow?

```bash
# Enable Gradle daemon
echo "org.gradle.daemon=true" >> android/gradle.properties
echo "org.gradle.parallel=true" >> android/gradle.properties
```

---

## 📦 BUILD COMMANDS REFERENCE

```bash
# Build web app
npm run build

# Sync to Android
npx cap sync android

# Open in Android Studio
npx cap open android

# Run on device/emulator
npx cap run android

# Build APK (in Android Studio)
Build > Build APK

# Live reload (development)
npx cap run android -l --external
```

---

## 🎯 NEXT STEPS

### After installing:

1. **Test semua features**
2. **Check performance**
3. **Fix any issues**
4. **Build release APK**
5. **Publish ke Play Store** (optional)

### Release Build:

```bash
# Di Android Studio:
Build > Generate Signed Bundle / APK
Select APK
Create new keystore
Fill details
Build release APK

# Location:
android/app/build/outputs/apk/release/app-release.apk
```

---

## 💰 PUBLISH KE PLAY STORE (OPTIONAL)

1. **Create Developer Account:**
   - Pay $25 one-time fee
   - https://play.google.com/console

2. **Prepare Assets:**
   - App icon (512x512)
   - Screenshots (5+ images)
   - Feature graphic (1024x500)
   - Description

3. **Upload APK:**
   - Create new app
   - Upload release APK
   - Fill store listing
   - Set pricing (Free/Paid)
   - Submit for review

4. **Wait 3-7 days:**
   - Google review
   - Approve/Reject
   - Live on Play Store!

---

## 🔐 IMPORTANT NOTES

### Security:

- **NEVER commit `.env` file**
- **Use environment variables**
- **Protect Supabase keys**
- **Enable RLS policies**

### Performance:

- **Optimize images**
- **Lazy load components**
- **Cache API calls**
- **Minimize bundle size**

### Testing:

- **Test on multiple devices**
- **Test different Android versions**
- **Test offline mode**
- **Test slow connections**

---

## 🆘 NEED HELP?

Kalau stuck:

1. Check error logs
2. Google the error
3. Check Capacitor docs: https://capacitorjs.com
4. Ask di Discord/Stack Overflow
5. Debug step by step

**Good luck building bro! 🚀**
