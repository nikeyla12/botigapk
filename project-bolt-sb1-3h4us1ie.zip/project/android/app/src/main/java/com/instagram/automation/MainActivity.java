package com.instagram.automation;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
