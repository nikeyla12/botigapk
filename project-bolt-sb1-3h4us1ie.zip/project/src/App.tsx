import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { Accounts } from './pages/Accounts';
import { Settings } from './pages/Settings';
import { StoryViewer } from './pages/StoryViewer';
import { AutoLiker } from './pages/AutoLiker';
import { AutoCommenter } from './pages/AutoCommenter';
import { AutoFollow } from './pages/AutoFollow';
import { AutoUnfollow } from './pages/AutoUnfollow';
import { DMAutomation } from './pages/DMAutomation';
import { ContentScheduler } from './pages/ContentScheduler';
import { HashtagAnalyzer } from './pages/HashtagAnalyzer';
import { CompetitorAnalysis } from './pages/CompetitorAnalysis';
import { LeadCollection } from './pages/LeadCollection';
import { Clients } from './pages/Clients';
import { Analytics } from './pages/Analytics';
import { ProtectedRoute } from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/accounts" element={<ProtectedRoute><Accounts /></ProtectedRoute>} />
          <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
          <Route path="/story-viewer" element={<ProtectedRoute><StoryViewer /></ProtectedRoute>} />
          <Route path="/auto-liker" element={<ProtectedRoute><AutoLiker /></ProtectedRoute>} />
          <Route path="/auto-commenter" element={<ProtectedRoute><AutoCommenter /></ProtectedRoute>} />
          <Route path="/auto-follow" element={<ProtectedRoute><AutoFollow /></ProtectedRoute>} />
          <Route path="/auto-unfollow" element={<ProtectedRoute><AutoUnfollow /></ProtectedRoute>} />
          <Route path="/dm-automation" element={<ProtectedRoute><DMAutomation /></ProtectedRoute>} />
          <Route path="/content-scheduler" element={<ProtectedRoute><ContentScheduler /></ProtectedRoute>} />
          <Route path="/hashtag-analyzer" element={<ProtectedRoute><HashtagAnalyzer /></ProtectedRoute>} />
          <Route path="/competitor-analysis" element={<ProtectedRoute><CompetitorAnalysis /></ProtectedRoute>} />
          <Route path="/lead-collection" element={<ProtectedRoute><LeadCollection /></ProtectedRoute>} />
          <Route path="/clients" element={<ProtectedRoute><Clients /></ProtectedRoute>} />
          <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
          <Route path="/" element={<Navigate to="/dashboard" />} />
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
