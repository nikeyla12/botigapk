export interface DeviceFingerprint {
  device_id: string;
  user_agent: string;
  device_type: 'ios' | 'android';
  device_model: string;
  os_version: string;
  app_version: string;
  screen_resolution: string;
  timezone: string;
  language: string;
  battery_level?: number;
  is_charging?: boolean;
  network_type?: string;
  imei?: string;
  serial_number?: string;
  mac_address?: string;
  android_id?: string;
  build_id?: string;
  hardware?: string;
  manufacturer?: string;
  brand?: string;
  cpu_abi?: string;
  density_dpi?: number;
  bootloader?: string;
  board?: string;
  device_name?: string;
  fingerprint?: string;
  host?: string;
  product?: string;
  tags?: string;
  type?: string;
  radio_version?: string;
  carrier?: string;
  mcc?: string;
  mnc?: string;
  gsf_id?: string;
  advertising_id?: string;
  bluetooth_mac?: string;
  wifi_mac?: string;
  sim_serial?: string;
  sim_operator?: string;
}

interface DeviceTemplate {
  brand: string;
  model: string;
  os_min: string;
  os_max: string;
  screen_width: number;
  screen_height: number;
  released_year: number;
  hardware?: string;
  cpu?: string;
  gpu?: string;
  ram?: string;
}

const IOS_DEVICES: DeviceTemplate[] = [
  { brand: 'Apple', model: 'iPhone 16 Pro Max', os_min: '18.0', os_max: '18.2', screen_width: 1320, screen_height: 2868, released_year: 2024, hardware: 'iPhone17,2', cpu: 'A18 Pro', gpu: 'Apple GPU', ram: '8GB' },
  { brand: 'Apple', model: 'iPhone 16 Pro', os_min: '18.0', os_max: '18.2', screen_width: 1206, screen_height: 2622, released_year: 2024, hardware: 'iPhone17,1', cpu: 'A18 Pro', gpu: 'Apple GPU', ram: '8GB' },
  { brand: 'Apple', model: 'iPhone 16 Plus', os_min: '18.0', os_max: '18.2', screen_width: 1290, screen_height: 2796, released_year: 2024, hardware: 'iPhone16,2', cpu: 'A18', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 16', os_min: '18.0', os_max: '18.2', screen_width: 1179, screen_height: 2556, released_year: 2024, hardware: 'iPhone16,1', cpu: 'A18', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 15 Pro Max', os_min: '17.0', os_max: '18.2', screen_width: 1290, screen_height: 2796, released_year: 2023, hardware: 'iPhone15,5', cpu: 'A17 Pro', gpu: 'Apple GPU', ram: '8GB' },
  { brand: 'Apple', model: 'iPhone 15 Pro', os_min: '17.0', os_max: '18.2', screen_width: 1179, screen_height: 2556, released_year: 2023, hardware: 'iPhone15,4', cpu: 'A17 Pro', gpu: 'Apple GPU', ram: '8GB' },
  { brand: 'Apple', model: 'iPhone 15 Plus', os_min: '17.0', os_max: '18.2', screen_width: 1290, screen_height: 2796, released_year: 2023, hardware: 'iPhone15,3', cpu: 'A16 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 15', os_min: '17.0', os_max: '18.2', screen_width: 1179, screen_height: 2556, released_year: 2023, hardware: 'iPhone15,2', cpu: 'A16 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 14 Pro Max', os_min: '16.0', os_max: '18.2', screen_width: 1290, screen_height: 2796, released_year: 2022, hardware: 'iPhone15,3', cpu: 'A16 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 14 Pro', os_min: '16.0', os_max: '18.2', screen_width: 1179, screen_height: 2556, released_year: 2022, hardware: 'iPhone15,2', cpu: 'A16 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 14 Plus', os_min: '16.0', os_max: '18.2', screen_width: 1284, screen_height: 2778, released_year: 2022, hardware: 'iPhone14,8', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 14', os_min: '16.0', os_max: '18.2', screen_width: 1170, screen_height: 2532, released_year: 2022, hardware: 'iPhone14,7', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 13 Pro Max', os_min: '15.0', os_max: '17.7', screen_width: 1284, screen_height: 2778, released_year: 2021, hardware: 'iPhone14,3', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 13 Pro', os_min: '15.0', os_max: '17.7', screen_width: 1170, screen_height: 2532, released_year: 2021, hardware: 'iPhone14,2', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 13', os_min: '15.0', os_max: '17.7', screen_width: 1170, screen_height: 2532, released_year: 2021, hardware: 'iPhone14,5', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 13 mini', os_min: '15.0', os_max: '17.7', screen_width: 1080, screen_height: 2340, released_year: 2021, hardware: 'iPhone14,4', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 12 Pro Max', os_min: '14.0', os_max: '17.7', screen_width: 1284, screen_height: 2778, released_year: 2020, hardware: 'iPhone13,4', cpu: 'A14 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 12 Pro', os_min: '14.0', os_max: '17.7', screen_width: 1170, screen_height: 2532, released_year: 2020, hardware: 'iPhone13,3', cpu: 'A14 Bionic', gpu: 'Apple GPU', ram: '6GB' },
  { brand: 'Apple', model: 'iPhone 12', os_min: '14.0', os_max: '17.7', screen_width: 1170, screen_height: 2532, released_year: 2020, hardware: 'iPhone13,2', cpu: 'A14 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 12 mini', os_min: '14.0', os_max: '17.7', screen_width: 1080, screen_height: 2340, released_year: 2020, hardware: 'iPhone13,1', cpu: 'A14 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone SE (3rd gen)', os_min: '15.0', os_max: '17.7', screen_width: 750, screen_height: 1334, released_year: 2022, hardware: 'iPhone14,6', cpu: 'A15 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 11 Pro Max', os_min: '13.0', os_max: '16.7', screen_width: 1242, screen_height: 2688, released_year: 2019, hardware: 'iPhone12,5', cpu: 'A13 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 11 Pro', os_min: '13.0', os_max: '16.7', screen_width: 1125, screen_height: 2436, released_year: 2019, hardware: 'iPhone12,3', cpu: 'A13 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone 11', os_min: '13.0', os_max: '16.7', screen_width: 828, screen_height: 1792, released_year: 2019, hardware: 'iPhone12,1', cpu: 'A13 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone XS Max', os_min: '12.0', os_max: '16.7', screen_width: 1242, screen_height: 2688, released_year: 2018, hardware: 'iPhone11,6', cpu: 'A12 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone XS', os_min: '12.0', os_max: '16.7', screen_width: 1125, screen_height: 2436, released_year: 2018, hardware: 'iPhone11,2', cpu: 'A12 Bionic', gpu: 'Apple GPU', ram: '4GB' },
  { brand: 'Apple', model: 'iPhone XR', os_min: '12.0', os_max: '16.7', screen_width: 828, screen_height: 1792, released_year: 2018, hardware: 'iPhone11,8', cpu: 'A12 Bionic', gpu: 'Apple GPU', ram: '3GB' },
  { brand: 'Apple', model: 'iPhone X', os_min: '11.0', os_max: '16.7', screen_width: 1125, screen_height: 2436, released_year: 2017, hardware: 'iPhone10,6', cpu: 'A11 Bionic', gpu: 'Apple GPU', ram: '3GB' },
];

const ANDROID_DEVICES: DeviceTemplate[] = [
  { brand: 'Samsung', model: 'Galaxy S24 Ultra', os_min: '14.0', os_max: '15.0', screen_width: 1440, screen_height: 3120, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy S24+', os_min: '14.0', os_max: '15.0', screen_width: 1440, screen_height: 3120, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy S24', os_min: '14.0', os_max: '15.0', screen_width: 1080, screen_height: 2340, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S23 Ultra', os_min: '13.0', os_max: '15.0', screen_width: 1440, screen_height: 3088, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy S23+', os_min: '13.0', os_max: '15.0', screen_width: 1080, screen_height: 2340, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S23', os_min: '13.0', os_max: '15.0', screen_width: 1080, screen_height: 2340, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S22 Ultra', os_min: '12.0', os_max: '14.0', screen_width: 1440, screen_height: 3088, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy S22+', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2340, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 1', gpu: 'Adreno 730', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S22', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2340, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 1', gpu: 'Adreno 730', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S21 Ultra', os_min: '11.0', os_max: '14.0', screen_width: 1440, screen_height: 3200, released_year: 2021, hardware: 'qcom', cpu: 'Snapdragon 888', gpu: 'Adreno 660', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy S21+', os_min: '11.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2021, hardware: 'qcom', cpu: 'Snapdragon 888', gpu: 'Adreno 660', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy S21', os_min: '11.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2021, hardware: 'qcom', cpu: 'Snapdragon 888', gpu: 'Adreno 660', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy Z Fold5', os_min: '13.0', os_max: '15.0', screen_width: 1812, screen_height: 2176, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy Z Flip5', os_min: '13.0', os_max: '15.0', screen_width: 1080, screen_height: 2640, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy Z Fold4', os_min: '12.0', os_max: '14.0', screen_width: 1812, screen_height: 2176, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Samsung', model: 'Galaxy Z Flip4', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2640, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy A54', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2340, released_year: 2023, hardware: 'qcom', cpu: 'Exynos 1380', gpu: 'Mali-G68', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy A34', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2340, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 1080', gpu: 'Mali-G68', ram: '8GB' },
  { brand: 'Samsung', model: 'Galaxy A14', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2408, released_year: 2023, hardware: 'qcom', cpu: 'Exynos 850', gpu: 'Mali-G52', ram: '4GB' },
  { brand: 'Google', model: 'Pixel 8 Pro', os_min: '14.0', os_max: '15.0', screen_width: 1344, screen_height: 2992, released_year: 2023, hardware: 'google', cpu: 'Tensor G3', gpu: 'Mali-G715', ram: '12GB' },
  { brand: 'Google', model: 'Pixel 8', os_min: '14.0', os_max: '15.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'google', cpu: 'Tensor G3', gpu: 'Mali-G715', ram: '8GB' },
  { brand: 'Google', model: 'Pixel 7 Pro', os_min: '13.0', os_max: '15.0', screen_width: 1440, screen_height: 3120, released_year: 2022, hardware: 'google', cpu: 'Tensor G2', gpu: 'Mali-G710', ram: '12GB' },
  { brand: 'Google', model: 'Pixel 7', os_min: '13.0', os_max: '15.0', screen_width: 1080, screen_height: 2400, released_year: 2022, hardware: 'google', cpu: 'Tensor G2', gpu: 'Mali-G710', ram: '8GB' },
  { brand: 'Google', model: 'Pixel 6 Pro', os_min: '12.0', os_max: '14.0', screen_width: 1440, screen_height: 3120, released_year: 2021, hardware: 'google', cpu: 'Tensor', gpu: 'Mali-G78', ram: '12GB' },
  { brand: 'Google', model: 'Pixel 6', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2021, hardware: 'google', cpu: 'Tensor', gpu: 'Mali-G78', ram: '8GB' },
  { brand: 'Google', model: 'Pixel 6a', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2022, hardware: 'google', cpu: 'Tensor', gpu: 'Mali-G78', ram: '6GB' },
  { brand: 'Xiaomi', model: '14 Pro', os_min: '14.0', os_max: '15.0', screen_width: 1440, screen_height: 3200, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'Xiaomi', model: '14', os_min: '14.0', os_max: '15.0', screen_width: 1200, screen_height: 2670, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '12GB' },
  { brand: 'Xiaomi', model: '13T Pro', os_min: '13.0', os_max: '14.0', screen_width: 1220, screen_height: 2712, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 9200+', gpu: 'Mali-G715', ram: '12GB' },
  { brand: 'Xiaomi', model: '13 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1440, screen_height: 3200, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Xiaomi', model: '13', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '8GB' },
  { brand: 'Xiaomi', model: '12T Pro', os_min: '12.0', os_max: '14.0', screen_width: 1220, screen_height: 2712, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Xiaomi', model: 'Redmi Note 13 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 7s Gen 2', gpu: 'Adreno 710', ram: '8GB' },
  { brand: 'Xiaomi', model: 'Poco F5 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1440, screen_height: 3200, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Xiaomi', model: 'Poco X6 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1220, screen_height: 2712, released_year: 2024, hardware: 'qcom', cpu: 'Dimensity 8300', gpu: 'Mali-G615', ram: '12GB' },
  { brand: 'OnePlus', model: '12', os_min: '14.0', os_max: '15.0', screen_width: 1440, screen_height: 3168, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'OnePlus', model: '11', os_min: '13.0', os_max: '14.0', screen_width: 1440, screen_height: 3216, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '16GB' },
  { brand: 'OnePlus', model: '10 Pro', os_min: '12.0', os_max: '14.0', screen_width: 1440, screen_height: 3216, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'OnePlus', model: '10T', os_min: '12.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '16GB' },
  { brand: 'OnePlus', model: 'Nord 3', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 9000', gpu: 'Mali-G710', ram: '12GB' },
  { brand: 'OnePlus', model: 'Nord CE 3', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 782G', gpu: 'Adreno 642L', ram: '8GB' },
  { brand: 'Oppo', model: 'Find X7 Ultra', os_min: '14.0', os_max: '15.0', screen_width: 1440, screen_height: 3168, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'Oppo', model: 'Find X6 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1440, screen_height: 3216, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '16GB' },
  { brand: 'Oppo', model: 'Reno11 Pro', os_min: '14.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2024, hardware: 'qcom', cpu: 'Dimensity 8200', gpu: 'Mali-G610', ram: '12GB' },
  { brand: 'Oppo', model: 'Reno10 Pro+', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Oppo', model: 'A78', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 700', gpu: 'Mali-G57', ram: '8GB' },
  { brand: 'Vivo', model: 'X100 Pro', os_min: '14.0', os_max: '15.0', screen_width: 1260, screen_height: 2800, released_year: 2024, hardware: 'qcom', cpu: 'Dimensity 9300', gpu: 'Immortalis-G720', ram: '16GB' },
  { brand: 'Vivo', model: 'X90 Pro+', os_min: '13.0', os_max: '14.0', screen_width: 1440, screen_height: 3200, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Vivo', model: 'V29 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 8200', gpu: 'Mali-G610', ram: '12GB' },
  { brand: 'Vivo', model: 'V27 Pro', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 8200', gpu: 'Mali-G610', ram: '8GB' },
  { brand: 'Vivo', model: 'Y100', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 685', gpu: 'Adreno 610', ram: '8GB' },
  { brand: 'Realme', model: 'GT 5 Pro', os_min: '14.0', os_max: '14.0', screen_width: 1240, screen_height: 2772, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'Realme', model: 'GT Neo6', os_min: '14.0', os_max: '14.0', screen_width: 1240, screen_height: 2772, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8s Gen 3', gpu: 'Adreno 735', ram: '12GB' },
  { brand: 'Realme', model: '12 Pro+', os_min: '14.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 7s Gen 2', gpu: 'Adreno 710', ram: '12GB' },
  { brand: 'Realme', model: '11 Pro+', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2023, hardware: 'qcom', cpu: 'Dimensity 7050', gpu: 'Mali-G68', ram: '12GB' },
  { brand: 'Realme', model: 'C55', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Helio G88', gpu: 'Mali-G52', ram: '6GB' },
  { brand: 'Motorola', model: 'Edge 50 Ultra', os_min: '14.0', os_max: '14.0', screen_width: 1220, screen_height: 2712, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8s Gen 3', gpu: 'Adreno 735', ram: '16GB' },
  { brand: 'Motorola', model: 'Edge 40 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Motorola', model: 'Edge 30 Ultra', os_min: '12.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2022, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Motorola', model: 'G84', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 695', gpu: 'Adreno 619', ram: '12GB' },
  { brand: 'Asus', model: 'ROG Phone 8 Pro', os_min: '14.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '24GB' },
  { brand: 'Asus', model: 'ROG Phone 7 Ultimate', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2448, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '16GB' },
  { brand: 'Asus', model: 'Zenfone 11 Ultra', os_min: '14.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'Asus', model: 'Zenfone 10', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '16GB' },
  { brand: 'Sony', model: 'Xperia 1 VI', os_min: '14.0', os_max: '14.0', screen_width: 1644, screen_height: 3840, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '12GB' },
  { brand: 'Sony', model: 'Xperia 5 V', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2520, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '8GB' },
  { brand: 'Sony', model: 'Xperia 1 V', os_min: '13.0', os_max: '14.0', screen_width: 1644, screen_height: 3840, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 2', gpu: 'Adreno 740', ram: '12GB' },
  { brand: 'Sony', model: 'Xperia 10 V', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2520, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 695', gpu: 'Adreno 619', ram: '6GB' },
  { brand: 'Nothing', model: 'Phone (2)', os_min: '13.0', os_max: '14.0', screen_width: 1080, screen_height: 2412, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Nothing', model: 'Phone (2a)', os_min: '14.0', os_max: '14.0', screen_width: 1080, screen_height: 2400, released_year: 2024, hardware: 'qcom', cpu: 'Dimensity 7200 Pro', gpu: 'Mali-G610', ram: '12GB' },
  { brand: 'Honor', model: 'Magic6 Pro', os_min: '14.0', os_max: '14.0', screen_width: 1280, screen_height: 2800, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 8 Gen 3', gpu: 'Adreno 750', ram: '16GB' },
  { brand: 'Honor', model: '90 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1200, screen_height: 2664, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Honor', model: 'X9b', os_min: '13.0', os_max: '13.0', screen_width: 1080, screen_height: 2412, released_year: 2024, hardware: 'qcom', cpu: 'Snapdragon 6 Gen 1', gpu: 'Adreno 710', ram: '12GB' },
  { brand: 'Huawei', model: 'Pura 70 Ultra', os_min: '14.0', os_max: '14.0', screen_width: 1260, screen_height: 2844, released_year: 2024, hardware: 'kirin', cpu: 'Kirin 9010', gpu: 'Maleoon 910', ram: '16GB' },
  { brand: 'Huawei', model: 'Mate 60 Pro+', os_min: '14.0', os_max: '14.0', screen_width: 1260, screen_height: 2720, released_year: 2023, hardware: 'kirin', cpu: 'Kirin 9000s', gpu: 'Maleoon 910', ram: '16GB' },
  { brand: 'Huawei', model: 'P60 Pro', os_min: '13.0', os_max: '14.0', screen_width: 1220, screen_height: 2700, released_year: 2023, hardware: 'qcom', cpu: 'Snapdragon 8+ Gen 1', gpu: 'Adreno 730', ram: '12GB' },
  { brand: 'Huawei', model: 'Nova 12 Pro', os_min: '14.0', os_max: '14.0', screen_width: 1084, screen_height: 2776, released_year: 2024, hardware: 'kirin', cpu: 'Kirin 8000', gpu: 'Mali-G610', ram: '12GB' },
];

const TIMEZONES = [
  'Asia/Jakarta', 'Asia/Singapore', 'Asia/Bangkok', 'Asia/Manila', 'Asia/Kuala_Lumpur',
  'Asia/Ho_Chi_Minh', 'Asia/Hong_Kong', 'Asia/Seoul', 'Asia/Tokyo', 'Asia/Taipei',
  'Asia/Dubai', 'Asia/Karachi', 'Asia/Kolkata', 'Asia/Dhaka', 'Asia/Shanghai',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Madrid', 'Europe/Rome',
  'Europe/Amsterdam', 'Europe/Brussels', 'Europe/Vienna', 'Europe/Warsaw', 'Europe/Stockholm',
  'America/New_York', 'America/Los_Angeles', 'America/Chicago', 'America/Denver', 'America/Phoenix',
  'America/Toronto', 'America/Vancouver', 'America/Mexico_City', 'America/Sao_Paulo', 'America/Buenos_Aires',
  'Australia/Sydney', 'Australia/Melbourne', 'Australia/Brisbane', 'Australia/Perth', 'Pacific/Auckland',
];

const LANGUAGES = [
  'en-US', 'en-GB', 'id-ID', 'ms-MY', 'th-TH', 'vi-VN', 'zh-CN', 'zh-TW', 'ja-JP', 'ko-KR',
  'es-ES', 'es-MX', 'pt-BR', 'pt-PT', 'fr-FR', 'de-DE', 'it-IT', 'ru-RU', 'ar-SA', 'hi-IN',
  'tr-TR', 'pl-PL', 'nl-NL', 'sv-SE', 'no-NO', 'da-DK', 'fi-FI', 'el-GR', 'cs-CZ', 'hu-HU',
];

const CARRIERS = [
  'T-Mobile', 'AT&T', 'Verizon', 'Sprint', 'Vodafone', 'Orange', 'Telefonica', 'China Mobile',
  'China Unicom', 'China Telecom', 'NTT Docomo', 'KDDI', 'SoftBank', 'SK Telecom', 'KT',
  'Telkomsel', 'Indosat', 'XL Axiata', 'Smartfren', 'Three', 'Singtel', 'StarHub', 'M1',
  'AIS', 'DTAC', 'TrueMove', 'Globe', 'Smart', 'Celcom', 'Maxis', 'Digi', 'Airtel', 'Jio',
];

function random(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomItem<T>(array: T[]): T {
  return array[random(0, array.length - 1)];
}

function generateIMEI(): string {
  const tac = random(35000000, 35999999).toString();
  const serialNum = random(100000, 999999).toString();
  const imei = tac + serialNum;

  let sum = 0;
  for (let i = 0; i < 14; i++) {
    let digit = parseInt(imei[i]);
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }

  const checkDigit = (10 - (sum % 10)) % 10;
  return imei + checkDigit;
}

function generateSerialNumber(brand: string): string {
  if (brand === 'Apple') {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    return Array.from({ length: 12 }, () => chars[random(0, chars.length - 1)]).join('');
  } else {
    return Array.from({ length: 16 }, () =>
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[random(0, 35)]
    ).join('');
  }
}

function generateMacAddress(): string {
  return Array.from({ length: 6 }, () =>
    random(0, 255).toString(16).padStart(2, '0')
  ).join(':');
}

function generateAndroidId(): string {
  return Array.from({ length: 16 }, () =>
    random(0, 15).toString(16)
  ).join('');
}

function generateBuildId(osVersion: string): string {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const majorVersion = osVersion.split('.')[0];
  const buildLetter = letters[parseInt(majorVersion) - 1] || 'T';
  const buildNumber = random(10000, 99999);
  return `${buildLetter}P${random(1, 9)}A.${buildNumber}.${random(100, 999)}`;
}

function generateBootloader(brand: string): string {
  if (brand === 'Samsung') {
    return `${random(1, 9)}${random(100000, 999999)}`;
  } else if (brand === 'Google') {
    return `google-${random(10000, 99999)}-${random(100, 999)}`;
  } else {
    return `unknown-${random(10000, 99999)}`;
  }
}

function generateFingerprint(brand: string, model: string, osVersion: string, buildId: string): string {
  const brandLower = brand.toLowerCase().replace(/\s/g, '');
  const modelCode = model.toLowerCase().replace(/\s/g, '_').replace(/[()]/g, '');
  const timestamp = Date.now() - random(0, 365 * 24 * 60 * 60 * 1000);
  const buildDate = new Date(timestamp).toISOString().split('T')[0].replace(/-/g, '');

  return `${brandLower}/${modelCode}/${modelCode}:${osVersion}/${buildId}/${buildDate}:user/release-keys`;
}

function generateGSFId(): string {
  return Array.from({ length: 16 }, () =>
    random(0, 15).toString(16)
  ).join('');
}

function generateAdvertisingId(): string {
  return `${Array.from({ length: 8 }, () => random(0, 15).toString(16)).join('')}-` +
         `${Array.from({ length: 4 }, () => random(0, 15).toString(16)).join('')}-` +
         `${Array.from({ length: 4 }, () => random(0, 15).toString(16)).join('')}-` +
         `${Array.from({ length: 4 }, () => random(0, 15).toString(16)).join('')}-` +
         `${Array.from({ length: 12 }, () => random(0, 15).toString(16)).join('')}`;
}

function generateSimSerial(): string {
  return '8901' + Array.from({ length: 16 }, () => random(0, 9)).join('');
}

function getCarrierCodes(carrier: string): { mcc: string; mnc: string } {
  const carrierMap: Record<string, { mcc: string; mnc: string }> = {
    'Telkomsel': { mcc: '510', mnc: '10' },
    'Indosat': { mcc: '510', mnc: '01' },
    'XL Axiata': { mcc: '510', mnc: '11' },
    'T-Mobile': { mcc: '310', mnc: '260' },
    'AT&T': { mcc: '310', mnc: '410' },
    'Verizon': { mcc: '311', mnc: '480' },
    'Vodafone': { mcc: '234', mnc: '15' },
    'Orange': { mcc: '208', mnc: '01' },
    'China Mobile': { mcc: '460', mnc: '00' },
    'NTT Docomo': { mcc: '440', mnc: '10' },
    'SK Telecom': { mcc: '450', mnc: '05' },
  };

  return carrierMap[carrier] || { mcc: '310', mnc: '260' };
}

function generateDeviceHardware(hardware: string, brand: string): string {
  if (brand === 'Samsung') {
    return `exynos${random(2100, 2400)}` || `qcom`;
  } else if (brand === 'Google') {
    return `google_tensor`;
  } else {
    return hardware || `qcom`;
  }
}

function generateOSVersion(minVersion: string, maxVersion: string): string {
  const [minMajor, minMinor] = minVersion.split('.').map(Number);
  const [maxMajor, maxMinor] = maxVersion.split('.').map(Number);

  const major = random(minMajor, maxMajor);
  const minor = major === maxMajor ? random(0, maxMinor) : random(0, 9);
  const patch = random(0, 9);

  return `${major}.${minor}.${patch}`;
}

function generateInstagramVersion(deviceType: 'ios' | 'android'): string {
  if (deviceType === 'ios') {
    const baseVersion = random(310, 332);
    const minor = random(0, 9);
    const patch = random(0, 50);
    const build = random(100, 200);
    return `${baseVersion}.${minor}.${patch}.${baseVersion}.${build}`;
  } else {
    const baseVersion = random(310, 332);
    const minor = random(0, 9);
    const patch = random(0, 50);
    const build = random(100, 200);
    return `${baseVersion}.${minor}.${patch}.${baseVersion}.${build}`;
  }
}

export function createDeviceFingerprint(
  existingDeviceId?: string,
  preferredType?: 'ios' | 'android'
): DeviceFingerprint {
  const deviceType = preferredType || (Math.random() > 0.5 ? 'ios' : 'android');
  const devices = deviceType === 'ios' ? IOS_DEVICES : ANDROID_DEVICES;
  const device = randomItem(devices);

  const osVersion = generateOSVersion(device.os_min, device.os_max);
  const appVersion = generateInstagramVersion(deviceType);
  const timezone = randomItem(TIMEZONES);
  const language = randomItem(LANGUAGES);
  const carrier = randomItem(CARRIERS);
  const carrierCodes = getCarrierCodes(carrier);

  const deviceId = existingDeviceId || `${Date.now()}-${random(100000, 999999)}`;

  const userAgent = deviceType === 'ios'
    ? `Instagram ${appVersion} (${device.hardware}; ${device.brand} ${device.model}; iOS ${osVersion}; ${language.split('-')[0]}_${language.split('-')[1]}; ${device.screen_width}x${device.screen_height}; ${carrier})`
    : `Instagram ${appVersion} Android (${osVersion.split('.')[0]}/${osVersion}; ${random(320, 640)}dpi; ${device.screen_width}x${device.screen_height}; ${device.brand}; ${device.model}; ${device.model.toLowerCase().replace(/\s/g, '_')}; ${device.hardware}; ${language.split('-')[0]}_${language.split('-')[1]}; ${random(400000000, 600000000)})`;

  const fingerprint: DeviceFingerprint = {
    device_id: deviceId,
    user_agent: userAgent,
    device_type: deviceType,
    device_model: `${device.brand} ${device.model}`,
    os_version: osVersion,
    app_version: appVersion,
    screen_resolution: `${device.screen_width}x${device.screen_height}`,
    timezone,
    language,
    battery_level: random(20, 95),
    is_charging: Math.random() > 0.7,
    network_type: randomItem(['wifi', '4g', '5g', 'lte']),
    imei: generateIMEI(),
    serial_number: generateSerialNumber(device.brand),
    mac_address: generateMacAddress(),
    bluetooth_mac: generateMacAddress(),
    wifi_mac: generateMacAddress(),
    carrier,
    mcc: carrierCodes.mcc,
    mnc: carrierCodes.mnc,
  };

  if (deviceType === 'android') {
    const androidId = generateAndroidId();
    const buildId = generateBuildId(osVersion);
    const hardwareType = generateDeviceHardware(device.hardware!, device.brand);

    fingerprint.android_id = androidId;
    fingerprint.build_id = buildId;
    fingerprint.hardware = hardwareType;
    fingerprint.manufacturer = device.brand;
    fingerprint.brand = device.brand;
    fingerprint.cpu_abi = randomItem(['arm64-v8a', 'armeabi-v7a', 'x86_64']);
    fingerprint.density_dpi = random(320, 640);
    fingerprint.bootloader = generateBootloader(device.brand);
    fingerprint.board = device.model.toLowerCase().replace(/\s/g, '_');
    fingerprint.device_name = device.model.toLowerCase().replace(/\s/g, '_');
    fingerprint.fingerprint = generateFingerprint(device.brand, device.model, osVersion, buildId);
    fingerprint.host = `${device.brand.toLowerCase()}-build-${random(1, 999)}`;
    fingerprint.product = device.model.toLowerCase().replace(/\s/g, '_');
    fingerprint.tags = 'release-keys';
    fingerprint.type = 'user';
    fingerprint.radio_version = `${random(1, 9)}.${random(10, 99)}.${random(100, 999)}`;
    fingerprint.gsf_id = generateGSFId();
    fingerprint.advertising_id = generateAdvertisingId();
    fingerprint.sim_serial = generateSimSerial();
    fingerprint.sim_operator = carrier;
  }

  return fingerprint;
}

export function getDeviceInfo(device: DeviceFingerprint): string {
  if (device.device_type === 'ios') {
    return `${device.device_model} • iOS ${device.os_version} • v${device.app_version.split('.').slice(0, 3).join('.')}`;
  } else {
    return `${device.device_model} • ANDROID ${device.os_version} • v${device.app_version.split('.').slice(0, 3).join('.')}`;
  }
}

export function getDeviceStats(): { ios: number; android: number; total: number } {
  return {
    ios: IOS_DEVICES.length,
    android: ANDROID_DEVICES.length,
    total: IOS_DEVICES.length + ANDROID_DEVICES.length,
  };
}

export type { DeviceFingerprint };
