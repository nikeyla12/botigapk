interface PersonalizationData {
  username: string;
  fullName?: string;
  accountUsername?: string;
  followerCount?: number;
  niche?: string;
  customFields?: Record<string, string>;
}

export function personalizeDM(template: string, data: PersonalizationData): string {
  let message = template;

  message = message.replace(/\[username\]/gi, `@${data.username}`);

  if (data.fullName) {
    message = message.replace(/\[name\]/gi, data.fullName);
    message = message.replace(/\[firstname\]/gi, data.fullName.split(' ')[0]);
  } else {
    message = message.replace(/\[name\]/gi, data.username);
    message = message.replace(/\[firstname\]/gi, data.username);
  }

  if (data.accountUsername) {
    message = message.replace(/\[account\]/gi, `@${data.accountUsername}`);
  }

  if (data.followerCount !== undefined) {
    message = message.replace(/\[followers\]/gi, data.followerCount.toLocaleString());
  }

  if (data.niche) {
    message = message.replace(/\[niche\]/gi, data.niche);
  }

  if (data.customFields) {
    Object.entries(data.customFields).forEach(([key, value]) => {
      const pattern = new RegExp(`\\[${key}\\]`, 'gi');
      message = message.replace(pattern, value);
    });
  }

  return message.trim();
}

export const welcomeTemplates = [
  "Hey [username]! 👋 Thanks for following [account]! I appreciate your support!",
  "Welcome to the [account] fam, [username]! 🎉 Great to have you here!",
  "Hi [firstname]! ✨ Thanks for the follow! Feel free to DM me anytime!",
  "Hey [username]! 🙌 Excited to connect! What brought you to my page?",
  "Thanks for following, [firstname]! 💯 Drop me a message if you have any questions!",
  "Hey [username]! Welcome aboard! 🚀 Looking forward to engaging with your content too!",
  "[firstname]! Thanks for the follow! 🔥 What content would you like to see more of?",
  "Hi [username]! Appreciate the follow! ❤️ Let me know if there's anything I can help you with!",
];

export const promoTemplates = [
  "Hey [username]! 🎁 Special offer just for my followers! Check out [link] for 20% off!",
  "[firstname], you're invited! 🌟 Exclusive access to our new collection. DM me 'INFO' to learn more!",
  "Hi [username]! 💎 As a valued follower, you get early access to our launch. Interested?",
  "[firstname]! 🔥 Limited time offer for followers only! Would you like to know more?",
  "Hey [username]! ✨ I think you'd love what we're working on. Can I share the details?",
];

export const followUpTemplates = [
  "Hey [username]! Just following up on my last message. Any questions?",
  "[firstname], still interested in [topic]? Let me know how I can help! 😊",
  "Hi [username]! Wanted to check in. Did you get a chance to check out [content]?",
  "[firstname]! 👋 Following up! Is there anything specific you'd like to know?",
];

export const autoReplyTemplates = [
  "Thanks for your message, [username]! I'll get back to you soon! 😊",
  "Hey [firstname]! Got your message! I'll respond within 24 hours. Talk soon! ✨",
  "Hi [username]! Thanks for reaching out! I'm currently away but will reply shortly! 🙌",
  "[firstname], appreciate your message! I'll get back to you ASAP! 💯",
];

export const engagementTemplates = [
  "Loved your recent post, [username]! 🔥 Keep up the great content!",
  "Hey [firstname]! Your profile is amazing! Would love to collaborate sometime! ✨",
  "[username], your [niche] content is 🔥! Sending you a follow back!",
  "Hi [firstname]! Really enjoy your work! Let's support each other! 💪",
];

export function getTemplatesByCategory(category: string): string[] {
  switch (category.toLowerCase()) {
    case 'welcome':
      return welcomeTemplates;
    case 'promo':
    case 'promotion':
      return promoTemplates;
    case 'follow-up':
    case 'followup':
      return followUpTemplates;
    case 'auto-reply':
    case 'autoreply':
      return autoReplyTemplates;
    case 'engagement':
      return engagementTemplates;
    default:
      return welcomeTemplates;
  }
}

export function getRandomTemplate(category: string = 'welcome'): string {
  const templates = getTemplatesByCategory(category);
  return templates[Math.floor(Math.random() * templates.length)];
}

export function validateDM(message: string): { valid: boolean; reason?: string } {
  if (!message || message.trim().length === 0) {
    return { valid: false, reason: 'Message is empty' };
  }

  if (message.length < 5) {
    return { valid: false, reason: 'Message is too short (min 5 characters)' };
  }

  if (message.length > 1000) {
    return { valid: false, reason: 'Message is too long (max 1000 characters)' };
  }

  const spamPatterns = [
    /click here/i,
    /buy now/i,
    /limited time/i,
    /act now/i,
    /urgent/i,
    /free money/i,
    /make money fast/i,
    /weight loss/i,
    /viagra/i,
  ];

  if (spamPatterns.some(pattern => pattern.test(message))) {
    return { valid: false, reason: 'Message contains spam-like content' };
  }

  const urlCount = (message.match(/https?:\/\//g) || []).length;
  if (urlCount > 1) {
    return { valid: false, reason: 'Too many links (max 1)' };
  }

  return { valid: true };
}

export function addVariation(message: string): string {
  const variations = [
    message,
    message.replace('!', ''),
    message.replace('!', '!!'),
    message + ' 😊',
    message + ' ✨',
    message + ' 🙌',
  ];

  return variations[Math.floor(Math.random() * variations.length)];
}

export function shouldSendDM(userProfile: {
  isFollowing: boolean;
  isFollower: boolean;
  hasBeenContacted?: boolean;
  lastContactDays?: number;
}): { should: boolean; reason: string } {
  const { isFollowing, isFollower, hasBeenContacted, lastContactDays } = userProfile;

  if (hasBeenContacted && (lastContactDays === undefined || lastContactDays < 30)) {
    return {
      should: false,
      reason: 'User was contacted recently (wait 30 days)',
    };
  }

  if (!isFollower && !isFollowing) {
    return {
      should: false,
      reason: 'No relationship with user',
    };
  }

  return {
    should: true,
    reason: 'Safe to send DM',
  };
}

export function estimateResponseRate(campaign: {
  messageLength: number;
  hasPersonalization: boolean;
  hasEmojis: boolean;
  hasQuestion: boolean;
  timeOfDay: number;
}): number {
  let baseRate = 0.15;

  if (campaign.messageLength < 50) {
    baseRate += 0.05;
  } else if (campaign.messageLength > 200) {
    baseRate -= 0.05;
  }

  if (campaign.hasPersonalization) {
    baseRate += 0.08;
  }

  if (campaign.hasEmojis) {
    baseRate += 0.03;
  }

  if (campaign.hasQuestion) {
    baseRate += 0.07;
  }

  if (campaign.timeOfDay >= 9 && campaign.timeOfDay <= 21) {
    baseRate += 0.05;
  }

  return Math.min(Math.max(baseRate, 0), 1);
}

export function generateDMVariations(template: string, count: number = 5): string[] {
  const variations = new Set<string>();

  variations.add(template);

  const emojis = ['😊', '✨', '🙌', '💯', '🔥', '👋', '❤️', '💪', '🎉', '⭐'];

  const greetings = ['Hey', 'Hi', 'Hello', 'Yo', 'What\'s up'];

  while (variations.size < count) {
    let variation = template;

    const hasEmoji = /[\u{1F300}-\u{1F9FF}]/u.test(variation);
    if (!hasEmoji && Math.random() < 0.7) {
      const emoji = emojis[Math.floor(Math.random() * emojis.length)];
      if (Math.random() < 0.5) {
        variation = emoji + ' ' + variation;
      } else {
        variation = variation + ' ' + emoji;
      }
    }

    if (variation.startsWith('Hey') && Math.random() < 0.4) {
      const newGreeting = greetings[Math.floor(Math.random() * greetings.length)];
      variation = variation.replace(/^Hey/, newGreeting);
    }

    const exclamationCount = (variation.match(/!/g) || []).length;
    if (exclamationCount === 1 && Math.random() < 0.3) {
      variation = variation.replace('!', '!!');
    } else if (exclamationCount > 1 && Math.random() < 0.3) {
      variation = variation.replace(/!!+/g, '!');
    }

    if (variation.length >= 5) {
      variations.add(variation);
    }
  }

  return Array.from(variations).slice(0, count);
}

export function createPersonalizedDrip(templates: string[], data: PersonalizationData): string[] {
  return templates.map(template => personalizeDM(template, data));
}

export function scheduleOptimalTime(): Date {
  const now = new Date();
  const hour = now.getHours();

  let targetHour = hour;

  if (hour < 9) {
    targetHour = 9;
  } else if (hour > 21) {
    targetHour = 9;
    now.setDate(now.getDate() + 1);
  }

  now.setHours(targetHour, Math.floor(Math.random() * 60), 0, 0);

  return now;
}
