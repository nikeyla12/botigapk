interface HashtagSet {
  category: string;
  tags: string[];
}

const hashtagDatabase: HashtagSet[] = [
  {
    category: 'fashion',
    tags: [
      'fashion', 'style', 'ootd', 'fashionblogger', 'instafashion',
      'fashionista', 'streetstyle', 'outfitoftheday', 'fashiongram', 'stylish',
      'trendy', 'fashionable', 'fashionweek', 'fashiondesigner', 'fashiondiaries',
      'fashionaddict', 'fashionstyle', 'fashionlover', 'styleinspo', 'fashionphotography',
    ],
  },
  {
    category: 'fitness',
    tags: [
      'fitness', 'gym', 'workout', 'fitnessmotivation', 'fit',
      'bodybuilding', 'training', 'health', 'fitfam', 'exercise',
      'muscle', 'fitnessjourney', 'gymlife', 'fitlife', 'healthy',
      'motivation', 'gains', 'cardio', 'strength', 'fitnessaddict',
    ],
  },
  {
    category: 'food',
    tags: [
      'food', 'foodie', 'foodporn', 'instafood', 'foodstagram',
      'foodphotography', 'foodlover', 'delicious', 'yummy', 'foodgasm',
      'homemade', 'cooking', 'foodblogger', 'tasty', 'dinner',
      'lunch', 'breakfast', 'recipe', 'chef', 'foodiesofinstagram',
    ],
  },
  {
    category: 'travel',
    tags: [
      'travel', 'travelphotography', 'travelgram', 'instatravel', 'wanderlust',
      'adventure', 'explore', 'vacation', 'trip', 'traveling',
      'traveltheworld', 'travelblogger', 'travelholic', 'traveladdict', 'tourism',
      'holiday', 'traveler', 'travellife', 'worldtraveler', 'beautifuldestinations',
    ],
  },
  {
    category: 'photography',
    tags: [
      'photography', 'photo', 'photographer', 'photooftheday', 'picoftheday',
      'photos', 'photoshoot', 'instagram', 'canon', 'nikon',
      'camera', 'portrait', 'landscape', 'naturephotography', 'travelphotography',
      'photographylovers', 'photoart', 'instaphoto', 'photographyislife', 'portraitphotography',
    ],
  },
  {
    category: 'beauty',
    tags: [
      'beauty', 'makeup', 'skincare', 'beautyblogger', 'makeuptutorial',
      'makeupartist', 'cosmetics', 'beautytips', 'instabeauty', 'makeupaddict',
      'beautyguru', 'makeuplover', 'beautycommunity', 'glam', 'beautyjunkie',
      'makeupoftheday', 'beautycare', 'selfcare', 'skincareroutine', 'beautyblog',
    ],
  },
  {
    category: 'business',
    tags: [
      'business', 'entrepreneur', 'motivation', 'success', 'marketing',
      'smallbusiness', 'businessowner', 'startup', 'hustle', 'entrepreneurship',
      'businesstips', 'businessman', 'businesswoman', 'money', 'businessmindset',
      'businesslife', 'businesscoach', 'businessgrowth', 'leadership', 'entrepreneurlife',
    ],
  },
  {
    category: 'art',
    tags: [
      'art', 'artist', 'artwork', 'drawing', 'painting',
      'illustration', 'design', 'creative', 'instaart', 'artistsoninstagram',
      'sketch', 'art_gallery', 'contemporaryart', 'artoftheday', 'digitalart',
      'artlovers', 'artsy', 'fineart', 'abstract', 'modernart',
    ],
  },
  {
    category: 'lifestyle',
    tags: [
      'lifestyle', 'life', 'instagood', 'happy', 'love',
      'daily', 'motivation', 'inspiration', 'lifestyleblogger', 'lifequotes',
      'wellness', 'selfcare', 'mindfulness', 'positivevibes', 'goodvibes',
      'happiness', 'blessed', 'grateful', 'liveyourbestlife', 'lifestyledesign',
    ],
  },
  {
    category: 'nature',
    tags: [
      'nature', 'naturephotography', 'landscape', 'outdoor', 'mountains',
      'hiking', 'adventure', 'naturelovers', 'wildlife', 'forest',
      'sunset', 'beach', 'ocean', 'sky', 'outdoors',
      'naturelover', 'landscapephotography', 'explore', 'beautiful', 'naturegram',
    ],
  },
];

const popularHashtags = [
  'love', 'instagood', 'photooftheday', 'beautiful', 'happy',
  'cute', 'followme', 'like4like', 'follow', 'me',
  'selfie', 'summer', 'art', 'instadaily', 'friends',
  'repost', 'nature', 'fun', 'style', 'smile',
  'life', 'likeforlike', 'amazing', 'followforfollow', 'picoftheday',
  'instalike', 'follow4follow', 'igers', 'instamood', 'photography',
];

const engagementHashtags = [
  'follow', 'followme', 'followforfollow', 'followback', 'followers',
  'like', 'like4like', 'likeforlike', 'likes', 'likeforlikes',
  'instagood', 'instagram', 'insta', 'instadaily', 'instalike',
  'comment', 'comments', 'commentforcomment', 'viral', 'trending',
];

export function suggestHashtags(caption: string, maxTags: number = 15): string[] {
  const suggested = new Set<string>();
  const captionLower = caption.toLowerCase();

  hashtagDatabase.forEach(({ category, tags }) => {
    if (captionLower.includes(category)) {
      tags.slice(0, 5).forEach(tag => suggested.add(tag));
    }
  });

  const words = captionLower.split(/\s+/);
  hashtagDatabase.forEach(({ category, tags }) => {
    tags.forEach(tag => {
      if (words.some(word => word.includes(tag) || tag.includes(word))) {
        suggested.add(tag);
      }
    });
  });

  while (suggested.size < maxTags && suggested.size < 30) {
    const randomCategory = hashtagDatabase[Math.floor(Math.random() * hashtagDatabase.length)];
    const randomTag = randomCategory.tags[Math.floor(Math.random() * randomCategory.tags.length)];
    suggested.add(randomTag);
  }

  return Array.from(suggested).slice(0, maxTags);
}

export function getHashtagsByCategory(category: string): string[] {
  const found = hashtagDatabase.find(set => set.category.toLowerCase() === category.toLowerCase());
  return found ? found.tags : [];
}

export function getMixedHashtags(options: {
  niche?: string;
  includePopular?: boolean;
  includeEngagement?: boolean;
  count?: number;
}): string[] {
  const { niche, includePopular = true, includeEngagement = true, count = 30 } = options;
  const tags = new Set<string>();

  if (niche) {
    const nicheTags = getHashtagsByCategory(niche);
    nicheTags.slice(0, 15).forEach(tag => tags.add(tag));
  }

  if (includePopular) {
    popularHashtags.slice(0, 8).forEach(tag => tags.add(tag));
  }

  if (includeEngagement) {
    engagementHashtags.slice(0, 7).forEach(tag => tags.add(tag));
  }

  return Array.from(tags).slice(0, count);
}

export function getHashtagScore(hashtag: string): {
  competition: 'low' | 'medium' | 'high';
  reach: 'low' | 'medium' | 'high' | 'very high';
  recommended: boolean;
} {
  const isPopular = popularHashtags.includes(hashtag);
  const isEngagement = engagementHashtags.includes(hashtag);

  if (isPopular) {
    return {
      competition: 'high',
      reach: 'very high',
      recommended: false,
    };
  }

  if (isEngagement) {
    return {
      competition: 'high',
      reach: 'high',
      recommended: true,
    };
  }

  const length = hashtag.length;
  if (length < 8) {
    return {
      competition: 'high',
      reach: 'high',
      recommended: false,
    };
  } else if (length < 15) {
    return {
      competition: 'medium',
      reach: 'medium',
      recommended: true,
    };
  } else {
    return {
      competition: 'low',
      reach: 'low',
      recommended: true,
    };
  }
}

export function optimizeHashtags(hashtags: string[]): {
  optimized: string[];
  removed: string[];
  suggestions: string[];
} {
  const removed: string[] = [];
  const optimized: string[] = [];

  hashtags.forEach(tag => {
    const score = getHashtagScore(tag);

    if (score.competition === 'high' && score.reach !== 'very high') {
      removed.push(tag);
    } else {
      optimized.push(tag);
    }
  });

  const suggestions: string[] = [];
  if (optimized.length < 20) {
    const needed = 20 - optimized.length;
    hashtagDatabase.forEach(({ tags }) => {
      tags.forEach(tag => {
        if (!optimized.includes(tag) && suggestions.length < needed) {
          const score = getHashtagScore(tag);
          if (score.recommended) {
            suggestions.push(tag);
          }
        }
      });
    });
  }

  return {
    optimized,
    removed,
    suggestions,
  };
}

export function generateHashtagStrategy(niche: string): {
  broad: string[];
  medium: string[];
  niche: string[];
  total: string[];
} {
  const nicheTags = getHashtagsByCategory(niche);

  const broad = popularHashtags.slice(0, 5);

  const medium = nicheTags.slice(0, 15);

  const nicheSpecific = nicheTags.slice(15, 25);

  return {
    broad,
    medium,
    niche: nicheSpecific,
    total: [...broad, ...medium, ...nicheSpecific],
  };
}

export function getTrendingHashtags(): string[] {
  return [
    'viral', 'trending', 'explore', 'explorepage', 'fyp',
    'foryou', 'foryoupage', 'reels', 'reelsinstagram', 'instareels',
    'trendingnow', 'viralpost', 'exploremore', 'instagram', 'instagood',
  ];
}

export function getBestHashtagCombos(category: string): string[][] {
  const categoryTags = getHashtagsByCategory(category);
  const trending = getTrendingHashtags();
  const popular = popularHashtags;

  return [
    [...categoryTags.slice(0, 20), ...trending.slice(0, 5), ...popular.slice(0, 5)],
    [...categoryTags.slice(5, 25), ...trending.slice(2, 7), ...popular.slice(2, 7)],
    [...categoryTags.slice(10, 30), ...trending.slice(0, 3), ...popular.slice(5, 10)],
  ];
}

export function analyzeHashtagPerformance(hashtag: string): {
  estimatedPosts: string;
  difficulty: 'easy' | 'medium' | 'hard';
  recommendation: string;
} {
  const score = getHashtagScore(hashtag);

  let estimatedPosts = '100K - 1M';
  let difficulty: 'easy' | 'medium' | 'hard' = 'medium';
  let recommendation = '';

  if (score.competition === 'high') {
    estimatedPosts = '10M+';
    difficulty = 'hard';
    recommendation = 'Very competitive. Hard to rank. Use sparingly.';
  } else if (score.competition === 'medium') {
    estimatedPosts = '500K - 5M';
    difficulty = 'medium';
    recommendation = 'Good balance. Decent chance to rank.';
  } else {
    estimatedPosts = '10K - 500K';
    difficulty = 'easy';
    recommendation = 'Less competitive. Higher chance to rank!';
  }

  return {
    estimatedPosts,
    difficulty,
    recommendation,
  };
}

export function extractHashtagsFromCaption(caption: string): string[] {
  const hashtagPattern = /#(\w+)/g;
  const matches = caption.match(hashtagPattern);
  return matches ? matches.map(tag => tag.substring(1)) : [];
}

export function removeHashtagsFromCaption(caption: string): string {
  return caption.replace(/#\w+/g, '').trim();
}

export function formatHashtagsForFirstComment(hashtags: string[]): string {
  return hashtags.map(tag => `#${tag}`).join(' ');
}

export const categoryList = hashtagDatabase.map(set => set.category);
