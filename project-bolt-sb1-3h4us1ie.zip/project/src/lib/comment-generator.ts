interface CommentOptions {
  niche?: string;
  useEmojis?: boolean;
  length?: 'short' | 'medium' | 'long';
  tone?: 'casual' | 'professional' | 'enthusiastic';
}

const shortComments = [
  'Amazing!',
  'Love this!',
  'So cool!',
  'Nice!',
  'Great shot!',
  'Perfect!',
  'Wow!',
  'Awesome!',
  'Beautiful!',
  'Incredible!',
  'Stunning!',
  'Epic!',
  'Fire!',
  'Goals!',
  'Insane!',
];

const mediumComments = [
  'This is absolutely amazing!',
  'Love the vibes here!',
  'This content is fire!',
  'So inspiring to see this!',
  'Keep up the great work!',
  'This made my day!',
  'Really appreciate this content!',
  'Can\'t get enough of this!',
  'This is exactly what I needed!',
  'You always deliver quality!',
  'This is so well done!',
  'Loving the creativity here!',
  'This deserves more recognition!',
  'You\'re killing it with this!',
  'Absolutely love your content!',
];

const longComments = [
  'This is absolutely incredible! Keep creating amazing content like this!',
  'Wow, I\'m blown away by the quality of this! Really inspiring work!',
  'I always look forward to your posts! This one is especially great!',
  'The attention to detail here is amazing! You\'re so talented!',
  'This is exactly the kind of content I love to see! Keep it up!',
  'I can\'t believe how good this is! You really outdid yourself!',
  'This is such high quality content! Really appreciate what you do!',
  'Every time you post, it gets better and better! Love this!',
  'This is so well executed! Can tell you put a lot of work into this!',
  'Absolutely loving everything about this! You\'re so talented!',
  'This is the kind of content that inspires me! Thank you for sharing!',
  'The creativity here is off the charts! Really impressive work!',
  'I always stop scrolling when I see your content! This is amazing!',
  'You have such a unique style! Really love what you\'re doing!',
  'This is next level content! Can\'t wait to see what you post next!',
];

const emojis = {
  positive: ['🔥', '💯', '✨', '👏', '🙌', '❤️', '💪', '😍', '🤩', '⭐'],
  excited: ['🚀', '💥', '⚡', '🎉', '🎊', '🏆', '👑', '💎', '🌟', '✌️'],
  supportive: ['💚', '💙', '💜', '🧡', '💖', '💗', '💓', '💕', '🤝', '👍'],
};

const questionComments = [
  'How did you achieve this?',
  'What camera did you use?',
  'Where is this location?',
  'Can you share more about this?',
  'What inspired you to create this?',
  'Would love to know your process!',
  'Any tips for someone starting out?',
  'How long did this take to create?',
];

const nicheComments: Record<string, string[]> = {
  fashion: [
    'Love this outfit! Where is it from?',
    'Your style is always on point!',
    'This look is everything! 🔥',
    'You always know how to dress!',
    'Need this in my wardrobe!',
  ],
  fitness: [
    'Your dedication is inspiring! 💪',
    'Keep crushing those goals!',
    'This is the motivation I needed today!',
    'Your progress is amazing!',
    'You\'re an inspiration to many!',
  ],
  food: [
    'This looks absolutely delicious! 🤤',
    'I need to try this recipe!',
    'My mouth is watering! 😋',
    'You always make the best food!',
    'This presentation is beautiful!',
  ],
  travel: [
    'Adding this to my bucket list! ✈️',
    'What an incredible view!',
    'This place looks like paradise!',
    'I need to visit here someday!',
    'Your travel content is always amazing!',
  ],
  photography: [
    'The composition here is perfect!',
    'Love the lighting in this shot!',
    'Your eye for detail is incredible!',
    'Such a beautiful capture! 📸',
    'The colors are stunning!',
  ],
  business: [
    'Great insights! Thanks for sharing!',
    'This is valuable information!',
    'Appreciate the knowledge you share!',
    'This perspective is really helpful!',
    'Always learning from your content!',
  ],
  art: [
    'Your creativity is boundless! 🎨',
    'This is a masterpiece!',
    'The detail in this is incredible!',
    'Your art always amazes me!',
    'This is so unique and beautiful!',
  ],
};

function getRandomEmoji(category: keyof typeof emojis = 'positive'): string {
  const emojiList = emojis[category];
  return emojiList[Math.floor(Math.random() * emojiList.length)];
}

function getRandomComment(length: 'short' | 'medium' | 'long'): string {
  const comments = length === 'short' ? shortComments :
                   length === 'medium' ? mediumComments :
                   longComments;
  return comments[Math.floor(Math.random() * comments.length)];
}

function addVariation(comment: string): string {
  const variations = [
    comment,
    comment + '!',
    comment + '!!',
    comment.replace('!', '.'),
    comment.toLowerCase(),
  ];
  return variations[Math.floor(Math.random() * variations.length)];
}

export function generateSmartComment(options: CommentOptions = {}): string {
  const {
    niche = 'general',
    useEmojis = true,
    length = 'medium',
    tone = 'casual',
  } = options;

  let comment = '';

  if (niche && niche !== 'general' && nicheComments[niche]) {
    const nicheCommentList = nicheComments[niche];
    comment = nicheCommentList[Math.floor(Math.random() * nicheCommentList.length)];
  } else {
    const useQuestion = Math.random() < 0.15;

    if (useQuestion) {
      comment = questionComments[Math.floor(Math.random() * questionComments.length)];
    } else {
      comment = getRandomComment(length);
    }
  }

  comment = addVariation(comment);

  if (useEmojis && Math.random() < 0.7) {
    const hasEmoji = /[\u{1F300}-\u{1F9FF}]/u.test(comment);

    if (!hasEmoji) {
      const emojiCategory = tone === 'enthusiastic' ? 'excited' :
                           tone === 'professional' ? 'supportive' :
                           'positive';

      const shouldAddAtEnd = Math.random() < 0.8;

      if (shouldAddAtEnd) {
        comment = comment.trim() + ' ' + getRandomEmoji(emojiCategory);
      } else {
        comment = getRandomEmoji(emojiCategory) + ' ' + comment.trim();
      }
    }
  }

  return comment.trim();
}

export function generateBulkComments(count: number, options: CommentOptions = {}): string[] {
  const comments = new Set<string>();

  while (comments.size < count) {
    comments.add(generateSmartComment(options));
  }

  return Array.from(comments);
}

export function isSpammy(comment: string): boolean {
  const spamPatterns = [
    /^(nice|cool|great|awesome)$/i,
    /check out my/i,
    /follow me/i,
    /dm me/i,
    /link in bio/i,
    /^\s*[👍👏❤️🔥]+\s*$/,
  ];

  return spamPatterns.some(pattern => pattern.test(comment));
}

export function validateComment(comment: string): { valid: boolean; reason?: string } {
  if (!comment || comment.trim().length === 0) {
    return { valid: false, reason: 'Comment is empty' };
  }

  if (comment.length < 2) {
    return { valid: false, reason: 'Comment is too short' };
  }

  if (comment.length > 500) {
    return { valid: false, reason: 'Comment is too long (max 500 characters)' };
  }

  if (isSpammy(comment)) {
    return { valid: false, reason: 'Comment looks spammy' };
  }

  const urlPattern = /(https?:\/\/[^\s]+)/g;
  if (urlPattern.test(comment)) {
    return { valid: false, reason: 'Comment contains URLs' };
  }

  return { valid: true };
}
