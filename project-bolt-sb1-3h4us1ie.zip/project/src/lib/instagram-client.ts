import { DeviceFingerprint } from './device-fingerprint';

export interface InstagramLoginResponse {
  success: boolean;
  user?: {
    pk: string;
    username: string;
    full_name: string;
    profile_pic_url: string;
  };
  session?: {
    cookies: string;
    csrf_token: string;
    session_id: string;
  };
  error?: string;
}

export interface InstagramUserInfo {
  pk: string;
  username: string;
  full_name: string;
  biography: string;
  follower_count: number;
  following_count: number;
  media_count: number;
  profile_pic_url: string;
  is_private: boolean;
  is_verified: boolean;
}

export class InstagramClient {
  private baseUrl = 'https://i.instagram.com/api/v1';
  private device: DeviceFingerprint;
  private cookies: Map<string, string> = new Map();
  private csrfToken: string = '';

  constructor(device: DeviceFingerprint) {
    this.device = device;
  }

  private generateHeaders(includeAuth: boolean = false): Record<string, string> {
    const headers: Record<string, string> = {
      'User-Agent': this.device.user_agent,
      'Accept': '*/*',
      'Accept-Language': this.device.language,
      'Accept-Encoding': 'gzip, deflate',
      'Connection': 'keep-alive',
      'X-IG-App-Locale': this.device.language.split('-')[0],
      'X-IG-Device-Locale': this.device.language.split('-')[0],
      'X-IG-Mapped-Locale': this.device.language.split('-')[0],
      'X-Pigeon-Session-Id': this.generatePigeonSessionId(),
      'X-Pigeon-Rawclienttime': (Date.now() / 1000).toFixed(3),
      'X-IG-Bandwidth-Speed-KBPS': '-1.000',
      'X-IG-Bandwidth-TotalBytes-B': '0',
      'X-IG-Bandwidth-TotalTime-MS': '0',
      'X-IG-App-Startup-Country': this.device.timezone.split('/')[0],
      'X-Bloks-Version-Id': this.getBloksVersionId(),
      'X-IG-WWW-Claim': '0',
      'X-Bloks-Is-Layout-RTL': 'false',
      'X-Bloks-Is-Panorama-Enabled': 'true',
      'X-IG-Device-ID': this.device.device_id,
      'X-IG-Family-Device-ID': this.device.device_id,
      'X-IG-Android-ID': this.device.android_id || this.generateAndroidId(),
      'X-IG-Timezone-Offset': this.getTimezoneOffset().toString(),
      'X-IG-Connection-Type': this.device.network_type || 'wifi',
      'X-IG-Capabilities': '3brTvx0=',
      'X-IG-App-ID': '567067343352427',
      'X-IG-VP9-Capable': 'true',
      'X-IG-AV-PRIORITY': '0',
      'X-IG-SALT-IDS': '1004990422',
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    };

    if (this.device.device_type === 'android') {
      headers['X-IG-ABR-Connection-Speed-KBPS'] = '0';
      headers['X-IG-App-Startup-Country'] = this.device.mcc || '310';
      headers['X-IG-Network-Type-V2'] = this.device.network_type || 'wifi';
      if (this.device.advertising_id) headers['X-Google-AD-ID'] = this.device.advertising_id;
      if (this.device.carrier) headers['X-IG-Connection-Carrier'] = this.device.carrier;
    }

    if (includeAuth && this.csrfToken) {
      headers['X-CSRFToken'] = this.csrfToken;
      headers['Cookie'] = this.getCookieHeader();
    }

    return headers;
  }

  private generatePigeonSessionId(): string {
    return `UFS-${this.generateUUID()}-0`;
  }

  private generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  private generateAndroidId(): string {
    return 'android-' + Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }

  private getBloksVersionId(): string {
    const version = this.device.app_version.split('.')[0];
    return `${version}0000000000000000000000`;
  }

  private getTimezoneOffset(): number {
    return -new Date().getTimezoneOffset() * 60;
  }

  private getCookieHeader(): string {
    return Array.from(this.cookies.entries())
      .map(([key, value]) => `${key}=${value}`)
      .join('; ');
  }

  private parseCookies(cookieHeader: string): void {
    const cookies = cookieHeader.split(/[,;]/).map(c => c.trim());
    for (const cookie of cookies) {
      const [key, value] = cookie.split('=');
      if (key && value) {
        const cleanKey = key.trim();
        const cleanValue = value.split(';')[0].trim();
        this.cookies.set(cleanKey, cleanValue);

        if (cleanKey === 'csrftoken') {
          this.csrfToken = cleanValue;
        }
      }
    }
  }

  async login(username: string, password: string): Promise<InstagramLoginResponse> {
    try {
      const preLoginData = await this.preLoginFlow();
      if (!preLoginData.success) {
        return { success: false, error: 'Pre-login flow failed' };
      }

      const loginData = new URLSearchParams({
        username,
        enc_password: `#PWD_INSTAGRAM:0:${Date.now()}:${password}`,
        guid: this.device.device_id,
        phone_id: this.generateUUID(),
        _csrftoken: this.csrfToken,
        device_id: this.device.device_id,
        adid: this.generateUUID(),
        google_tokens: '[]',
        login_attempt_count: '0',
        country_codes: JSON.stringify([{ country_code: '1', source: 'default' }]),
        jazoest: this.generateJazoest(),
      });

      const response = await fetch(`${this.baseUrl}/accounts/login/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: loginData.toString(),
      });

      const setCookieHeader = response.headers.get('set-cookie');
      if (setCookieHeader) {
        this.parseCookies(setCookieHeader);
      }

      const result = await response.json();

      if (result.logged_in_user) {
        return {
          success: true,
          user: {
            pk: result.logged_in_user.pk,
            username: result.logged_in_user.username,
            full_name: result.logged_in_user.full_name,
            profile_pic_url: result.logged_in_user.profile_pic_url,
          },
          session: {
            cookies: this.getCookieHeader(),
            csrf_token: this.csrfToken,
            session_id: this.cookies.get('sessionid') || '',
          },
        };
      }

      return {
        success: false,
        error: result.message || 'Login failed',
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Network error',
      };
    }
  }

  private async preLoginFlow(): Promise<{ success: boolean }> {
    try {
      const response = await fetch(`${this.baseUrl}/si/fetch_headers/?challenge_type=signup&guid=${this.device.device_id}`, {
        method: 'GET',
        headers: this.generateHeaders(false),
      });

      const setCookieHeader = response.headers.get('set-cookie');
      if (setCookieHeader) {
        this.parseCookies(setCookieHeader);
      }

      return { success: true };
    } catch {
      return { success: false };
    }
  }

  private generateJazoest(): string {
    return '2' + Array.from({ length: 4 }, () =>
      Math.floor(Math.random() * 10)
    ).join('');
  }

  async getUserInfo(username: string): Promise<InstagramUserInfo | null> {
    try {
      const response = await fetch(`${this.baseUrl}/users/${username}/usernameinfo/`, {
        method: 'GET',
        headers: this.generateHeaders(true),
      });

      const result = await response.json();

      if (result.user) {
        return {
          pk: result.user.pk,
          username: result.user.username,
          full_name: result.user.full_name,
          biography: result.user.biography,
          follower_count: result.user.follower_count,
          following_count: result.user.following_count,
          media_count: result.user.media_count,
          profile_pic_url: result.user.profile_pic_url,
          is_private: result.user.is_private,
          is_verified: result.user.is_verified,
        };
      }

      return null;
    } catch {
      return null;
    }
  }

  async sendDirectMessage(userId: string, message: string): Promise<boolean> {
    try {
      const data = new URLSearchParams({
        recipient_users: JSON.stringify([userId]),
        client_context: this.generateUUID(),
        thread_ids: '[]',
        text: message,
        device_id: this.device.device_id,
        mutation_token: this.generateUUID(),
        _csrftoken: this.csrfToken,
        _uid: userId,
      });

      const response = await fetch(`${this.baseUrl}/direct_v2/threads/broadcast/text/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: data.toString(),
      });

      const result = await response.json();
      return result.status === 'ok';
    } catch {
      return false;
    }
  }

  async followUser(userId: string): Promise<boolean> {
    try {
      const data = new URLSearchParams({
        user_id: userId,
        device_id: this.device.device_id,
        _csrftoken: this.csrfToken,
        _uid: userId,
      });

      const response = await fetch(`${this.baseUrl}/friendships/create/${userId}/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: data.toString(),
      });

      const result = await response.json();
      return result.status === 'ok';
    } catch {
      return false;
    }
  }

  async unfollowUser(userId: string): Promise<boolean> {
    try {
      const data = new URLSearchParams({
        user_id: userId,
        device_id: this.device.device_id,
        _csrftoken: this.csrfToken,
        _uid: userId,
      });

      const response = await fetch(`${this.baseUrl}/friendships/destroy/${userId}/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: data.toString(),
      });

      const result = await response.json();
      return result.status === 'ok';
    } catch {
      return false;
    }
  }

  async likeMedia(mediaId: string): Promise<boolean> {
    try {
      const data = new URLSearchParams({
        media_id: mediaId,
        device_id: this.device.device_id,
        _csrftoken: this.csrfToken,
      });

      const response = await fetch(`${this.baseUrl}/media/${mediaId}/like/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: data.toString(),
      });

      const result = await response.json();
      return result.status === 'ok';
    } catch {
      return false;
    }
  }

  async commentOnMedia(mediaId: string, comment: string): Promise<boolean> {
    try {
      const data = new URLSearchParams({
        comment_text: comment,
        device_id: this.device.device_id,
        _csrftoken: this.csrfToken,
      });

      const response = await fetch(`${this.baseUrl}/media/${mediaId}/comment/`, {
        method: 'POST',
        headers: this.generateHeaders(true),
        body: data.toString(),
      });

      const result = await response.json();
      return result.status === 'ok';
    } catch {
      return false;
    }
  }

  loadSession(cookies: string, csrfToken: string): void {
    this.cookies.clear();
    const cookiePairs = cookies.split('; ');
    for (const pair of cookiePairs) {
      const [key, value] = pair.split('=');
      if (key && value) {
        this.cookies.set(key, value);
      }
    }
    this.csrfToken = csrfToken;
  }

  getSession(): { cookies: string; csrf_token: string } {
    return {
      cookies: this.getCookieHeader(),
      csrf_token: this.csrfToken,
    };
  }
}

export function createInstagramClient(device: DeviceFingerprint): InstagramClient {
  return new InstagramClient(device);
}
