export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      instagram_accounts: {
        Row: {
          id: string
          user_id: string
          username: string
          access_token: string
          account_id: string
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          username: string
          access_token: string
          account_id: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          username?: string
          access_token?: string
          account_id?: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      auto_reply_rules: {
        Row: {
          id: string
          instagram_account_id: string
          trigger_type: 'dm' | 'comment' | 'mention' | 'all'
          keyword: string | null
          reply_message: string
          is_active: boolean
          priority: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          instagram_account_id: string
          trigger_type: 'dm' | 'comment' | 'mention' | 'all'
          keyword?: string | null
          reply_message: string
          is_active?: boolean
          priority?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          instagram_account_id?: string
          trigger_type?: 'dm' | 'comment' | 'mention' | 'all'
          keyword?: string | null
          reply_message?: string
          is_active?: boolean
          priority?: number
          created_at?: string
          updated_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          instagram_account_id: string
          sender_username: string
          sender_id: string
          message_type: 'dm' | 'comment' | 'mention'
          message_text: string
          reply_text: string | null
          rule_id: string | null
          status: 'received' | 'replied' | 'failed' | 'ignored'
          received_at: string
          replied_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          instagram_account_id: string
          sender_username: string
          sender_id: string
          message_type: 'dm' | 'comment' | 'mention'
          message_text: string
          reply_text?: string | null
          rule_id?: string | null
          status?: 'received' | 'replied' | 'failed' | 'ignored'
          received_at?: string
          replied_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          instagram_account_id?: string
          sender_username?: string
          sender_id?: string
          message_type?: 'dm' | 'comment' | 'mention'
          message_text?: string
          reply_text?: string | null
          rule_id?: string | null
          status?: 'received' | 'replied' | 'failed' | 'ignored'
          received_at?: string
          replied_at?: string | null
          created_at?: string
        }
      }
      analytics: {
        Row: {
          id: string
          instagram_account_id: string
          date: string
          total_messages: number
          total_replies: number
          total_dms: number
          total_comments: number
          total_mentions: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          instagram_account_id: string
          date: string
          total_messages?: number
          total_replies?: number
          total_dms?: number
          total_comments?: number
          total_mentions?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          instagram_account_id?: string
          date?: string
          total_messages?: number
          total_replies?: number
          total_dms?: number
          total_comments?: number
          total_mentions?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
