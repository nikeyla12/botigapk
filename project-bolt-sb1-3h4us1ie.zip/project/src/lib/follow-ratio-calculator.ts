export interface FollowRatioResult {
  ratio: number;
  status: 'excellent' | 'good' | 'fair' | 'poor' | 'critical';
  message: string;
  recommendations: string[];
  canFollow: boolean;
  shouldUnfollow: boolean;
  unfollowCount: number;
}

export interface AccountStats {
  followers: number;
  following: number;
  posts?: number;
}

export function calculateFollowRatio(stats: AccountStats): FollowRatioResult {
  const { followers, following } = stats;

  if (followers === 0 && following === 0) {
    return {
      ratio: 0,
      status: 'excellent',
      message: 'New account - Start building your presence!',
      recommendations: [
        'Start by following 10-20 accounts in your niche',
        'Post 3-5 quality posts before aggressive following',
        'Engage with others\' content naturally',
      ],
      canFollow: true,
      shouldUnfollow: false,
      unfollowCount: 0,
    };
  }

  const ratio = following / Math.max(followers, 1);

  let status: FollowRatioResult['status'];
  let message: string;
  let recommendations: string[] = [];
  let canFollow = true;
  let shouldUnfollow = false;
  let unfollowCount = 0;

  if (ratio <= 0.8) {
    status = 'excellent';
    message = 'Perfect! You have more followers than following.';
    recommendations = [
      'Your account looks very healthy',
      'You can continue following strategically',
      'Maintain this great ratio',
    ];
  } else if (ratio <= 1.2) {
    status = 'good';
    message = 'Healthy ratio! Account looks natural.';
    recommendations = [
      'Good balance between followers and following',
      'You can still follow 20-50 accounts per day',
      'Consider selective unfollowing of non-engagers',
    ];
  } else if (ratio <= 1.8) {
    status = 'fair';
    message = 'Acceptable ratio, but room for improvement.';
    recommendations = [
      'Slow down on following new accounts',
      'Focus on content quality to attract followers',
      'Consider unfollowing inactive accounts',
    ];
    unfollowCount = Math.ceil((following - followers * 1.2) / 2);
  } else if (ratio <= 2.5) {
    status = 'poor';
    message = 'Ratio is high. Focus on unfollowing and content.';
    recommendations = [
      'Pause new follows temporarily',
      'Unfollow non-followers and inactive accounts',
      'Improve content quality to gain organic followers',
      'Engage more with your audience',
    ];
    canFollow = false;
    shouldUnfollow = true;
    unfollowCount = Math.ceil(following - followers * 1.2);
  } else {
    status = 'critical';
    message = 'Critical ratio! Account may look spammy.';
    recommendations = [
      'STOP following immediately',
      'Aggressively unfollow non-followers',
      'Wait 7-14 days before following again',
      'Focus entirely on content and engagement',
      'Your account may be flagged as spam',
    ];
    canFollow = false;
    shouldUnfollow = true;
    unfollowCount = Math.ceil(following - followers * 1.0);
  }

  return {
    ratio: parseFloat(ratio.toFixed(2)),
    status,
    message,
    recommendations,
    canFollow,
    shouldUnfollow,
    unfollowCount: Math.max(0, unfollowCount),
  };
}

export function calculateSafeFollowLimit(stats: AccountStats, accountAge?: 'new' | 'medium' | 'aged'): number {
  const { followers, following, posts = 0 } = stats;
  const ratio = following / Math.max(followers, 1);

  let baseLimit = 50;

  if (accountAge === 'new') {
    baseLimit = 20;
  } else if (accountAge === 'aged') {
    baseLimit = 100;
  }

  if (posts < 5) {
    baseLimit = Math.min(baseLimit, 15);
  }

  if (ratio > 2.0) {
    return 0;
  } else if (ratio > 1.5) {
    return Math.floor(baseLimit * 0.3);
  } else if (ratio > 1.2) {
    return Math.floor(baseLimit * 0.6);
  }

  return baseLimit;
}

export function calculateSafeUnfollowLimit(stats: AccountStats): number {
  const { followers, following } = stats;
  const ratio = following / Math.max(followers, 1);

  if (ratio <= 1.0) {
    return 20;
  } else if (ratio <= 1.5) {
    return 50;
  } else if (ratio <= 2.0) {
    return 100;
  } else {
    return 150;
  }
}

export function shouldPauseFollowing(stats: AccountStats, recentFollowCount: number): boolean {
  const { followers, following } = stats;
  const ratio = following / Math.max(followers, 1);

  if (ratio > 2.0) {
    return true;
  }

  if (recentFollowCount > 200 && ratio > 1.5) {
    return true;
  }

  if (following > 7500) {
    return true;
  }

  return false;
}

export function calculateOptimalUnfollowTarget(stats: AccountStats, targetRatio: number = 1.0): number {
  const { followers, following } = stats;

  const targetFollowing = Math.floor(followers * targetRatio);

  const unfollowCount = Math.max(0, following - targetFollowing);

  return unfollowCount;
}

export function estimateTimeToHealthyRatio(
  stats: AccountStats,
  dailyUnfollowLimit: number,
  targetRatio: number = 1.0
): number {
  const unfollowTarget = calculateOptimalUnfollowTarget(stats, targetRatio);

  if (unfollowTarget === 0) {
    return 0;
  }

  return Math.ceil(unfollowTarget / dailyUnfollowLimit);
}

export function getFollowStrategyRecommendation(stats: AccountStats): string {
  const { followers, following, posts = 0 } = stats;
  const ratio = following / Math.max(followers, 1);

  if (posts < 5) {
    return 'Focus on posting quality content first. Aim for at least 9 posts before aggressive growth.';
  }

  if (followers < 100) {
    return 'New account phase: Follow 20-30 accounts daily, engage genuinely, post consistently.';
  }

  if (ratio > 2.0) {
    return 'CRITICAL: Pause all following. Unfollow 100+ daily until ratio is below 1.5.';
  }

  if (ratio > 1.5) {
    return 'Slow growth phase: Follow 10-20 daily, unfollow 30-50 non-followers daily.';
  }

  if (ratio > 1.0) {
    return 'Balanced growth: Follow 30-50 daily, unfollow 20-30 non-followers daily.';
  }

  return 'Healthy account: Follow 50-100 daily strategically, focus on content quality.';
}

export function isProfileWorthFollowing(profile: {
  followers: number;
  following: number;
  posts: number;
  isPrivate: boolean;
  isVerified: boolean;
  isBusiness: boolean;
}): { worth: boolean; reason: string } {
  const { followers, following, posts, isPrivate, isVerified } = profile;

  if (posts < 3) {
    return { worth: false, reason: 'Too few posts (possible bot/inactive)' };
  }

  if (isPrivate) {
    return { worth: false, reason: 'Private account (can\'t see content)' };
  }

  if (isVerified && followers > 100000) {
    return { worth: false, reason: 'Celebrity/influencer (unlikely to follow back)' };
  }

  const ratio = following / Math.max(followers, 1);

  if (ratio > 3.0) {
    return { worth: false, reason: 'Following too many (possible bot/spam)' };
  }

  if (followers < 50 && following > 1000) {
    return { worth: false, reason: 'Spam-like behavior detected' };
  }

  if (followers > 50000 && ratio < 0.1) {
    return { worth: false, reason: 'Large account (low follow-back rate)' };
  }

  return { worth: true, reason: 'Profile looks good!' };
}
