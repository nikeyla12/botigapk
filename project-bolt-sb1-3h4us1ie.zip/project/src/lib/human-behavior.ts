export interface HumanBehaviorConfig {
  typingSpeedWPM: number;
  typingVariance: number;
  viewDurationMin: number;
  viewDurationMax: number;
  actionDelayMin: number;
  actionDelayMax: number;
  scrollDelayMin: number;
  scrollDelayMax: number;
}

export const DEFAULT_BEHAVIOR: HumanBehaviorConfig = {
  typingSpeedWPM: 60,
  typingVariance: 20,
  viewDurationMin: 3,
  viewDurationMax: 8,
  actionDelayMin: 3,
  actionDelayMax: 15,
  scrollDelayMin: 2,
  scrollDelayMax: 5,
};

export class HumanBehaviorSimulator {
  private config: HumanBehaviorConfig;

  constructor(config: HumanBehaviorConfig = DEFAULT_BEHAVIOR) {
    this.config = config;
  }

  getRandomDelay(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  getActionDelay(): number {
    return this.getRandomDelay(
      this.config.actionDelayMin,
      this.config.actionDelayMax
    ) * 1000;
  }

  getViewDuration(): number {
    return this.getRandomDelay(
      this.config.viewDurationMin,
      this.config.viewDurationMax
    ) * 1000;
  }

  getScrollDelay(): number {
    return this.getRandomDelay(
      this.config.scrollDelayMin,
      this.config.scrollDelayMax
    ) * 1000;
  }

  getTypingDelay(text: string): number {
    const baseWPM = this.config.typingSpeedWPM;
    const variance = this.config.typingVariance;
    const actualWPM = baseWPM + (Math.random() * variance * 2 - variance);

    const wordsCount = text.split(' ').length;
    const minutes = wordsCount / actualWPM;
    const milliseconds = minutes * 60 * 1000;

    return Math.floor(milliseconds);
  }

  async simulateTyping(text: string, onProgress?: (char: string) => void): Promise<void> {
    const characters = text.split('');
    const baseDelay = this.getTypingDelay(text) / characters.length;

    for (const char of characters) {
      await this.delay(baseDelay + Math.random() * 50);
      onProgress?.(char);
    }
  }

  async simulateReading(duration?: number): Promise<void> {
    const readTime = duration || this.getViewDuration();
    await this.delay(readTime);
  }

  async simulateScrolling(): Promise<void> {
    await this.delay(this.getScrollDelay());
  }

  async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  isWithinActiveHours(startHour: number, endHour: number, timezone: string = 'UTC'): boolean {
    const now = new Date();
    const hour = now.getHours();
    return hour >= startHour && hour <= endHour;
  }

  shouldTakeBreak(lastActionTime: Date, restFrequency: number): boolean {
    const now = new Date();
    const minutesSinceLastAction = (now.getTime() - lastActionTime.getTime()) / (1000 * 60);
    return minutesSinceLastAction >= restFrequency;
  }
}

export function calculateWarmupMultiplier(currentDay: number, totalDays: number = 7): number {
  if (currentDay >= totalDays) return 1.0;
  return currentDay / totalDays;
}

export function applyWarmupLimit(baseLimit: number, currentDay: number, totalDays: number = 7): number {
  const multiplier = calculateWarmupMultiplier(currentDay, totalDays);
  return Math.floor(baseLimit * multiplier);
}
