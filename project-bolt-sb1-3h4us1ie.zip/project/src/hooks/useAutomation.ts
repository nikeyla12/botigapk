import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { HumanBehaviorSimulator, applyWarmupLimit } from '../lib/human-behavior';

export interface AutomationSettings {
  id: string;
  instagram_account_id: string;
  enabled: boolean;
  active_hours_start: number;
  active_hours_end: number;
  timezone: string;
  typing_speed_wpm: number;
  typing_speed_variance: number;
  view_duration_min: number;
  view_duration_max: number;
  action_delay_min: number;
  action_delay_max: number;
  scroll_delay_min: number;
  scroll_delay_max: number;
  rest_duration_minutes: number;
  rest_frequency_minutes: number;
  daily_active_hours: number;
  warmup_enabled: boolean;
  warmup_duration_days: number;
  warmup_day_current: number;
  daily_story_views_limit: number;
  daily_likes_limit: number;
  daily_comments_limit: number;
  daily_follows_limit: number;
  daily_unfollows_limit: number;
  daily_dms_limit: number;
  unfollow_after_days: number;
  maintain_follow_ratio: boolean;
  max_follow_ratio: number;
  never_unfollow_followers: boolean;
  auto_pause_on_high_risk: boolean;
  risk_threshold: number;
}

export interface DailyLimitStatus {
  action_type: string;
  current_count: number;
  limit_count: number;
  percentage: number;
}

export function useAutomation(accountId: string | null) {
  const [settings, setSettings] = useState<AutomationSettings | null>(null);
  const [simulator, setSimulator] = useState<HumanBehaviorSimulator | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!accountId) {
      setLoading(false);
      return;
    }

    loadSettings();
  }, [accountId]);

  useEffect(() => {
    if (settings) {
      const sim = new HumanBehaviorSimulator({
        typingSpeedWPM: settings.typing_speed_wpm,
        typingVariance: settings.typing_speed_variance,
        viewDurationMin: settings.view_duration_min,
        viewDurationMax: settings.view_duration_max,
        actionDelayMin: settings.action_delay_min,
        actionDelayMax: settings.action_delay_max,
        scrollDelayMin: settings.scroll_delay_min,
        scrollDelayMax: settings.scroll_delay_max,
      });
      setSimulator(sim);
    }
  }, [settings]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('automation_settings')
        .select('*')
        .eq('instagram_account_id', accountId)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (data) {
        setSettings(data as AutomationSettings);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (updates: Partial<AutomationSettings>) => {
    if (!accountId || !settings) return;

    try {
      const { error: updateError } = await supabase
        .from('automation_settings')
        .update(updates)
        .eq('instagram_account_id', accountId);

      if (updateError) throw updateError;

      await loadSettings();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update settings');
      throw err;
    }
  };

  const getDailyLimits = async (): Promise<DailyLimitStatus[]> => {
    if (!accountId || !settings) return [];

    const today = new Date().toISOString().split('T')[0];

    try {
      const { data, error: fetchError } = await supabase
        .from('daily_action_limits')
        .select('*')
        .eq('instagram_account_id', accountId)
        .eq('date', today);

      if (fetchError) throw fetchError;

      const actionTypes = [
        { type: 'story_view', limit: settings.daily_story_views_limit },
        { type: 'like', limit: settings.daily_likes_limit },
        { type: 'comment', limit: settings.daily_comments_limit },
        { type: 'follow', limit: settings.daily_follows_limit },
        { type: 'unfollow', limit: settings.daily_unfollows_limit },
        { type: 'dm', limit: settings.daily_dms_limit },
      ];

      return actionTypes.map(({ type, limit }) => {
        const record = data?.find(d => d.action_type === type);
        const current = record?.current_count || 0;
        const adjustedLimit = settings.warmup_enabled
          ? applyWarmupLimit(limit, settings.warmup_day_current, settings.warmup_duration_days)
          : limit;

        return {
          action_type: type,
          current_count: current,
          limit_count: adjustedLimit,
          percentage: adjustedLimit > 0 ? (current / adjustedLimit) * 100 : 0,
        };
      });
    } catch (err) {
      console.error('Failed to get daily limits:', err);
      return [];
    }
  };

  const logAction = async (
    actionType: string,
    targetUsername?: string,
    targetUserId?: string,
    status: 'success' | 'failed' | 'blocked' | 'rate_limited' = 'success',
    errorMessage?: string
  ) => {
    if (!accountId) return;

    try {
      await supabase.from('action_logs').insert({
        instagram_account_id: accountId,
        action_type: actionType,
        target_username: targetUsername,
        target_user_id: targetUserId,
        status,
        error_message: errorMessage,
        executed_at: new Date().toISOString(),
      });

      await incrementDailyLimit(actionType);
    } catch (err) {
      console.error('Failed to log action:', err);
    }
  };

  const incrementDailyLimit = async (actionType: string) => {
    if (!accountId) return;

    const today = new Date().toISOString().split('T')[0];

    try {
      const { data: existing } = await supabase
        .from('daily_action_limits')
        .select('*')
        .eq('instagram_account_id', accountId)
        .eq('date', today)
        .eq('action_type', actionType)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('daily_action_limits')
          .update({
            current_count: existing.current_count + 1,
            last_action_at: new Date().toISOString(),
          })
          .eq('id', existing.id);
      } else {
        const limitMap: Record<string, number> = {
          story_view: settings?.daily_story_views_limit || 300,
          like: settings?.daily_likes_limit || 300,
          comment: settings?.daily_comments_limit || 30,
          follow: settings?.daily_follows_limit || 50,
          unfollow: settings?.daily_unfollows_limit || 50,
          dm: settings?.daily_dms_limit || 20,
        };

        await supabase.from('daily_action_limits').insert({
          instagram_account_id: accountId,
          date: today,
          action_type: actionType,
          current_count: 1,
          limit_count: limitMap[actionType] || 100,
          last_action_at: new Date().toISOString(),
        });
      }
    } catch (err) {
      console.error('Failed to increment daily limit:', err);
    }
  };

  const canPerformAction = async (actionType: string): Promise<boolean> => {
    const limits = await getDailyLimits();
    const actionLimit = limits.find(l => l.action_type === actionType);

    if (!actionLimit) return true;

    return actionLimit.current_count < actionLimit.limit_count;
  };

  return {
    settings,
    simulator,
    loading,
    error,
    updateSettings,
    getDailyLimits,
    logAction,
    canPerformAction,
    reload: loadSettings,
  };
}
