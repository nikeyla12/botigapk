import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { suggestHashtags } from '../lib/hashtag-suggester';

export function ContentScheduler() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [scheduledPosts, setScheduledPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showComposer, setShowComposer] = useState(false);
  const [view, setView] = useState<'calendar' | 'list'>('list');
  const [filter, setFilter] = useState<'all' | 'pending' | 'published' | 'failed'>('all');
  const [postForm, setPostForm] = useState({
    content_type: 'post',
    caption: '',
    media_urls: [] as string[],
    scheduled_time: '',
    hashtags: [] as string[],
    location: '',
    first_comment: '',
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadScheduledPosts();
    }
  }, [selectedAccountId, filter]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadScheduledPosts = async () => {
    let query = supabase
      .from('scheduled_content')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('scheduled_time', { ascending: true });

    if (filter !== 'all') {
      query = query.eq('status', filter);
    }

    const { data } = await query;
    setScheduledPosts(data || []);
  };

  const handleSuggestHashtags = async () => {
    if (!postForm.caption) {
      alert('Write some caption first!');
      return;
    }

    const suggested = suggestHashtags(postForm.caption);
    setPostForm({
      ...postForm,
      hashtags: [...new Set([...postForm.hashtags, ...suggested])],
    });
  };

  const handleSchedulePost = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedAccountId) {
      alert('Please select an account');
      return;
    }

    if (!postForm.scheduled_time) {
      alert('Please select a schedule time');
      return;
    }

    try {
      await supabase.from('scheduled_content').insert({
        instagram_account_id: selectedAccountId,
        ...postForm,
        status: 'pending',
      });

      setShowComposer(false);
      setPostForm({
        content_type: 'post',
        caption: '',
        media_urls: [],
        scheduled_time: '',
        hashtags: [],
        location: '',
        first_comment: '',
      });
      loadScheduledPosts();
      alert('Content scheduled successfully!');
    } catch (error) {
      console.error('Failed to schedule:', error);
      alert('Failed to schedule content');
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm('Delete this scheduled post?')) return;

    try {
      await supabase.from('scheduled_content').delete().eq('id', postId);
      loadScheduledPosts();
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleEditPost = (post: any) => {
    setPostForm({
      content_type: post.content_type,
      caption: post.caption || '',
      media_urls: post.media_urls || [],
      scheduled_time: post.scheduled_time,
      hashtags: post.hashtags || [],
      location: post.location || '',
      first_comment: post.first_comment || '',
    });
    setShowComposer(true);
  };

  const handleAddHashtag = (hashtag: string) => {
    if (hashtag && !postForm.hashtags.includes(hashtag)) {
      setPostForm({
        ...postForm,
        hashtags: [...postForm.hashtags, hashtag],
      });
    }
  };

  const handleRemoveHashtag = (hashtag: string) => {
    setPostForm({
      ...postForm,
      hashtags: postForm.hashtags.filter(h => h !== hashtag),
    });
  };

  const getBestPostingTimes = () => {
    return [
      { time: '09:00', label: 'Morning Rush (9 AM)', engagement: 'High' },
      { time: '12:00', label: 'Lunch Break (12 PM)', engagement: 'Very High' },
      { time: '15:00', label: 'Afternoon (3 PM)', engagement: 'Medium' },
      { time: '18:00', label: 'After Work (6 PM)', engagement: 'Very High' },
      { time: '21:00', label: 'Evening (9 PM)', engagement: 'High' },
    ];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-300';
      case 'published':
        return 'bg-green-500/20 text-green-300';
      case 'failed':
        return 'bg-red-500/20 text-red-300';
      default:
        return 'bg-gray-500/20 text-gray-300';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Content Scheduler</h1>
            </div>
            <button
              onClick={() => setShowComposer(true)}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition font-medium"
            >
              + Schedule Content
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <div className="flex gap-2">
                  <button
                    onClick={() => setView('list')}
                    className={`px-4 py-2 rounded-lg transition ${view === 'list' ? 'bg-white/20 text-white' : 'text-slate-300 hover:bg-white/10'}`}
                  >
                    List View
                  </button>
                  <button
                    onClick={() => setView('calendar')}
                    className={`px-4 py-2 rounded-lg transition ${view === 'calendar' ? 'bg-white/20 text-white' : 'text-slate-300 hover:bg-white/10'}`}
                  >
                    Calendar View
                  </button>
                </div>

                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as any)}
                  className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="all">All Posts</option>
                  <option value="pending">Pending</option>
                  <option value="published">Published</option>
                  <option value="failed">Failed</option>
                </select>
              </div>

              {scheduledPosts.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">📅</div>
                  <h3 className="text-xl font-semibold text-white mb-2">No Scheduled Content</h3>
                  <p className="text-slate-400 mb-6">Start by scheduling your first post, story, or reel!</p>
                  <button
                    onClick={() => setShowComposer(true)}
                    className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition"
                  >
                    Schedule First Content
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {scheduledPosts.map((post) => (
                    <div key={post.id} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition">
                      <div className="flex gap-4">
                        <div className="flex-shrink-0">
                          <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                            {post.content_type === 'post' && <span className="text-2xl">📷</span>}
                            {post.content_type === 'story' && <span className="text-2xl">📱</span>}
                            {post.content_type === 'reel' && <span className="text-2xl">🎬</span>}
                          </div>
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <span className={`text-xs px-2 py-1 rounded ${getStatusColor(post.status)}`}>
                                {post.status}
                              </span>
                              <span className="text-sm text-slate-400">
                                {post.content_type.charAt(0).toUpperCase() + post.content_type.slice(1)}
                              </span>
                            </div>
                            <div className="flex gap-2">
                              {post.status === 'pending' && (
                                <button
                                  onClick={() => handleEditPost(post)}
                                  className="text-blue-400 hover:text-blue-300 text-sm"
                                >
                                  Edit
                                </button>
                              )}
                              <button
                                onClick={() => handleDeletePost(post.id)}
                                className="text-red-400 hover:text-red-300 text-sm"
                              >
                                Delete
                              </button>
                            </div>
                          </div>

                          <p className="text-white mb-2 line-clamp-2">{post.caption}</p>

                          {post.hashtags && post.hashtags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-2">
                              {post.hashtags.slice(0, 5).map((tag: string, idx: number) => (
                                <span key={idx} className="text-xs text-blue-400">
                                  #{tag}
                                </span>
                              ))}
                              {post.hashtags.length > 5 && (
                                <span className="text-xs text-slate-400">
                                  +{post.hashtags.length - 5} more
                                </span>
                              )}
                            </div>
                          )}

                          <div className="flex items-center gap-4 text-xs text-slate-400">
                            <span>📅 {new Date(post.scheduled_time).toLocaleString()}</span>
                            {post.location && <span>📍 {post.location}</span>}
                            {post.media_urls && post.media_urls.length > 0 && (
                              <span>🖼️ {post.media_urls.length} media</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Queue Summary</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Total Scheduled</span>
                  <span className="text-white font-semibold">
                    {scheduledPosts.filter(p => p.status === 'pending').length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Posts</span>
                  <span className="text-white font-semibold">
                    {scheduledPosts.filter(p => p.content_type === 'post' && p.status === 'pending').length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Stories</span>
                  <span className="text-white font-semibold">
                    {scheduledPosts.filter(p => p.content_type === 'story' && p.status === 'pending').length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Reels</span>
                  <span className="text-white font-semibold">
                    {scheduledPosts.filter(p => p.content_type === 'reel' && p.status === 'pending').length}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">📊 Best Posting Times</h3>
              <div className="space-y-3">
                {getBestPostingTimes().map((time, idx) => (
                  <div key={idx} className="flex justify-between items-center text-sm">
                    <span className="text-white">{time.label}</span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      time.engagement === 'Very High' ? 'bg-green-500/20 text-green-300' :
                      time.engagement === 'High' ? 'bg-blue-500/20 text-blue-300' :
                      'bg-yellow-500/20 text-yellow-300'
                    }`}>
                      {time.engagement}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-cyan-500/20 border border-cyan-500/50 rounded-xl p-4">
              <div className="text-cyan-300 font-semibold mb-2">💡 Pro Tips</div>
              <ul className="text-xs text-cyan-200 space-y-1">
                <li>• Post consistently 3-7x per week</li>
                <li>• Use 20-30 relevant hashtags</li>
                <li>• Schedule at peak engagement times</li>
                <li>• Mix content types (posts/reels/stories)</li>
                <li>• Add location tags for local reach</li>
                <li>• First comment with extra hashtags</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {showComposer && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-slate-800 rounded-xl p-6 max-w-2xl w-full border border-white/20 my-8">
            <h2 className="text-xl font-bold text-white mb-6">Schedule Content</h2>

            <form onSubmit={handleSchedulePost} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Content Type *
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {['post', 'story', 'reel'].map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setPostForm({ ...postForm, content_type: type })}
                      className={`p-4 rounded-lg border-2 transition ${
                        postForm.content_type === type
                          ? 'border-purple-500 bg-purple-500/20'
                          : 'border-white/20 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="text-2xl mb-1">
                        {type === 'post' && '📷'}
                        {type === 'story' && '📱'}
                        {type === 'reel' && '🎬'}
                      </div>
                      <div className="text-white font-medium capitalize">{type}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Caption *
                </label>
                <textarea
                  required
                  value={postForm.caption}
                  onChange={(e) => setPostForm({ ...postForm, caption: e.target.value })}
                  rows={6}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Write your caption here... ✨"
                />
                <div className="flex justify-between items-center mt-1">
                  <span className="text-xs text-slate-400">
                    {postForm.caption.length} / 2200 characters
                  </span>
                  <button
                    type="button"
                    onClick={handleSuggestHashtags}
                    className="text-xs text-purple-400 hover:text-purple-300"
                  >
                    🤖 Suggest Hashtags
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Hashtags
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {postForm.hashtags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm flex items-center gap-2"
                    >
                      #{tag}
                      <button
                        type="button"
                        onClick={() => handleRemoveHashtag(tag)}
                        className="hover:text-red-300"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
                <input
                  type="text"
                  placeholder="Add hashtag (without #)"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const input = e.target as HTMLInputElement;
                      handleAddHashtag(input.value);
                      input.value = '';
                    }
                  }}
                />
                <p className="text-xs text-slate-400 mt-1">
                  Press Enter to add. {postForm.hashtags.length}/30 hashtags
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Schedule Time *
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={postForm.scheduled_time}
                    onChange={(e) => setPostForm({ ...postForm, scheduled_time: e.target.value })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Location (Optional)
                  </label>
                  <input
                    type="text"
                    value={postForm.location}
                    onChange={(e) => setPostForm({ ...postForm, location: e.target.value })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                    placeholder="Add location"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  First Comment (Optional)
                </label>
                <textarea
                  value={postForm.first_comment}
                  onChange={(e) => setPostForm({ ...postForm, first_comment: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Add extra hashtags or CTA as first comment..."
                />
                <p className="text-xs text-slate-400 mt-1">
                  Pro tip: Add extra hashtags here to keep caption clean
                </p>
              </div>

              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-3">
                <p className="text-xs text-yellow-200">
                  <strong>Note:</strong> Media files will be uploaded when you publish. Make sure to have images/videos ready!
                </p>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowComposer(false);
                    setPostForm({
                      content_type: 'post',
                      caption: '',
                      media_urls: [],
                      scheduled_time: '',
                      hashtags: [],
                      location: '',
                      first_comment: '',
                    });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition"
                >
                  Schedule Content
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
