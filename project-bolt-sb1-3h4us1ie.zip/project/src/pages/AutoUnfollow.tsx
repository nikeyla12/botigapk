import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAutomation } from '../hooks/useAutomation';

export function AutoUnfollow() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [settings, setSettings] = useState<any>(null);
  const [unfollows, setUnfollows] = useState<any[]>([]);
  const [whitelist, setWhitelist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { getDailyLimits } = useAutomation(selectedAccountId || null);
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [showWhitelistModal, setShowWhitelistModal] = useState(false);
  const [whitelistUsername, setWhitelistUsername] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadSettings();
      loadUnfollows();
      loadWhitelist();
      loadDailyStats();
    }
  }, [selectedAccountId]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from('auto_unfollow_settings')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .maybeSingle();

    setSettings(data || {
      enabled: false,
      unfollow_mode: 'non_followers',
      days_to_wait: 7,
      keep_recent_follows: true,
      recent_follows_days: 3,
      respect_whitelist: true,
      check_engagement: false,
      min_engagement_threshold: 2,
      daily_limit: 50,
      maintain_follow_ratio: true,
      target_follow_ratio: 1.0,
    });
  };

  const loadUnfollows = async () => {
    const { data } = await supabase
      .from('unfollows')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('unfollowed_at', { ascending: false })
      .limit(50);

    setUnfollows(data || []);
  };

  const loadWhitelist = async () => {
    const { data } = await supabase
      .from('unfollow_whitelist')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('created_at', { ascending: false });

    setWhitelist(data || []);
  };

  const loadDailyStats = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    const unfollowLimit = limits.find(l => l.action_type === 'unfollow');
    setDailyStats(unfollowLimit);
  };

  const handleSave = async () => {
    if (!selectedAccountId) return;

    setSaving(true);

    try {
      const { data: existing } = await supabase
        .from('auto_unfollow_settings')
        .select('id')
        .eq('instagram_account_id', selectedAccountId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('auto_unfollow_settings')
          .update(settings)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('auto_unfollow_settings')
          .insert({ ...settings, instagram_account_id: selectedAccountId });
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleAddToWhitelist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!whitelistUsername.trim()) return;

    try {
      await supabase
        .from('unfollow_whitelist')
        .insert({
          instagram_account_id: selectedAccountId,
          username: whitelistUsername.trim(),
        });

      setWhitelistUsername('');
      setShowWhitelistModal(false);
      loadWhitelist();
    } catch (error) {
      console.error('Failed to add to whitelist:', error);
      alert('Failed to add to whitelist');
    }
  };

  const handleRemoveFromWhitelist = async (whitelistId: string) => {
    if (!confirm('Remove from whitelist?')) return;

    try {
      await supabase.from('unfollow_whitelist').delete().eq('id', whitelistId);
      loadWhitelist();
    } catch (error) {
      console.error('Failed to remove:', error);
    }
  };

  const handleChange = (field: string, value: any) => {
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Auto Unfollow</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">Auto Unfollow Settings</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <span className="text-slate-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Unfollow Mode
                  </label>
                  <select
                    value={settings?.unfollow_mode || 'non_followers'}
                    onChange={(e) => handleChange('unfollow_mode', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="non_followers">Non-Followers (Not following back)</option>
                    <option value="all_old">All Old Follows</option>
                    <option value="low_engagement">Low Engagement Only</option>
                    <option value="ghost_accounts">Ghost Accounts (Inactive)</option>
                  </select>
                  <p className="text-xs text-slate-400 mt-1">
                    {settings?.unfollow_mode === 'non_followers' && 'Unfollow users who don\'t follow you back'}
                    {settings?.unfollow_mode === 'all_old' && 'Unfollow all users you followed X days ago'}
                    {settings?.unfollow_mode === 'low_engagement' && 'Unfollow users with low engagement on your posts'}
                    {settings?.unfollow_mode === 'ghost_accounts' && 'Unfollow inactive accounts (no posts in 30+ days)'}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Days to Wait Before Unfollowing
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="90"
                    value={settings?.days_to_wait || 7}
                    onChange={(e) => handleChange('days_to_wait', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Only unfollow users you followed at least this many days ago
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Daily Unfollow Limit
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="200"
                    value={settings?.daily_limit || 50}
                    onChange={(e) => handleChange('daily_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Recommended: 30-100 unfollows per day to avoid detection
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.keep_recent_follows || false}
                      onChange={(e) => handleChange('keep_recent_follows', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Keep recent follows (Don't unfollow too soon)</span>
                  </label>

                  {settings?.keep_recent_follows && (
                    <div className="pl-8">
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Recent Follows Period (days)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="30"
                        value={settings?.recent_follows_days || 3}
                        onChange={(e) => handleChange('recent_follows_days', parseInt(e.target.value))}
                        className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      />
                      <p className="text-xs text-slate-400 mt-1">
                        Never unfollow users you followed in the last X days
                      </p>
                    </div>
                  )}

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.respect_whitelist || false}
                      onChange={(e) => handleChange('respect_whitelist', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Respect whitelist (Never unfollow whitelist users)</span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.maintain_follow_ratio || false}
                      onChange={(e) => handleChange('maintain_follow_ratio', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Maintain follow ratio (Auto-balance following/followers)</span>
                  </label>

                  {settings?.maintain_follow_ratio && (
                    <div className="pl-8">
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Target Follow Ratio
                      </label>
                      <input
                        type="number"
                        min="0.5"
                        max="2"
                        step="0.1"
                        value={settings?.target_follow_ratio || 1.0}
                        onChange={(e) => handleChange('target_follow_ratio', parseFloat(e.target.value))}
                        className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      />
                      <p className="text-xs text-slate-400 mt-1">
                        1.0 = Equal followers and following, 0.8 = Follow 80% of your followers
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">Whitelist</h2>
                <button
                  onClick={() => setShowWhitelistModal(true)}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition text-sm"
                >
                  + Add to Whitelist
                </button>
              </div>

              <p className="text-sm text-slate-400 mb-4">
                Users in whitelist will NEVER be unfollowed automatically.
              </p>

              {whitelist.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  No whitelist entries yet. Add important accounts you never want to unfollow!
                </div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {whitelist.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <span className="text-white">@{item.username}</span>
                      <button
                        onClick={() => handleRemoveFromWhitelist(item.id)}
                        className="text-red-400 hover:text-red-300 text-sm"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              {dailyStats ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300">Unfollowed</span>
                    <span className="text-white font-semibold">
                      {dailyStats.current_count} / {dailyStats.limit_count}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-orange-500 to-red-500 rounded-full transition-all"
                      style={{ width: `${Math.min(dailyStats.percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    {dailyStats.percentage.toFixed(1)}% of daily limit used
                  </p>
                </div>
              ) : (
                <p className="text-slate-400">No data available</p>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Recent Unfollows</h3>
              {unfollows.length === 0 ? (
                <p className="text-slate-400 text-center py-4">No unfollows yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {unfollows.map((unfollow) => (
                    <div key={unfollow.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="text-white font-medium mb-1">@{unfollow.target_username}</div>
                      <div className="text-xs text-slate-400 mb-1">
                        Reason: {unfollow.reason || 'Not following back'}
                      </div>
                      <div className="text-xs text-slate-400">
                        {new Date(unfollow.unfollowed_at).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-xl p-4">
              <div className="text-yellow-300 font-semibold mb-2">⚠️ Important Tips</div>
              <ul className="text-xs text-yellow-200 space-y-1">
                <li>• Don't unfollow too quickly after following</li>
                <li>• Keep important accounts in whitelist</li>
                <li>• Maintain healthy follow ratio (under 1.5)</li>
                <li>• Start slow and increase gradually</li>
                <li>• Balance follows with unfollows</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {showWhitelistModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">Add to Whitelist</h2>

            <form onSubmit={handleAddToWhitelist} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Instagram Username
                </label>
                <input
                  type="text"
                  required
                  value={whitelistUsername}
                  onChange={(e) => setWhitelistUsername(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="username (without @)"
                />
                <p className="text-xs text-slate-400 mt-1">
                  This user will never be unfollowed automatically
                </p>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowWhitelistModal(false);
                    setWhitelistUsername('');
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition"
                >
                  Add to Whitelist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
