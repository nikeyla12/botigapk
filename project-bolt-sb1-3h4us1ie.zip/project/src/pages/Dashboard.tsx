import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { useAutomation } from '../hooks/useAutomation';

interface InstagramAccount {
  id: string;
  username: string;
  is_active: boolean;
  follower_count: number;
  following_count: number;
  created_at: string;
}

interface Analytics {
  total_messages: number;
  total_replies: number;
  stories_viewed: number;
  posts_liked: number;
  date: string;
}

interface Message {
  id: string;
  sender_username: string;
  message_text: string;
  reply_text: string | null;
  status: string;
  received_at: string;
}

export function Dashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<InstagramAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState<Analytics[]>([]);
  const [recentMessages, setRecentMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const { getDailyLimits } = useAutomation(selectedAccount);
  const [dailyLimits, setDailyLimits] = useState<any[]>([]);

  useEffect(() => {
    fetchData();
  }, [user]);

  useEffect(() => {
    if (selectedAccount && getDailyLimits) {
      loadDailyLimits();
    }
  }, [selectedAccount, getDailyLimits]);

  useEffect(() => {
    if (accounts.length > 0 && !selectedAccount) {
      setSelectedAccount(accounts[0].id);
    }
  }, [accounts]);

  const loadDailyLimits = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    setDailyLimits(limits);
  };

  const fetchData = async () => {
    if (!user) return;

    try {
      const [accountsRes, analyticsRes, messagesRes] = await Promise.all([
        supabase
          .from('instagram_accounts')
          .select('*')
          .order('created_at', { ascending: false }),
        supabase
          .from('analytics')
          .select('*')
          .order('date', { ascending: false })
          .limit(7),
        supabase
          .from('messages')
          .select('*')
          .order('received_at', { ascending: false })
          .limit(10),
      ]);

      if (accountsRes.data) setAccounts(accountsRes.data as any);
      if (analyticsRes.data) setAnalytics(analyticsRes.data as any);
      if (messagesRes.data) setRecentMessages(messagesRes.data as any);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const totalMessages = analytics.reduce((sum, a) => sum + a.total_messages, 0);
  const totalReplies = analytics.reduce((sum, a) => sum + a.total_replies, 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-bold text-white">Instagram Auto-Reply Bot</h1>
            <div className="flex items-center gap-4">
              <span className="text-slate-300">{user?.email}</span>
              <button
                onClick={handleSignOut}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-slate-400 text-sm mb-2">Total Accounts</div>
            <div className="text-3xl font-bold text-white">{accounts.length}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-slate-400 text-sm mb-2">Messages (7 days)</div>
            <div className="text-3xl font-bold text-white">{totalMessages}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-slate-400 text-sm mb-2">Replies Sent (7 days)</div>
            <div className="text-3xl font-bold text-white">{totalReplies}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-white">Instagram Accounts</h2>
              <button
                onClick={() => navigate('/accounts')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition text-sm"
              >
                Manage
              </button>
            </div>
            {accounts.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                No accounts connected yet. Add your first account to get started.
              </div>
            ) : (
              <div className="space-y-3">
                {accounts.map((account) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-3 bg-white/5 rounded-lg"
                  >
                    <div>
                      <div className="text-white font-medium">@{account.username}</div>
                      <div className="text-sm text-slate-400">
                        {account.is_active ? 'Active' : 'Inactive'}
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${account.is_active ? 'bg-green-500' : 'bg-gray-500'}`} />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-white">Recent Messages</h2>
              <button
                onClick={() => navigate('/messages')}
                className="text-blue-400 hover:text-blue-300 text-sm transition"
              >
                View All
              </button>
            </div>
            {recentMessages.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                No messages yet. Messages will appear here once you start receiving them.
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {recentMessages.map((message) => (
                  <div
                    key={message.id}
                    className="p-3 bg-white/5 rounded-lg"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="text-white font-medium">@{message.sender_username}</div>
                      <span className={`text-xs px-2 py-1 rounded ${
                        message.status === 'replied' ? 'bg-green-500/20 text-green-300' :
                        message.status === 'failed' ? 'bg-red-500/20 text-red-300' :
                        'bg-blue-500/20 text-blue-300'
                      }`}>
                        {message.status}
                      </span>
                    </div>
                    <div className="text-sm text-slate-300 mb-2">{message.message_text}</div>
                    {message.reply_text && (
                      <div className="text-sm text-slate-400 pl-3 border-l-2 border-blue-500/50">
                        {message.reply_text}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
