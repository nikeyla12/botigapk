import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  analyzeHashtagPerformance,
  getHashtagScore,
  getHashtagsByCategory,
  getMixedHashtags,
  generateHashtagStrategy,
  getBestHashtagCombos,
  categoryList,
} from '../lib/hashtag-suggester';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function HashtagAnalyzer() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [savedGroups, setSavedGroups] = useState<any[]>([]);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupForm, setGroupForm] = useState({ name: '', hashtags: [] as string[] });
  const [analyzing, setAnalyzing] = useState(false);

  const handleSearch = () => {
    if (!searchQuery.trim()) return;

    setAnalyzing(true);
    const hashtag = searchQuery.replace('#', '').trim().toLowerCase();

    const performance = analyzeHashtagPerformance(hashtag);
    const score = getHashtagScore(hashtag);

    const result = {
      tag: hashtag,
      ...performance,
      ...score,
    };

    setSearchResults([result, ...searchResults.slice(0, 19)]);
    setSearchQuery('');
    setAnalyzing(false);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    const tags = getHashtagsByCategory(category);
    const analyzed = tags.slice(0, 20).map(tag => ({
      tag,
      ...analyzeHashtagPerformance(tag),
      ...getHashtagScore(tag),
    }));
    setSearchResults(analyzed);
  };

  const handleGenerateStrategy = () => {
    if (!selectedCategory) {
      alert('Please select a category first!');
      return;
    }

    const strategy = generateHashtagStrategy(selectedCategory);
    const allTags = [...strategy.broad, ...strategy.medium, ...strategy.niche];

    const analyzed = allTags.map(tag => ({
      tag,
      tier: strategy.broad.includes(tag) ? 'Broad' : strategy.medium.includes(tag) ? 'Medium' : 'Niche',
      ...analyzeHashtagPerformance(tag),
      ...getHashtagScore(tag),
    }));

    setSearchResults(analyzed);
  };

  const handleGetBestCombos = () => {
    if (!selectedCategory) {
      alert('Please select a category first!');
      return;
    }

    const combos = getBestHashtagCombos(selectedCategory);
    const combo = combos[0];

    const analyzed = combo.slice(0, 30).map(tag => ({
      tag,
      ...analyzeHashtagPerformance(tag),
      ...getHashtagScore(tag),
    }));

    setSearchResults(analyzed);
  };

  const handleSaveGroup = async () => {
    if (!groupForm.name.trim() || groupForm.hashtags.length === 0) {
      alert('Please enter group name and add hashtags!');
      return;
    }

    try {
      await supabase.from('hashtag_groups').insert({
        user_id: user?.id,
        name: groupForm.name,
        hashtags: groupForm.hashtags,
      });

      setShowGroupModal(false);
      setGroupForm({ name: '', hashtags: [] });
      loadSavedGroups();
      alert('Hashtag group saved!');
    } catch (error) {
      console.error('Failed to save group:', error);
      alert('Failed to save group');
    }
  };

  const loadSavedGroups = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('hashtag_groups')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    setSavedGroups(data || []);
  };

  const handleDeleteGroup = async (groupId: string) => {
    if (!confirm('Delete this hashtag group?')) return;

    try {
      await supabase.from('hashtag_groups').delete().eq('id', groupId);
      loadSavedGroups();
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleCopyHashtags = (hashtags: string[]) => {
    const text = hashtags.map(h => `#${h}`).join(' ');
    navigator.clipboard.writeText(text);
    alert('Hashtags copied to clipboard!');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-500/20 text-green-300';
      case 'medium':
        return 'bg-yellow-500/20 text-yellow-300';
      case 'hard':
        return 'bg-red-500/20 text-red-300';
      default:
        return 'bg-gray-500/20 text-gray-300';
    }
  };

  const getReachColor = (reach: string) => {
    switch (reach) {
      case 'very high':
        return 'text-purple-400';
      case 'high':
        return 'text-blue-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Hashtag Analyzer</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold text-white mb-4">Search & Analyze Hashtags</h2>

              <div className="flex gap-3 mb-4">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Enter hashtag (e.g., fashion, fitness)"
                  className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-slate-400"
                />
                <button
                  onClick={handleSearch}
                  disabled={analyzing}
                  className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {analyzing ? 'Analyzing...' : 'Analyze'}
                </button>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Or select a category
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {categoryList.map((category) => (
                    <button
                      key={category}
                      onClick={() => handleCategorySelect(category)}
                      className={`px-3 py-2 rounded-lg text-sm transition ${
                        selectedCategory === category
                          ? 'bg-blue-600 text-white'
                          : 'bg-white/10 text-slate-300 hover:bg-white/20'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleGenerateStrategy}
                  className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition"
                >
                  Generate Strategy
                </button>
                <button
                  onClick={handleGetBestCombos}
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition"
                >
                  Best Combo (30)
                </button>
                <button
                  onClick={() => {
                    if (searchResults.length > 0) {
                      setGroupForm({ name: selectedCategory || 'My Group', hashtags: searchResults.map(r => r.tag) });
                      setShowGroupModal(true);
                    }
                  }}
                  className="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm transition"
                >
                  Save as Group
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">Analysis Results</h2>
                {searchResults.length > 0 && (
                  <button
                    onClick={() => handleCopyHashtags(searchResults.map(r => r.tag))}
                    className="text-sm text-cyan-400 hover:text-cyan-300"
                  >
                    📋 Copy All
                  </button>
                )}
              </div>

              {searchResults.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-xl font-semibold text-white mb-2">No Results Yet</h3>
                  <p className="text-slate-400">Search for hashtags or select a category to analyze</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {searchResults.map((result, idx) => (
                    <div key={idx} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="text-lg font-semibold text-blue-400">#{result.tag}</span>
                            {result.tier && (
                              <span className="text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded">
                                {result.tier}
                              </span>
                            )}
                            <span className={`text-xs px-2 py-1 rounded ${getDifficultyColor(result.difficulty)}`}>
                              {result.difficulty}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mb-2">
                            <div>
                              <div className="text-xs text-slate-400">Estimated Posts</div>
                              <div className="text-sm text-white font-medium">{result.estimatedPosts}</div>
                            </div>
                            <div>
                              <div className="text-xs text-slate-400">Competition</div>
                              <div className={`text-sm font-medium ${
                                result.competition === 'low' ? 'text-green-400' :
                                result.competition === 'medium' ? 'text-yellow-400' :
                                'text-red-400'
                              }`}>
                                {result.competition}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-slate-400">Reach Potential</div>
                              <div className={`text-sm font-medium ${getReachColor(result.reach)}`}>
                                {result.reach}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-slate-400">Recommended</div>
                              <div className={`text-sm font-medium ${result.recommended ? 'text-green-400' : 'text-red-400'}`}>
                                {result.recommended ? 'Yes ✓' : 'No ✗'}
                              </div>
                            </div>
                          </div>

                          <div className="text-xs text-slate-300 bg-white/5 rounded p-2">
                            💡 {result.recommendation}
                          </div>
                        </div>

                        <button
                          onClick={() => handleCopyHashtags([result.tag])}
                          className="ml-4 text-cyan-400 hover:text-cyan-300 text-sm"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Difficulty Guide</h3>
              <div className="space-y-3">
                <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <div className="text-green-300 font-semibold mb-1">Easy</div>
                  <div className="text-xs text-green-200">
                    Low competition. Best chance to rank and get discovered!
                  </div>
                </div>

                <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                  <div className="text-yellow-300 font-semibold mb-1">Medium</div>
                  <div className="text-xs text-yellow-200">
                    Balanced competition. Good reach with decent ranking chance.
                  </div>
                </div>

                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <div className="text-red-300 font-semibold mb-1">Hard</div>
                  <div className="text-xs text-red-200">
                    Very competitive. Massive reach but hard to rank. Use 1-2 max.
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Saved Groups</h3>
              {savedGroups.length === 0 ? (
                <p className="text-slate-400 text-sm text-center py-4">
                  No saved groups yet. Save your favorite hashtag sets!
                </p>
              ) : (
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {savedGroups.map((group) => (
                    <div key={group.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-medium text-white">{group.name}</div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleCopyHashtags(group.hashtags)}
                            className="text-xs text-cyan-400 hover:text-cyan-300"
                          >
                            Copy
                          </button>
                          <button
                            onClick={() => handleDeleteGroup(group.id)}
                            className="text-xs text-red-400 hover:text-red-300"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                      <div className="text-xs text-slate-400">
                        {group.hashtags.length} hashtags
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/50 rounded-xl p-4">
              <h3 className="text-lg font-semibold text-white mb-3">Pro Strategy</h3>
              <div className="space-y-2 text-sm text-cyan-100">
                <div className="flex items-start gap-2">
                  <span className="text-cyan-400">5x</span>
                  <span>Broad hashtags (1M+ posts)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-cyan-400">15x</span>
                  <span>Medium hashtags (100K-1M)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-cyan-400">10x</span>
                  <span>Niche hashtags (10K-100K)</span>
                </div>
                <div className="text-xs text-cyan-200 mt-3 pt-3 border-t border-cyan-500/30">
                  This 5-15-10 formula gives you the best balance of reach and discoverability!
                </div>
              </div>
            </div>

            <div className="bg-orange-500/20 border border-orange-500/50 rounded-xl p-4">
              <div className="text-orange-300 font-semibold mb-2">💡 Quick Tips</div>
              <ul className="text-xs text-orange-200 space-y-1">
                <li>• Change hashtags for every post</li>
                <li>• Mix different difficulty levels</li>
                <li>• Focus on niche hashtags first</li>
                <li>• Avoid banned hashtags</li>
                <li>• Research before using</li>
                <li>• Track which hashtags work</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {showGroupModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-lg w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">Save Hashtag Group</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Group Name *
                </label>
                <input
                  type="text"
                  required
                  value={groupForm.name}
                  onChange={(e) => setGroupForm({ ...groupForm, name: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="e.g., Fashion Summer 2024"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Hashtags ({groupForm.hashtags.length})
                </label>
                <div className="p-4 bg-white/5 rounded-lg max-h-48 overflow-y-auto">
                  <div className="flex flex-wrap gap-2">
                    {groupForm.hashtags.map((tag, idx) => (
                      <span key={idx} className="text-xs px-2 py-1 bg-blue-500/20 text-blue-300 rounded">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  onClick={() => {
                    setShowGroupModal(false);
                    setGroupForm({ name: '', hashtags: [] });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveGroup}
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
                >
                  Save Group
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
