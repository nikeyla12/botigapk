import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAutomation } from '../hooks/useAutomation';
import { personalizeDM } from '../lib/dm-personalizer';

export function DMAutomation() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [settings, setSettings] = useState<any>(null);
  const [templates, setTemplates] = useState<any[]>([]);
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [dmHistory, setDmHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { getDailyLimits } = useAutomation(selectedAccountId || null);
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);
  const [templateForm, setTemplateForm] = useState({ name: '', message: '', category: '' });
  const [campaignForm, setCampaignForm] = useState({
    name: '',
    campaign_type: 'welcome',
    template_id: '',
    target_type: 'new_followers',
    target_usernames: [],
    delay_minutes: 5,
    daily_limit: 50,
    enabled: true,
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadSettings();
      loadTemplates();
      loadCampaigns();
      loadDmHistory();
      loadDailyStats();
    }
  }, [selectedAccountId]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from('dm_automation_settings')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .maybeSingle();

    setSettings(data || {
      enabled: false,
      welcome_dm_enabled: true,
      auto_reply_enabled: false,
      use_ai_replies: false,
      daily_dm_limit: 50,
      delay_between_dms: 5,
      personalization_enabled: true,
    });
  };

  const loadTemplates = async () => {
    const { data } = await supabase
      .from('dm_templates')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('created_at', { ascending: false });

    setTemplates(data || []);
  };

  const loadCampaigns = async () => {
    const { data } = await supabase
      .from('dm_campaigns')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('created_at', { ascending: false });

    setCampaigns(data || []);
  };

  const loadDmHistory = async () => {
    const { data } = await supabase
      .from('dm_history')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('sent_at', { ascending: false })
      .limit(50);

    setDmHistory(data || []);
  };

  const loadDailyStats = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    const dmLimit = limits.find(l => l.action_type === 'dm');
    setDailyStats(dmLimit);
  };

  const handleSaveSettings = async () => {
    if (!selectedAccountId) return;

    setSaving(true);

    try {
      const { data: existing } = await supabase
        .from('dm_automation_settings')
        .select('id')
        .eq('instagram_account_id', selectedAccountId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('dm_automation_settings')
          .update(settings)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('dm_automation_settings')
          .insert({ ...settings, instagram_account_id: selectedAccountId });
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingTemplate) {
        await supabase
          .from('dm_templates')
          .update(templateForm)
          .eq('id', editingTemplate.id);
      } else {
        await supabase
          .from('dm_templates')
          .insert({ ...templateForm, instagram_account_id: selectedAccountId });
      }

      setShowTemplateModal(false);
      setEditingTemplate(null);
      setTemplateForm({ name: '', message: '', category: '' });
      loadTemplates();
    } catch (error) {
      console.error('Failed to save template:', error);
      alert('Failed to save template');
    }
  };

  const handleSaveCampaign = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await supabase
        .from('dm_campaigns')
        .insert({ ...campaignForm, instagram_account_id: selectedAccountId });

      setShowCampaignModal(false);
      setCampaignForm({
        name: '',
        campaign_type: 'welcome',
        template_id: '',
        target_type: 'new_followers',
        target_usernames: [],
        delay_minutes: 5,
        daily_limit: 50,
        enabled: true,
      });
      loadCampaigns();
    } catch (error) {
      console.error('Failed to save campaign:', error);
      alert('Failed to save campaign');
    }
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Delete this template?')) return;

    try {
      await supabase.from('dm_templates').delete().eq('id', templateId);
      loadTemplates();
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleToggleCampaign = async (campaignId: string, enabled: boolean) => {
    try {
      await supabase
        .from('dm_campaigns')
        .update({ enabled })
        .eq('id', campaignId);
      loadCampaigns();
    } catch (error) {
      console.error('Failed to update campaign:', error);
    }
  };

  const handleDeleteCampaign = async (campaignId: string) => {
    if (!confirm('Delete this campaign?')) return;

    try {
      await supabase.from('dm_campaigns').delete().eq('id', campaignId);
      loadCampaigns();
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleChange = (field: string, value: any) => {
    setSettings({ ...settings, [field]: value });
  };

  const handlePreviewTemplate = (template: any) => {
    const preview = personalizeDM(template.message, {
      username: 'john_doe',
      fullName: 'John Doe',
      accountUsername: 'your_account',
    });
    alert(`Preview:\n\n${preview}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">DM Automation</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">DM Automation Settings</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <span className="text-slate-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                </label>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Daily DM Limit
                    </label>
                    <input
                      type="number"
                      min="10"
                      max="100"
                      value={settings?.daily_dm_limit || 50}
                      onChange={(e) => handleChange('daily_dm_limit', parseInt(e.target.value))}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Recommended: 30-50 DMs/day
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Delay Between DMs (minutes)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="60"
                      value={settings?.delay_between_dms || 5}
                      onChange={(e) => handleChange('delay_between_dms', parseInt(e.target.value))}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Delay to look human
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                    <input
                      type="checkbox"
                      checked={settings?.welcome_dm_enabled || false}
                      onChange={(e) => handleChange('welcome_dm_enabled', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <div>
                      <div className="text-white font-medium">Welcome DM for New Followers</div>
                      <div className="text-xs text-slate-400">Send automatic DM when someone follows you</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                    <input
                      type="checkbox"
                      checked={settings?.auto_reply_enabled || false}
                      onChange={(e) => handleChange('auto_reply_enabled', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <div>
                      <div className="text-white font-medium">Auto Reply to DMs</div>
                      <div className="text-xs text-slate-400">Automatically respond to incoming messages</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                    <input
                      type="checkbox"
                      checked={settings?.personalization_enabled || false}
                      onChange={(e) => handleChange('personalization_enabled', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <div>
                      <div className="text-white font-medium">Message Personalization</div>
                      <div className="text-xs text-slate-400">Use variables like [username], [name]</div>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                    <input
                      type="checkbox"
                      checked={settings?.use_ai_replies || false}
                      onChange={(e) => handleChange('use_ai_replies', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <div>
                      <div className="text-white font-medium">AI-Powered Replies (Premium)</div>
                      <div className="text-xs text-slate-400">Smart context-aware responses</div>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={handleSaveSettings}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">DM Templates</h2>
                <button
                  onClick={() => {
                    setEditingTemplate(null);
                    setTemplateForm({ name: '', message: '', category: '' });
                    setShowTemplateModal(true);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition text-sm"
                >
                  + Add Template
                </button>
              </div>

              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-3 mb-4">
                <p className="text-xs text-yellow-200">
                  <strong>Variables:</strong> [username], [name], [account] will be replaced automatically
                </p>
              </div>

              {templates.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  No templates yet. Create your first DM template!
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {templates.map((template) => (
                    <div key={template.id} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="text-white font-medium mb-1">{template.name}</div>
                          <p className="text-slate-300 text-sm mb-2">{template.message}</p>
                          {template.category && (
                            <span className="text-xs text-slate-400">#{template.category}</span>
                          )}
                        </div>
                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => handlePreviewTemplate(template)}
                            className="text-cyan-400 hover:text-cyan-300 text-sm"
                          >
                            Preview
                          </button>
                          <button
                            onClick={() => {
                              setEditingTemplate(template);
                              setTemplateForm({
                                name: template.name,
                                message: template.message,
                                category: template.category || '',
                              });
                              setShowTemplateModal(true);
                            }}
                            className="text-blue-400 hover:text-blue-300 text-sm"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteTemplate(template.id)}
                            className="text-red-400 hover:text-red-300 text-sm"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">DM Campaigns</h2>
                <button
                  onClick={() => setShowCampaignModal(true)}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition text-sm"
                >
                  + Create Campaign
                </button>
              </div>

              {campaigns.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  No campaigns yet. Create your first DM campaign!
                </div>
              ) : (
                <div className="space-y-3">
                  {campaigns.map((campaign) => (
                    <div key={campaign.id} className="p-4 bg-white/5 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-white font-medium">{campaign.name}</div>
                            <span className={`text-xs px-2 py-1 rounded ${campaign.enabled ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'}`}>
                              {campaign.enabled ? 'Active' : 'Paused'}
                            </span>
                          </div>
                          <div className="text-sm text-slate-300">
                            Type: {campaign.campaign_type} | Target: {campaign.target_type}
                          </div>
                          <div className="text-xs text-slate-400 mt-1">
                            Limit: {campaign.daily_limit}/day | Delay: {campaign.delay_minutes}min
                          </div>
                        </div>
                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => handleToggleCampaign(campaign.id, !campaign.enabled)}
                            className={`text-sm ${campaign.enabled ? 'text-yellow-400 hover:text-yellow-300' : 'text-green-400 hover:text-green-300'}`}
                          >
                            {campaign.enabled ? 'Pause' : 'Resume'}
                          </button>
                          <button
                            onClick={() => handleDeleteCampaign(campaign.id)}
                            className="text-red-400 hover:text-red-300 text-sm"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              {dailyStats ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300">DMs Sent</span>
                    <span className="text-white font-semibold">
                      {dailyStats.current_count} / {dailyStats.limit_count}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all"
                      style={{ width: `${Math.min(dailyStats.percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    {dailyStats.percentage.toFixed(1)}% of daily limit used
                  </p>
                </div>
              ) : (
                <p className="text-slate-400">No data available</p>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Recent DMs</h3>
              {dmHistory.length === 0 ? (
                <p className="text-slate-400 text-center py-4">No DMs sent yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {dmHistory.map((dm) => (
                    <div key={dm.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-white font-medium">@{dm.recipient_username}</div>
                        {dm.opened && (
                          <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded">
                            Opened
                          </span>
                        )}
                        {dm.replied && (
                          <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded">
                            Replied
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-slate-300 mb-1 line-clamp-2">{dm.message_text}</div>
                      <div className="text-xs text-slate-400">
                        {new Date(dm.sent_at).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-cyan-500/20 border border-cyan-500/50 rounded-xl p-4">
              <div className="text-cyan-300 font-semibold mb-2">💡 DM Best Practices</div>
              <ul className="text-xs text-cyan-200 space-y-1">
                <li>• Keep messages under 200 characters</li>
                <li>• Always personalize with their name</li>
                <li>• Provide value, don't just sell</li>
                <li>• Include clear call-to-action</li>
                <li>• Avoid spammy words and links</li>
                <li>• Test templates before campaigns</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {showTemplateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">
              {editingTemplate ? 'Edit Template' : 'Add DM Template'}
            </h2>

            <form onSubmit={handleSaveTemplate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Template Name *
                </label>
                <input
                  type="text"
                  required
                  value={templateForm.name}
                  onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Welcome Message"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Message *
                </label>
                <textarea
                  required
                  value={templateForm.message}
                  onChange={(e) => setTemplateForm({ ...templateForm, message: e.target.value })}
                  rows={5}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Hey [username]! Thanks for following [account]! 🎉"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Use [username], [name], [account] for personalization
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Category (Optional)
                </label>
                <input
                  type="text"
                  value={templateForm.category}
                  onChange={(e) => setTemplateForm({ ...templateForm, category: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="welcome, promo, follow-up"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowTemplateModal(false);
                    setEditingTemplate(null);
                    setTemplateForm({ name: '', message: '', category: '' });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
                >
                  {editingTemplate ? 'Update' : 'Create Template'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showCampaignModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20 max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-4">Create DM Campaign</h2>

            <form onSubmit={handleSaveCampaign} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Campaign Name *
                </label>
                <input
                  type="text"
                  required
                  value={campaignForm.name}
                  onChange={(e) => setCampaignForm({ ...campaignForm, name: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="New Follower Welcome"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Campaign Type *
                </label>
                <select
                  required
                  value={campaignForm.campaign_type}
                  onChange={(e) => setCampaignForm({ ...campaignForm, campaign_type: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="welcome">Welcome Message</option>
                  <option value="bulk">Bulk DM</option>
                  <option value="drip">Drip Campaign</option>
                  <option value="auto_reply">Auto Reply</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Template *
                </label>
                <select
                  required
                  value={campaignForm.template_id}
                  onChange={(e) => setCampaignForm({ ...campaignForm, template_id: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="">Select a template</option>
                  {templates.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Target Audience *
                </label>
                <select
                  required
                  value={campaignForm.target_type}
                  onChange={(e) => setCampaignForm({ ...campaignForm, target_type: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="new_followers">New Followers</option>
                  <option value="all_followers">All Followers</option>
                  <option value="non_followers">People I Follow</option>
                  <option value="specific">Specific Users</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Delay (minutes)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={campaignForm.delay_minutes}
                    onChange={(e) => setCampaignForm({ ...campaignForm, delay_minutes: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Daily Limit
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={campaignForm.daily_limit}
                    onChange={(e) => setCampaignForm({ ...campaignForm, daily_limit: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowCampaignModal(false);
                    setCampaignForm({
                      name: '',
                      campaign_type: 'welcome',
                      template_id: '',
                      target_type: 'new_followers',
                      target_usernames: [],
                      delay_minutes: 5,
                      daily_limit: 50,
                      enabled: true,
                    });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition"
                >
                  Create Campaign
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
