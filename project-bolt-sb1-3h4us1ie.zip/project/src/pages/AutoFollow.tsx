import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAutomation } from '../hooks/useAutomation';

export function AutoFollow() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [settings, setSettings] = useState<any>(null);
  const [follows, setFollows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { getDailyLimits } = useAutomation(selectedAccountId || null);
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [accountStats, setAccountStats] = useState<any>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadSettings();
      loadFollows();
      loadDailyStats();
      loadAccountStats();
    }
  }, [selectedAccountId]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from('auto_follow_settings')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .maybeSingle();

    setSettings(data || {
      enabled: false,
      target_type: 'hashtags',
      target_hashtags: [],
      target_usernames: [],
      target_locations: [],
      competitor_usernames: [],
      follow_followers: true,
      follow_following: false,
      check_profile_before_follow: true,
      min_followers: 100,
      max_followers: 50000,
      min_posts: 3,
      max_following_ratio: 2.0,
      skip_private_accounts: true,
      skip_business_accounts: false,
      skip_verified_accounts: false,
      daily_limit: 50,
    });
  };

  const loadFollows = async () => {
    const { data } = await supabase
      .from('follows')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('followed_at', { ascending: false })
      .limit(50);

    setFollows(data || []);
  };

  const loadDailyStats = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    const followLimit = limits.find(l => l.action_type === 'follow');
    setDailyStats(followLimit);
  };

  const loadAccountStats = async () => {
    const account = accounts.find(a => a.id === selectedAccountId);
    if (!account) return;

    const followRatio = account.following_count / Math.max(account.follower_count, 1);

    setAccountStats({
      followers: account.follower_count || 0,
      following: account.following_count || 0,
      ratio: followRatio.toFixed(2),
      isHealthy: followRatio < 1.5,
    });
  };

  const handleSave = async () => {
    if (!selectedAccountId) return;

    setSaving(true);

    try {
      const { data: existing } = await supabase
        .from('auto_follow_settings')
        .select('id')
        .eq('instagram_account_id', selectedAccountId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('auto_follow_settings')
          .update(settings)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('auto_follow_settings')
          .insert({ ...settings, instagram_account_id: selectedAccountId });
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Auto Follow</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">Auto Follow Settings</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <span className="text-slate-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Target Source
                  </label>
                  <select
                    value={settings?.target_type || 'hashtags'}
                    onChange={(e) => handleChange('target_type', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="hashtags">Hashtag Followers</option>
                    <option value="users">Specific Users' Followers</option>
                    <option value="competitors">Competitors' Followers</option>
                    <option value="locations">Location Based</option>
                    <option value="explore">Explore Page Users</option>
                    <option value="suggested">Suggested Users</option>
                  </select>
                </div>

                {settings?.target_type === 'hashtags' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Hashtags (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_hashtags || []).join('\n')}
                      onChange={(e) => handleChange('target_hashtags', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="fashion&#10;style&#10;ootd"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Bot will follow users who post with these hashtags
                    </p>
                  </div>
                )}

                {(settings?.target_type === 'users' || settings?.target_type === 'competitors') && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Usernames (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_type === 'competitors' ? settings?.competitor_usernames || [] : settings?.target_usernames || []).join('\n')}
                      onChange={(e) => handleChange(
                        settings?.target_type === 'competitors' ? 'competitor_usernames' : 'target_usernames',
                        e.target.value.split('\n').filter(Boolean)
                      )}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="username1&#10;username2"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      {settings?.target_type === 'competitors'
                        ? "Bot will follow your competitors' followers/following"
                        : "Bot will follow these users' followers"}
                    </p>
                  </div>
                )}

                {settings?.target_type === 'locations' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Locations (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_locations || []).join('\n')}
                      onChange={(e) => handleChange('target_locations', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="New York&#10;Los Angeles"
                    />
                  </div>
                )}

                {(settings?.target_type === 'users' || settings?.target_type === 'competitors') && (
                  <div className="grid grid-cols-2 gap-4">
                    <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                      <input
                        type="checkbox"
                        checked={settings?.follow_followers || false}
                        onChange={(e) => handleChange('follow_followers', e.target.checked)}
                        className="w-5 h-5 rounded bg-white/10 border-white/20"
                      />
                      <span className="text-white">Follow their followers</span>
                    </label>

                    <label className="flex items-center gap-3 cursor-pointer p-3 bg-white/5 rounded-lg">
                      <input
                        type="checkbox"
                        checked={settings?.follow_following || false}
                        onChange={(e) => handleChange('follow_following', e.target.checked)}
                        className="w-5 h-5 rounded bg-white/10 border-white/20"
                      />
                      <span className="text-white">Follow who they follow</span>
                    </label>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Daily Follow Limit
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="200"
                    value={settings?.daily_limit || 50}
                    onChange={(e) => handleChange('daily_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Recommended: 30-80 follows per day for new accounts, up to 200 for aged accounts
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold text-white mb-4">Profile Filtering</h2>

              <div className="space-y-4">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.check_profile_before_follow || false}
                    onChange={(e) => handleChange('check_profile_before_follow', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                  <span className="text-white">Check profile before following (Recommended)</span>
                </label>

                {settings?.check_profile_before_follow && (
                  <div className="pl-8 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">
                          Min Followers
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="10000"
                          value={settings?.min_followers || 100}
                          onChange={(e) => handleChange('min_followers', parseInt(e.target.value))}
                          className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">
                          Max Followers
                        </label>
                        <input
                          type="number"
                          min="100"
                          max="1000000"
                          value={settings?.max_followers || 50000}
                          onChange={(e) => handleChange('max_followers', parseInt(e.target.value))}
                          className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">
                          Min Posts
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={settings?.min_posts || 3}
                          onChange={(e) => handleChange('min_posts', parseInt(e.target.value))}
                          className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                        />
                        <p className="text-xs text-slate-400 mt-1">
                          Skip accounts with too few posts
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">
                          Max Following/Follower Ratio
                        </label>
                        <input
                          type="number"
                          min="0.5"
                          max="10"
                          step="0.5"
                          value={settings?.max_following_ratio || 2.0}
                          onChange={(e) => handleChange('max_following_ratio', parseFloat(e.target.value))}
                          className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                        />
                        <p className="text-xs text-slate-400 mt-1">
                          Skip users who follow too many (spam/bots)
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings?.skip_private_accounts || false}
                          onChange={(e) => handleChange('skip_private_accounts', e.target.checked)}
                          className="w-5 h-5 rounded bg-white/10 border-white/20"
                        />
                        <span className="text-white">Skip private accounts</span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings?.skip_business_accounts || false}
                          onChange={(e) => handleChange('skip_business_accounts', e.target.checked)}
                          className="w-5 h-5 rounded bg-white/10 border-white/20"
                        />
                        <span className="text-white">Skip business accounts</span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings?.skip_verified_accounts || false}
                          onChange={(e) => handleChange('skip_verified_accounts', e.target.checked)}
                          className="w-5 h-5 rounded bg-white/10 border-white/20"
                        />
                        <span className="text-white">Skip verified accounts (celebs)</span>
                      </label>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {accountStats && (
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-4">Account Health</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Followers</span>
                    <span className="text-white font-semibold">{accountStats.followers.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Following</span>
                    <span className="text-white font-semibold">{accountStats.following.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Ratio</span>
                    <span className={`font-semibold ${accountStats.isHealthy ? 'text-green-400' : 'text-yellow-400'}`}>
                      {accountStats.ratio}
                    </span>
                  </div>
                  <div className={`p-3 rounded-lg ${accountStats.isHealthy ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                    {accountStats.isHealthy
                      ? '✓ Healthy ratio - Safe to continue following'
                      : '⚠ Consider unfollowing to improve ratio'}
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              {dailyStats ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300">Followed</span>
                    <span className="text-white font-semibold">
                      {dailyStats.current_count} / {dailyStats.limit_count}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all"
                      style={{ width: `${Math.min(dailyStats.percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    {dailyStats.percentage.toFixed(1)}% of daily limit used
                  </p>
                </div>
              ) : (
                <p className="text-slate-400">No data available</p>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Recent Follows</h3>
              {follows.length === 0 ? (
                <p className="text-slate-400 text-center py-4">No follows yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {follows.map((follow) => (
                    <div key={follow.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-white font-medium">@{follow.target_username}</div>
                        {follow.is_following_back && (
                          <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded">
                            Following back
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">
                        {new Date(follow.followed_at).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
