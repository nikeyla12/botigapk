import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { extractHashtagsFromCaption } from '../lib/hashtag-suggester';

export function CompetitorAnalysis() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [competitors, setCompetitors] = useState<any[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [addForm, setAddForm] = useState({ username: '', notes: '' });
  const [selectedCompetitor, setSelectedCompetitor] = useState<any>(null);
  const [competitorData, setCompetitorData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [analysisView, setAnalysisView] = useState<'overview' | 'content' | 'hashtags' | 'schedule'>('overview');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadCompetitors();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedCompetitor) {
      loadCompetitorData();
    }
  }, [selectedCompetitor]);

  const loadCompetitors = async () => {
    const { data } = await supabase
      .from('competitor_tracking')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false });

    setCompetitors(data || []);
    if (data && data.length > 0 && !selectedCompetitor) {
      setSelectedCompetitor(data[0]);
    }
  };

  const loadCompetitorData = async () => {
    if (!selectedCompetitor) return;
    setLoading(true);

    const mockData = generateMockCompetitorData(selectedCompetitor.username);
    setCompetitorData(mockData);
    setLoading(false);
  };

  const generateMockCompetitorData = (username: string) => {
    const followers = Math.floor(Math.random() * 50000) + 10000;
    const following = Math.floor(Math.random() * 2000) + 500;
    const posts = Math.floor(Math.random() * 500) + 100;
    const avgLikes = Math.floor(followers * (Math.random() * 0.05 + 0.02));
    const avgComments = Math.floor(avgLikes * (Math.random() * 0.1 + 0.05));
    const engagementRate = ((avgLikes + avgComments) / followers * 100).toFixed(2);

    const recentPosts = Array.from({ length: 12 }, (_, i) => ({
      id: `post-${i}`,
      caption: generateMockCaption(),
      likes: Math.floor(avgLikes * (Math.random() * 0.5 + 0.75)),
      comments: Math.floor(avgComments * (Math.random() * 0.5 + 0.75)),
      posted_at: new Date(Date.now() - i * 24 * 60 * 60 * 1000 * Math.random() * 3).toISOString(),
      type: ['post', 'reel', 'carousel'][Math.floor(Math.random() * 3)],
    }));

    const hashtagUsage = extractTopHashtags(recentPosts);
    const postingSchedule = analyzePostingSchedule(recentPosts);

    return {
      profile: {
        username,
        followers,
        following,
        posts,
        bio: `${username}'s mock bio - Entrepreneur | Content Creator | Digital Marketing`,
        website: `https://example.com/${username}`,
      },
      metrics: {
        avgLikes,
        avgComments,
        engagementRate,
        followersGrowth: Math.floor(Math.random() * 1000) + 100,
        bestPostTime: '6:00 PM',
        postFrequency: '4.2 posts/week',
      },
      recentPosts,
      hashtagUsage,
      postingSchedule,
      contentTypes: {
        posts: recentPosts.filter(p => p.type === 'post').length,
        reels: recentPosts.filter(p => p.type === 'reel').length,
        carousels: recentPosts.filter(p => p.type === 'carousel').length,
      },
    };
  };

  const generateMockCaption = () => {
    const captions = [
      'New post alert! Check out this amazing content #instagood #photooftheday #love #fashion #style',
      'Behind the scenes of our latest project! #business #entrepreneur #motivation #success #hustle',
      'Excited to share this with you all! #travel #wanderlust #adventure #explore #nature',
      'Quick tip for growing your account! #socialmedia #marketing #tips #growth #instagram',
      'Throwback to this incredible moment! #throwback #memories #love #life #happy',
    ];
    return captions[Math.floor(Math.random() * captions.length)];
  };

  const extractTopHashtags = (posts: any[]) => {
    const hashtagCount: Record<string, number> = {};

    posts.forEach(post => {
      const hashtags = extractHashtagsFromCaption(post.caption);
      hashtags.forEach(tag => {
        hashtagCount[tag] = (hashtagCount[tag] || 0) + 1;
      });
    });

    return Object.entries(hashtagCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([tag, count]) => ({ tag, count }));
  };

  const analyzePostingSchedule = (posts: any[]) => {
    const hourCounts: Record<number, number> = {};
    const dayCounts: Record<string, number> = {};

    posts.forEach(post => {
      const date = new Date(post.posted_at);
      const hour = date.getHours();
      const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][date.getDay()];

      hourCounts[hour] = (hourCounts[hour] || 0) + 1;
      dayCounts[day] = (dayCounts[day] || 0) + 1;
    });

    return { hourCounts, dayCounts };
  };

  const handleAddCompetitor = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!addForm.username.trim()) {
      alert('Please enter a username');
      return;
    }

    try {
      await supabase.from('competitor_tracking').insert({
        user_id: user?.id,
        username: addForm.username.replace('@', ''),
        notes: addForm.notes,
        last_checked: new Date().toISOString(),
      });

      setShowAddModal(false);
      setAddForm({ username: '', notes: '' });
      loadCompetitors();
      alert('Competitor added successfully!');
    } catch (error) {
      console.error('Failed to add competitor:', error);
      alert('Failed to add competitor');
    }
  };

  const handleDeleteCompetitor = async (competitorId: string) => {
    if (!confirm('Remove this competitor from tracking?')) return;

    try {
      await supabase.from('competitor_tracking').delete().eq('id', competitorId);
      loadCompetitors();
      if (selectedCompetitor?.id === competitorId) {
        setSelectedCompetitor(null);
        setCompetitorData(null);
      }
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleRefreshData = async () => {
    if (selectedCompetitor) {
      await supabase
        .from('competitor_tracking')
        .update({ last_checked: new Date().toISOString() })
        .eq('id', selectedCompetitor.id);

      loadCompetitorData();
      loadCompetitors();
    }
  };

  const calculateGrowthRate = (current: number, previous: number) => {
    if (previous === 0) return 0;
    return (((current - previous) / previous) * 100).toFixed(1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Competitor Analysis</h1>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white rounded-lg transition"
            >
              + Track Competitor
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
              <h2 className="text-lg font-semibold text-white mb-4">Tracked Competitors</h2>

              {competitors.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-4xl mb-2">🔍</div>
                  <p className="text-slate-400 text-sm">No competitors tracked yet</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {competitors.map((comp) => (
                    <div
                      key={comp.id}
                      onClick={() => setSelectedCompetitor(comp)}
                      className={`p-3 rounded-lg cursor-pointer transition ${
                        selectedCompetitor?.id === comp.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="font-medium">@{comp.username}</div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCompetitor(comp.id);
                          }}
                          className="text-xs hover:text-red-300"
                        >
                          ✕
                        </button>
                      </div>
                      {comp.notes && (
                        <div className="text-xs opacity-75 line-clamp-1">{comp.notes}</div>
                      )}
                      <div className="text-xs opacity-50 mt-1">
                        Updated: {new Date(comp.last_checked).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-6 bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/50 rounded-xl p-4">
              <h3 className="text-orange-300 font-semibold mb-2">🔥 Pro Tips</h3>
              <ul className="text-xs text-orange-200 space-y-1">
                <li>• Track 3-5 direct competitors</li>
                <li>• Analyze their best posts</li>
                <li>• Copy their hashtags</li>
                <li>• Learn from their schedule</li>
                <li>• Adapt their content style</li>
                <li>• Monitor their growth</li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-3">
            {!selectedCompetitor || !competitorData ? (
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 text-center">
                <div className="text-6xl mb-4">📊</div>
                <h3 className="text-xl font-semibold text-white mb-2">Select a Competitor</h3>
                <p className="text-slate-400">Choose a competitor from the list to view their analytics</p>
              </div>
            ) : loading ? (
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 text-center">
                <div className="text-white text-xl">Loading competitor data...</div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-white">@{competitorData.profile.username}</h2>
                      <p className="text-slate-300 text-sm mt-1">{competitorData.profile.bio}</p>
                    </div>
                    <button
                      onClick={handleRefreshData}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition"
                    >
                      🔄 Refresh
                    </button>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    <div className="p-4 bg-white/5 rounded-lg">
                      <div className="text-slate-400 text-sm mb-1">Followers</div>
                      <div className="text-2xl font-bold text-white">
                        {competitorData.profile.followers.toLocaleString()}
                      </div>
                      <div className="text-xs text-green-400 mt-1">
                        +{competitorData.metrics.followersGrowth} this month
                      </div>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg">
                      <div className="text-slate-400 text-sm mb-1">Following</div>
                      <div className="text-2xl font-bold text-white">
                        {competitorData.profile.following.toLocaleString()}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        Ratio: {(competitorData.profile.followers / competitorData.profile.following).toFixed(2)}
                      </div>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg">
                      <div className="text-slate-400 text-sm mb-1">Posts</div>
                      <div className="text-2xl font-bold text-white">
                        {competitorData.profile.posts}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        {competitorData.metrics.postFrequency}
                      </div>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg">
                      <div className="text-slate-400 text-sm mb-1">Engagement</div>
                      <div className="text-2xl font-bold text-white">
                        {competitorData.metrics.engagementRate}%
                      </div>
                      <div className="text-xs text-blue-400 mt-1">
                        Avg: {competitorData.metrics.avgLikes} likes
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex gap-2 mb-6">
                    {['overview', 'content', 'hashtags', 'schedule'].map((view) => (
                      <button
                        key={view}
                        onClick={() => setAnalysisView(view as any)}
                        className={`px-4 py-2 rounded-lg text-sm transition capitalize ${
                          analysisView === view
                            ? 'bg-blue-600 text-white'
                            : 'bg-white/10 text-slate-300 hover:bg-white/20'
                        }`}
                      >
                        {view}
                      </button>
                    ))}
                  </div>

                  {analysisView === 'overview' && (
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Performance Metrics</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 bg-white/5 rounded-lg">
                            <div className="text-slate-400 text-sm mb-2">Average Likes</div>
                            <div className="text-xl font-bold text-white">
                              {competitorData.metrics.avgLikes.toLocaleString()}
                            </div>
                          </div>
                          <div className="p-4 bg-white/5 rounded-lg">
                            <div className="text-slate-400 text-sm mb-2">Average Comments</div>
                            <div className="text-xl font-bold text-white">
                              {competitorData.metrics.avgComments.toLocaleString()}
                            </div>
                          </div>
                          <div className="p-4 bg-white/5 rounded-lg">
                            <div className="text-slate-400 text-sm mb-2">Best Post Time</div>
                            <div className="text-xl font-bold text-white">
                              {competitorData.metrics.bestPostTime}
                            </div>
                          </div>
                          <div className="p-4 bg-white/5 rounded-lg">
                            <div className="text-slate-400 text-sm mb-2">Post Frequency</div>
                            <div className="text-xl font-bold text-white">
                              {competitorData.metrics.postFrequency}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Content Mix</h3>
                        <div className="grid grid-cols-3 gap-4">
                          <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                            <div className="text-purple-300 text-sm mb-1">Posts</div>
                            <div className="text-2xl font-bold text-white">
                              {competitorData.contentTypes.posts}
                            </div>
                            <div className="text-xs text-purple-400 mt-1">
                              {((competitorData.contentTypes.posts / competitorData.recentPosts.length) * 100).toFixed(0)}%
                            </div>
                          </div>
                          <div className="p-4 bg-pink-500/10 border border-pink-500/30 rounded-lg">
                            <div className="text-pink-300 text-sm mb-1">Reels</div>
                            <div className="text-2xl font-bold text-white">
                              {competitorData.contentTypes.reels}
                            </div>
                            <div className="text-xs text-pink-400 mt-1">
                              {((competitorData.contentTypes.reels / competitorData.recentPosts.length) * 100).toFixed(0)}%
                            </div>
                          </div>
                          <div className="p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                            <div className="text-cyan-300 text-sm mb-1">Carousels</div>
                            <div className="text-2xl font-bold text-white">
                              {competitorData.contentTypes.carousels}
                            </div>
                            <div className="text-xs text-cyan-400 mt-1">
                              {((competitorData.contentTypes.carousels / competitorData.recentPosts.length) * 100).toFixed(0)}%
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {analysisView === 'content' && (
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-4">Recent Posts</h3>
                      <div className="space-y-3 max-h-[500px] overflow-y-auto">
                        {competitorData.recentPosts.map((post: any) => (
                          <div key={post.id} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <span className={`text-xs px-2 py-1 rounded ${
                                    post.type === 'reel' ? 'bg-pink-500/20 text-pink-300' :
                                    post.type === 'carousel' ? 'bg-cyan-500/20 text-cyan-300' :
                                    'bg-purple-500/20 text-purple-300'
                                  }`}>
                                    {post.type}
                                  </span>
                                  <span className="text-xs text-slate-400">
                                    {new Date(post.posted_at).toLocaleDateString()}
                                  </span>
                                </div>
                                <p className="text-slate-300 text-sm mb-3 line-clamp-2">{post.caption}</p>
                                <div className="flex items-center gap-4 text-sm">
                                  <span className="text-red-400">❤️ {post.likes.toLocaleString()}</span>
                                  <span className="text-blue-400">💬 {post.comments.toLocaleString()}</span>
                                  <span className="text-green-400">
                                    {((post.likes + post.comments) / competitorData.profile.followers * 100).toFixed(2)}% ER
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {analysisView === 'hashtags' && (
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Top Hashtags Used</h3>
                        <button
                          onClick={() => {
                            const hashtags = competitorData.hashtagUsage.map((h: any) => `#${h.tag}`).join(' ');
                            navigator.clipboard.writeText(hashtags);
                            alert('Hashtags copied!');
                          }}
                          className="text-sm text-cyan-400 hover:text-cyan-300"
                        >
                          📋 Copy All
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {competitorData.hashtagUsage.map((item: any, idx: number) => (
                          <div key={idx} className="p-3 bg-white/5 rounded-lg hover:bg-white/10 transition">
                            <div className="flex items-center justify-between">
                              <span className="text-blue-400 font-medium">#{item.tag}</span>
                              <span className="text-slate-400 text-sm">Used {item.count}x</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {analysisView === 'schedule' && (
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Posting Schedule by Hour</h3>
                        <div className="grid grid-cols-8 gap-2">
                          {Object.entries(competitorData.postingSchedule.hourCounts).map(([hour, count]) => (
                            <div key={hour} className="text-center">
                              <div className="text-xs text-slate-400 mb-1">{hour}:00</div>
                              <div
                                className="bg-blue-500 rounded"
                                style={{ height: `${(count as number) * 30 + 10}px` }}
                              />
                              <div className="text-xs text-white mt-1">{count}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-white mb-4">Posting Schedule by Day</h3>
                        <div className="grid grid-cols-7 gap-2">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => {
                            const count = competitorData.postingSchedule.dayCounts[day] || 0;
                            return (
                              <div key={day} className="text-center">
                                <div className="text-xs text-slate-400 mb-2">{day}</div>
                                <div
                                  className="bg-purple-500 rounded mx-auto"
                                  style={{ width: '40px', height: `${count * 40 + 20}px` }}
                                />
                                <div className="text-xs text-white mt-2">{count}</div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">Track New Competitor</h2>

            <form onSubmit={handleAddCompetitor} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Instagram Username *
                </label>
                <input
                  type="text"
                  required
                  value={addForm.username}
                  onChange={(e) => setAddForm({ ...addForm, username: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="@competitor_username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Notes (Optional)
                </label>
                <textarea
                  value={addForm.notes}
                  onChange={(e) => setAddForm({ ...addForm, notes: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Why are you tracking this competitor?"
                />
              </div>

              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-3">
                <p className="text-xs text-yellow-200">
                  <strong>Note:</strong> Data is simulated for demo purposes. In production, this would fetch real Instagram data via API.
                </p>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setAddForm({ username: '', notes: '' });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white rounded-lg transition"
                >
                  Track Competitor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
