import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAutomation } from '../hooks/useAutomation';
import { generateSmartComment } from '../lib/comment-generator';

export function AutoCommenter() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [settings, setSettings] = useState<any>(null);
  const [templates, setTemplates] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { getDailyLimits } = useAutomation(selectedAccountId || null);
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);
  const [templateForm, setTemplateForm] = useState({ text: '', category: '' });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadSettings();
      loadTemplates();
      loadComments();
      loadDailyStats();
    }
  }, [selectedAccountId]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from('auto_commenter_settings')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .maybeSingle();

    setSettings(data || {
      enabled: false,
      target_type: 'hashtags',
      target_hashtags: [],
      target_usernames: [],
      comment_mode: 'templates',
      use_ai: false,
      use_emojis: true,
      comment_length: 'medium',
      daily_limit: 30,
      comment_ratio: 0.3,
    });
  };

  const loadTemplates = async () => {
    const { data } = await supabase
      .from('comment_templates')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('created_at', { ascending: false });

    setTemplates(data || []);
  };

  const loadComments = async () => {
    const { data } = await supabase
      .from('post_comments')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('commented_at', { ascending: false })
      .limit(50);

    setComments(data || []);
  };

  const loadDailyStats = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    const commentLimit = limits.find(l => l.action_type === 'comment');
    setDailyStats(commentLimit);
  };

  const handleSaveSettings = async () => {
    if (!selectedAccountId) return;

    setSaving(true);

    try {
      const { data: existing } = await supabase
        .from('auto_commenter_settings')
        .select('id')
        .eq('instagram_account_id', selectedAccountId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('auto_commenter_settings')
          .update(settings)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('auto_commenter_settings')
          .insert({ ...settings, instagram_account_id: selectedAccountId });
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingTemplate) {
        await supabase
          .from('comment_templates')
          .update(templateForm)
          .eq('id', editingTemplate.id);
      } else {
        await supabase
          .from('comment_templates')
          .insert({ ...templateForm, instagram_account_id: selectedAccountId });
      }

      setShowTemplateModal(false);
      setEditingTemplate(null);
      setTemplateForm({ text: '', category: '' });
      loadTemplates();
    } catch (error) {
      console.error('Failed to save template:', error);
      alert('Failed to save template');
    }
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Delete this template?')) return;

    try {
      await supabase.from('comment_templates').delete().eq('id', templateId);
      loadTemplates();
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  const handleChange = (field: string, value: any) => {
    setSettings({ ...settings, [field]: value });
  };

  const handleGenerateAIComment = async () => {
    const comment = await generateSmartComment({
      niche: 'general',
      useEmojis: settings?.use_emojis || false,
      length: settings?.comment_length || 'medium',
    });
    alert(`AI Generated Comment:\n\n"${comment}"\n\nAdd this to your templates!`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Auto Commenter</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">Auto Commenter Settings</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <span className="text-slate-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Target Type
                  </label>
                  <select
                    value={settings?.target_type || 'hashtags'}
                    onChange={(e) => handleChange('target_type', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="hashtags">Hashtags</option>
                    <option value="users">Specific Users</option>
                    <option value="followers">My Followers' Posts</option>
                    <option value="following">People I Follow</option>
                    <option value="explore">Explore Page</option>
                  </select>
                </div>

                {settings?.target_type === 'hashtags' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Hashtags (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_hashtags || []).join('\n')}
                      onChange={(e) => handleChange('target_hashtags', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="fashion&#10;style&#10;photography"
                    />
                  </div>
                )}

                {settings?.target_type === 'users' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Usernames (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_usernames || []).join('\n')}
                      onChange={(e) => handleChange('target_usernames', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="username1&#10;username2"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Comment Mode
                  </label>
                  <select
                    value={settings?.comment_mode || 'templates'}
                    onChange={(e) => handleChange('comment_mode', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="templates">Use Templates</option>
                    <option value="ai">AI Generated (Smart)</option>
                    <option value="mixed">Mixed (Templates + AI)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Comment Length
                  </label>
                  <select
                    value={settings?.comment_length || 'medium'}
                    onChange={(e) => handleChange('comment_length', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="short">Short (1-3 words)</option>
                    <option value="medium">Medium (4-8 words)</option>
                    <option value="long">Long (9-15 words)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Comment Ratio (0-1)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="1"
                    step="0.1"
                    value={settings?.comment_ratio || 0.3}
                    onChange={(e) => handleChange('comment_ratio', parseFloat(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    0.3 = Comment on 30% of posts viewed
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Daily Limit
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="200"
                    value={settings?.daily_limit || 30}
                    onChange={(e) => handleChange('daily_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Recommended: 20-50 comments per day to avoid spam detection
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.use_emojis || false}
                      onChange={(e) => handleChange('use_emojis', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Use emojis in comments</span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.use_ai || false}
                      onChange={(e) => handleChange('use_ai', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Enable AI smart comments (Premium)</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={handleSaveSettings}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">Comment Templates</h2>
                <div className="flex gap-2">
                  <button
                    onClick={handleGenerateAIComment}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition text-sm"
                  >
                    🤖 Generate AI
                  </button>
                  <button
                    onClick={() => {
                      setEditingTemplate(null);
                      setTemplateForm({ text: '', category: '' });
                      setShowTemplateModal(true);
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition text-sm"
                  >
                    + Add Template
                  </button>
                </div>
              </div>

              {templates.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  No templates yet. Add your first comment template!
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {templates.map((template) => (
                    <div key={template.id} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="text-white">{template.text}</p>
                          {template.category && (
                            <span className="text-xs text-slate-400 mt-1 inline-block">
                              #{template.category}
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => {
                              setEditingTemplate(template);
                              setTemplateForm({ text: template.text, category: template.category || '' });
                              setShowTemplateModal(true);
                            }}
                            className="text-blue-400 hover:text-blue-300 text-sm"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteTemplate(template.id)}
                            className="text-red-400 hover:text-red-300 text-sm"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              {dailyStats ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300">Comments Posted</span>
                    <span className="text-white font-semibold">
                      {dailyStats.current_count} / {dailyStats.limit_count}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-teal-500 rounded-full transition-all"
                      style={{ width: `${Math.min(dailyStats.percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    {dailyStats.percentage.toFixed(1)}% of daily limit used
                  </p>
                </div>
              ) : (
                <p className="text-slate-400">No data available</p>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Recent Comments</h3>
              {comments.length === 0 ? (
                <p className="text-slate-400 text-center py-4">No comments posted yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {comments.map((comment) => (
                    <div key={comment.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="text-sm text-slate-300 mb-1">@{comment.post_owner_username}</div>
                      <div className="text-white text-sm mb-2">"{comment.comment_text}"</div>
                      <div className="text-xs text-slate-400">
                        {new Date(comment.commented_at).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showTemplateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">
              {editingTemplate ? 'Edit Template' : 'Add Comment Template'}
            </h2>

            <form onSubmit={handleSaveTemplate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Comment Text *
                </label>
                <textarea
                  required
                  value={templateForm.text}
                  onChange={(e) => setTemplateForm({ ...templateForm, text: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="Amazing! Love this! 🔥"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Tip: Use varied comments to avoid spam detection
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Category (Optional)
                </label>
                <input
                  type="text"
                  value={templateForm.category}
                  onChange={(e) => setTemplateForm({ ...templateForm, category: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="general, positive, question, etc."
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowTemplateModal(false);
                    setEditingTemplate(null);
                    setTemplateForm({ text: '', category: '' });
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
                >
                  {editingTemplate ? 'Update' : 'Add Template'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
