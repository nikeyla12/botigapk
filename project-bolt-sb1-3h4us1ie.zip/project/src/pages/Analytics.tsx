import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export function Analytics() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [analytics, setAnalytics] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadAnalytics();
    }
  }, [selectedAccountId, timeRange]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadAnalytics = async () => {
    const days = parseInt(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const { data } = await supabase
      .from('analytics')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: true });

    setAnalytics(data || []);

    if (data && data.length > 0) {
      const totals = data.reduce((acc, day) => ({
        follower_growth: acc.follower_growth + (day.follower_growth || 0),
        total_likes: acc.total_likes + (day.total_likes || 0),
        total_comments: acc.total_comments + (day.total_comments || 0),
        stories_viewed: acc.stories_viewed + (day.stories_viewed || 0),
        posts_liked: acc.posts_liked + (day.posts_liked || 0),
        comments_posted: acc.comments_posted + (day.comments_posted || 0),
        follows_done: acc.follows_done + (day.follows_done || 0),
        unfollows_done: acc.unfollows_done + (day.unfollows_done || 0),
        dms_sent: acc.dms_sent + (day.dms_sent || 0),
        engagement_rate: 0,
      }), {
        follower_growth: 0,
        total_likes: 0,
        total_comments: 0,
        stories_viewed: 0,
        posts_liked: 0,
        comments_posted: 0,
        follows_done: 0,
        unfollows_done: 0,
        dms_sent: 0,
        engagement_rate: 0,
      });

      const avgEngagement = data.reduce((sum, d) => sum + (d.engagement_rate || 0), 0) / data.length;
      totals.engagement_rate = avgEngagement;

      setSummary(totals);
    }
  };

  const selectedAccount = accounts.find(a => a.id === selectedAccountId);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Analytics</h1>
            </div>
            <div className="flex items-center gap-4">
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                {accounts.map(account => (
                  <option key={account.id} value={account.id}>
                    @{account.username}
                  </option>
                ))}
              </select>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                <option value="7">Last 7 days</option>
                <option value="14">Last 14 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </select>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {selectedAccount && (
          <div className="mb-8 bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">@{selectedAccount.username}</h2>
                <div className="flex gap-6 text-slate-300">
                  <div>
                    <span className="font-semibold">{selectedAccount.follower_count?.toLocaleString()}</span> Followers
                  </div>
                  <div>
                    <span className="font-semibold">{selectedAccount.following_count?.toLocaleString()}</span> Following
                  </div>
                  <div>
                    <span className="font-semibold">{selectedAccount.post_count?.toLocaleString()}</span> Posts
                  </div>
                </div>
              </div>
              <div className={`px-4 py-2 rounded-lg ${selectedAccount.is_active ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'}`}>
                {selectedAccount.is_active ? 'Active' : 'Inactive'}
              </div>
            </div>
          </div>
        )}

        {summary && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="text-slate-400 text-sm mb-2">Follower Growth</div>
                <div className="text-3xl font-bold text-white">{summary.follower_growth > 0 ? '+' : ''}{summary.follower_growth}</div>
                <div className="text-xs text-slate-400 mt-1">Last {timeRange} days</div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="text-slate-400 text-sm mb-2">Engagement Rate</div>
                <div className="text-3xl font-bold text-white">{summary.engagement_rate.toFixed(2)}%</div>
                <div className="text-xs text-slate-400 mt-1">Average</div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="text-slate-400 text-sm mb-2">Total Likes Received</div>
                <div className="text-3xl font-bold text-white">{summary.total_likes.toLocaleString()}</div>
                <div className="text-xs text-slate-400 mt-1">On your posts</div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="text-slate-400 text-sm mb-2">Total Comments</div>
                <div className="text-3xl font-bold text-white">{summary.total_comments.toLocaleString()}</div>
                <div className="text-xs text-slate-400 mt-1">On your posts</div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-4">Bot Activity Summary</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Stories Viewed</span>
                    <span className="text-white font-semibold">{summary.stories_viewed.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Posts Liked</span>
                    <span className="text-white font-semibold">{summary.posts_liked.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Comments Posted</span>
                    <span className="text-white font-semibold">{summary.comments_posted.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Follows</span>
                    <span className="text-white font-semibold">{summary.follows_done.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Unfollows</span>
                    <span className="text-white font-semibold">{summary.unfollows_done.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">DMs Sent</span>
                    <span className="text-white font-semibold">{summary.dms_sent.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-4">Daily Breakdown</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {analytics.map((day) => (
                    <div key={day.date} className="p-3 bg-white/5 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-white font-medium">
                          {new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </span>
                        <span className={`text-sm ${day.follower_growth >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {day.follower_growth > 0 ? '+' : ''}{day.follower_growth} followers
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs text-slate-400">
                        <div>{day.stories_viewed} stories</div>
                        <div>{day.posts_liked} likes</div>
                        <div>{day.comments_posted} comments</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {!summary && analytics.length === 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 text-center">
            <div className="text-6xl mb-4">📊</div>
            <h2 className="text-2xl font-bold text-white mb-2">No Analytics Data Yet</h2>
            <p className="text-slate-400">
              Analytics will appear here once your bot starts working.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
