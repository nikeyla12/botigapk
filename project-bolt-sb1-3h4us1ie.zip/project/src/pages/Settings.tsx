import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useAutomation } from '../hooks/useAutomation';

export function Settings() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const { settings, updateSettings, loading } = useAutomation(selectedAccountId || null);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  const loadAccounts = async () => {
    const response = await fetch('/api/accounts');
    if (response.ok) {
      const data = await response.json();
      setAccounts(data);
      if (data.length > 0) {
        setSelectedAccountId(data[0].id);
      }
    }
  };

  const handleSave = async () => {
    if (!settings) return;

    setSaving(true);
    setSuccessMessage('');

    try {
      await updateSettings(settings);
      setSuccessMessage('Settings saved successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    if (settings) {
      updateSettings({ [field]: value });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading settings...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Automation Settings</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {successMessage && (
          <div className="mb-6 p-4 bg-green-500/20 border border-green-500/50 rounded-lg text-green-300">
            {successMessage}
          </div>
        )}

        <div className="space-y-6">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold text-white mb-4">General Settings</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Automation Status
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                  <span className="text-white">Enable Automation</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Active Hours Start
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="23"
                    value={settings?.active_hours_start || 8}
                    onChange={(e) => handleChange('active_hours_start', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Active Hours End
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="23"
                    value={settings?.active_hours_end || 22}
                    onChange={(e) => handleChange('active_hours_end', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold text-white mb-4">Human Behavior Simulation</h2>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Typing Speed (WPM)
                  </label>
                  <input
                    type="number"
                    min="20"
                    max="120"
                    value={settings?.typing_speed_wpm || 60}
                    onChange={(e) => handleChange('typing_speed_wpm', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Typing Variance
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={settings?.typing_speed_variance || 20}
                    onChange={(e) => handleChange('typing_speed_variance', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    View Duration Min (seconds)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={settings?.view_duration_min || 3}
                    onChange={(e) => handleChange('view_duration_min', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    View Duration Max (seconds)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={settings?.view_duration_max || 8}
                    onChange={(e) => handleChange('view_duration_max', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Action Delay Min (seconds)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={settings?.action_delay_min || 3}
                    onChange={(e) => handleChange('action_delay_min', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Action Delay Max (seconds)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={settings?.action_delay_max || 15}
                    onChange={(e) => handleChange('action_delay_max', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold text-white mb-4">Daily Limits</h2>

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Story Views
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="1000"
                    value={settings?.daily_story_views_limit || 300}
                    onChange={(e) => handleChange('daily_story_views_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Likes
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="1000"
                    value={settings?.daily_likes_limit || 300}
                    onChange={(e) => handleChange('daily_likes_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Comments
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={settings?.daily_comments_limit || 30}
                    onChange={(e) => handleChange('daily_comments_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Follows
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={settings?.daily_follows_limit || 50}
                    onChange={(e) => handleChange('daily_follows_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Unfollows
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={settings?.daily_unfollows_limit || 50}
                    onChange={(e) => handleChange('daily_unfollows_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    DMs
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={settings?.daily_dms_limit || 20}
                    onChange={(e) => handleChange('daily_dms_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold text-white mb-4">Warmup Mode</h2>

            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings?.warmup_enabled || false}
                  onChange={(e) => handleChange('warmup_enabled', e.target.checked)}
                  className="w-5 h-5 rounded bg-white/10 border-white/20"
                />
                <span className="text-white">Enable Warmup Mode (Gradually increase limits)</span>
              </label>

              {settings?.warmup_enabled && (
                <div className="grid grid-cols-2 gap-4 pl-8">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Warmup Duration (days)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="30"
                      value={settings?.warmup_duration_days || 7}
                      onChange={(e) => handleChange('warmup_duration_days', parseInt(e.target.value))}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Current Day
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="30"
                      value={settings?.warmup_day_current || 1}
                      onChange={(e) => handleChange('warmup_day_current', parseInt(e.target.value))}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h2 className="text-lg font-semibold text-white mb-4">Safety Settings</h2>

            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings?.auto_pause_on_high_risk || false}
                  onChange={(e) => handleChange('auto_pause_on_high_risk', e.target.checked)}
                  className="w-5 h-5 rounded bg-white/10 border-white/20"
                />
                <span className="text-white">Auto-pause on high risk detection</span>
              </label>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Risk Threshold (0-100)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={settings?.risk_threshold || 70}
                  onChange={(e) => handleChange('risk_threshold', parseInt(e.target.value))}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Higher threshold = more aggressive automation
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
