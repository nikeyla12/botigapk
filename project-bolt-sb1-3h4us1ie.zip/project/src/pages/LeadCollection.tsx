import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

interface Lead {
  id: string;
  username: string;
  full_name: string;
  followers: number;
  following: number;
  posts: number;
  engagement_rate: number;
  bio: string;
  website: string;
  is_verified: boolean;
  is_business: boolean;
  category: string;
  email?: string;
  phone?: string;
  score: number;
}

export function LeadCollection() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [filteredLeads, setFilteredLeads] = useState<Lead[]>([]);
  const [savedLists, setSavedLists] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [listName, setListName] = useState('');

  const [filters, setFilters] = useState({
    source: 'followers',
    minFollowers: 0,
    maxFollowers: 1000000,
    minEngagement: 0,
    onlyVerified: false,
    onlyBusiness: false,
    category: 'all',
  });

  const [extractForm, setExtractForm] = useState({
    targetUsername: '',
    source: 'followers',
    limit: 100,
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
    loadSavedLists();
  }, [user, navigate]);

  useEffect(() => {
    applyFilters();
  }, [leads, filters]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
  };

  const loadSavedLists = async () => {
    const { data } = await supabase
      .from('lead_lists')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false });

    setSavedLists(data || []);
  };

  const generateMockLeads = (count: number, source: string): Lead[] => {
    const categories = ['Fashion', 'Fitness', 'Food', 'Travel', 'Tech', 'Business', 'Beauty', 'Lifestyle'];
    const mockLeads: Lead[] = [];

    for (let i = 0; i < count; i++) {
      const followers = Math.floor(Math.random() * 50000) + 100;
      const following = Math.floor(Math.random() * 2000) + 50;
      const posts = Math.floor(Math.random() * 500) + 10;
      const avgLikes = Math.floor(followers * (Math.random() * 0.05 + 0.01));
      const avgComments = Math.floor(avgLikes * 0.1);
      const engagementRate = ((avgLikes + avgComments) / followers * 100);

      const hasContact = Math.random() > 0.7;

      mockLeads.push({
        id: `lead-${i}-${Date.now()}`,
        username: `user_${Math.random().toString(36).substring(7)}`,
        full_name: `User ${i + 1}`,
        followers,
        following,
        posts,
        engagement_rate: parseFloat(engagementRate.toFixed(2)),
        bio: `${categories[Math.floor(Math.random() * categories.length)]} enthusiast | Content creator`,
        website: hasContact ? `https://example.com/user${i}` : '',
        is_verified: Math.random() > 0.9,
        is_business: Math.random() > 0.6,
        category: categories[Math.floor(Math.random() * categories.length)],
        email: hasContact && Math.random() > 0.5 ? `user${i}@email.com` : undefined,
        phone: hasContact && Math.random() > 0.7 ? `+1234567890${i}` : undefined,
        score: Math.floor(Math.random() * 100),
      });
    }

    return mockLeads.sort((a, b) => b.score - a.score);
  };

  const handleExtractLeads = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!extractForm.targetUsername.trim()) {
      alert('Please enter a target username');
      return;
    }

    setExtracting(true);
    setLoading(true);

    await new Promise(resolve => setTimeout(resolve, 2000));

    const extractedLeads = generateMockLeads(extractForm.limit, extractForm.source);
    setLeads(extractedLeads);

    setExtracting(false);
    setLoading(false);
    alert(`Extracted ${extractedLeads.length} leads from @${extractForm.targetUsername}'s ${extractForm.source}!`);
  };

  const applyFilters = () => {
    let filtered = [...leads];

    if (filters.minFollowers > 0) {
      filtered = filtered.filter(lead => lead.followers >= filters.minFollowers);
    }

    if (filters.maxFollowers < 1000000) {
      filtered = filtered.filter(lead => lead.followers <= filters.maxFollowers);
    }

    if (filters.minEngagement > 0) {
      filtered = filtered.filter(lead => lead.engagement_rate >= filters.minEngagement);
    }

    if (filters.onlyVerified) {
      filtered = filtered.filter(lead => lead.is_verified);
    }

    if (filters.onlyBusiness) {
      filtered = filtered.filter(lead => lead.is_business);
    }

    if (filters.category !== 'all') {
      filtered = filtered.filter(lead => lead.category === filters.category);
    }

    setFilteredLeads(filtered);
  };

  const handleSelectAll = () => {
    if (selectedLeads.size === filteredLeads.length) {
      setSelectedLeads(new Set());
    } else {
      setSelectedLeads(new Set(filteredLeads.map(lead => lead.id)));
    }
  };

  const handleSelectLead = (leadId: string) => {
    const newSelected = new Set(selectedLeads);
    if (newSelected.has(leadId)) {
      newSelected.delete(leadId);
    } else {
      newSelected.add(leadId);
    }
    setSelectedLeads(newSelected);
  };

  const handleExportCSV = () => {
    if (selectedLeads.size === 0) {
      alert('Please select leads to export');
      return;
    }

    const leadsToExport = filteredLeads.filter(lead => selectedLeads.has(lead.id));

    const headers = [
      'Username',
      'Full Name',
      'Followers',
      'Following',
      'Posts',
      'Engagement Rate',
      'Bio',
      'Website',
      'Email',
      'Phone',
      'Verified',
      'Business',
      'Category',
      'Score',
    ];

    const rows = leadsToExport.map(lead => [
      lead.username,
      lead.full_name,
      lead.followers,
      lead.following,
      lead.posts,
      `${lead.engagement_rate}%`,
      lead.bio,
      lead.website || '',
      lead.email || '',
      lead.phone || '',
      lead.is_verified ? 'Yes' : 'No',
      lead.is_business ? 'Yes' : 'No',
      lead.category,
      lead.score,
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `leads_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    alert(`Exported ${leadsToExport.length} leads to CSV!`);
  };

  const handleSaveList = async () => {
    if (!listName.trim()) {
      alert('Please enter a list name');
      return;
    }

    if (selectedLeads.size === 0) {
      alert('Please select leads to save');
      return;
    }

    try {
      const leadsToSave = filteredLeads.filter(lead => selectedLeads.has(lead.id));

      await supabase.from('lead_lists').insert({
        user_id: user?.id,
        name: listName,
        leads: leadsToSave,
        lead_count: leadsToSave.length,
      });

      setShowSaveModal(false);
      setListName('');
      loadSavedLists();
      alert(`Saved ${leadsToSave.length} leads to list "${listName}"!`);
    } catch (error) {
      console.error('Failed to save list:', error);
      alert('Failed to save list');
    }
  };

  const handleLoadList = async (listId: string) => {
    const list = savedLists.find(l => l.id === listId);
    if (list) {
      setLeads(list.leads);
      alert(`Loaded ${list.leads.length} leads from "${list.name}"`);
    }
  };

  const handleDeleteList = async (listId: string) => {
    if (!confirm('Delete this lead list?')) return;

    try {
      await supabase.from('lead_lists').delete().eq('id', listId);
      loadSavedLists();
    } catch (error) {
      console.error('Failed to delete list:', error);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-blue-400';
    if (score >= 40) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Lead Collection & Export</h1>
            </div>
            <div className="flex gap-2">
              {selectedLeads.size > 0 && (
                <>
                  <button
                    onClick={() => setShowSaveModal(true)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition text-sm"
                  >
                    💾 Save List ({selectedLeads.size})
                  </button>
                  <button
                    onClick={handleExportCSV}
                    className="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-lg transition text-sm"
                  >
                    📥 Export CSV ({selectedLeads.size})
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold text-white mb-4">Extract Leads</h2>

              <form onSubmit={handleExtractLeads} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Target Account *
                  </label>
                  <input
                    type="text"
                    required
                    value={extractForm.targetUsername}
                    onChange={(e) => setExtractForm({ ...extractForm, targetUsername: e.target.value })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                    placeholder="@username"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Extract From
                  </label>
                  <select
                    value={extractForm.source}
                    onChange={(e) => setExtractForm({ ...extractForm, source: e.target.value })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  >
                    <option value="followers">Followers</option>
                    <option value="following">Following</option>
                    <option value="likers">Post Likers</option>
                    <option value="commenters">Post Commenters</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Limit
                  </label>
                  <select
                    value={extractForm.limit}
                    onChange={(e) => setExtractForm({ ...extractForm, limit: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  >
                    <option value={50}>50 leads</option>
                    <option value={100}>100 leads</option>
                    <option value={250}>250 leads</option>
                    <option value={500}>500 leads</option>
                    <option value={1000}>1,000 leads</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={extracting}
                  className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {extracting ? 'Extracting...' : '🔍 Extract Leads'}
                </button>
              </form>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Saved Lists</h3>

              {savedLists.length === 0 ? (
                <p className="text-slate-400 text-sm text-center py-4">No saved lists yet</p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {savedLists.map((list) => (
                    <div key={list.id} className="p-3 bg-white/5 rounded-lg hover:bg-white/10 transition">
                      <div className="flex items-center justify-between mb-1">
                        <div className="font-medium text-white text-sm">{list.name}</div>
                        <div className="flex gap-1">
                          <button
                            onClick={() => handleLoadList(list.id)}
                            className="text-xs text-blue-400 hover:text-blue-300"
                          >
                            Load
                          </button>
                          <button
                            onClick={() => handleDeleteList(list.id)}
                            className="text-xs text-red-400 hover:text-red-300"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                      <div className="text-xs text-slate-400">
                        {list.lead_count} leads • {new Date(list.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/50 rounded-xl p-4">
              <h3 className="text-green-300 font-semibold mb-2">💎 Use Cases</h3>
              <ul className="text-xs text-green-200 space-y-1">
                <li>• Extract competitor followers</li>
                <li>• Build email marketing lists</li>
                <li>• Find potential clients</li>
                <li>• Discover brand ambassadors</li>
                <li>• Research target audience</li>
                <li>• Export to CRM systems</li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">
                  Filters ({filteredLeads.length} of {leads.length} leads)
                </h2>
                <button
                  onClick={() => setFilters({
                    source: 'followers',
                    minFollowers: 0,
                    maxFollowers: 1000000,
                    minEngagement: 0,
                    onlyVerified: false,
                    onlyBusiness: false,
                    category: 'all',
                  })}
                  className="text-sm text-cyan-400 hover:text-cyan-300"
                >
                  Reset Filters
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Min Followers</label>
                  <input
                    type="number"
                    value={filters.minFollowers}
                    onChange={(e) => setFilters({ ...filters, minFollowers: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Max Followers</label>
                  <input
                    type="number"
                    value={filters.maxFollowers}
                    onChange={(e) => setFilters({ ...filters, maxFollowers: parseInt(e.target.value) || 1000000 })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Min Engagement %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={filters.minEngagement}
                    onChange={(e) => setFilters({ ...filters, minEngagement: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Category</label>
                  <select
                    value={filters.category}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm"
                  >
                    <option value="all">All Categories</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Fitness">Fitness</option>
                    <option value="Food">Food</option>
                    <option value="Travel">Travel</option>
                    <option value="Tech">Tech</option>
                    <option value="Business">Business</option>
                    <option value="Beauty">Beauty</option>
                    <option value="Lifestyle">Lifestyle</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-4 mt-4">
                <label className="flex items-center gap-2 text-sm text-slate-300">
                  <input
                    type="checkbox"
                    checked={filters.onlyVerified}
                    onChange={(e) => setFilters({ ...filters, onlyVerified: e.target.checked })}
                    className="rounded"
                  />
                  Verified Only
                </label>

                <label className="flex items-center gap-2 text-sm text-slate-300">
                  <input
                    type="checkbox"
                    checked={filters.onlyBusiness}
                    onChange={(e) => setFilters({ ...filters, onlyBusiness: e.target.checked })}
                    className="rounded"
                  />
                  Business Accounts Only
                </label>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              {leads.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">📊</div>
                  <h3 className="text-xl font-semibold text-white mb-2">No Leads Yet</h3>
                  <p className="text-slate-400">Extract leads from a target account to get started</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <label className="flex items-center gap-2 text-sm text-slate-300">
                      <input
                        type="checkbox"
                        checked={selectedLeads.size === filteredLeads.length && filteredLeads.length > 0}
                        onChange={handleSelectAll}
                        className="rounded"
                      />
                      Select All ({filteredLeads.length})
                    </label>

                    <div className="text-sm text-slate-300">
                      {selectedLeads.size} selected
                    </div>
                  </div>

                  <div className="space-y-2 max-h-[600px] overflow-y-auto">
                    {filteredLeads.map((lead) => (
                      <div
                        key={lead.id}
                        className={`p-4 rounded-lg transition cursor-pointer ${
                          selectedLeads.has(lead.id)
                            ? 'bg-blue-500/20 border border-blue-500/50'
                            : 'bg-white/5 hover:bg-white/10'
                        }`}
                        onClick={() => handleSelectLead(lead.id)}
                      >
                        <div className="flex items-start gap-4">
                          <input
                            type="checkbox"
                            checked={selectedLeads.has(lead.id)}
                            onChange={() => handleSelectLead(lead.id)}
                            className="mt-1 rounded"
                            onClick={(e) => e.stopPropagation()}
                          />

                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-white font-medium">@{lead.username}</span>
                                  {lead.is_verified && <span className="text-blue-400 text-xs">✓</span>}
                                  {lead.is_business && (
                                    <span className="text-xs px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded">
                                      Business
                                    </span>
                                  )}
                                </div>
                                <div className="text-sm text-slate-400">{lead.full_name}</div>
                              </div>

                              <div className="text-right">
                                <div className={`text-lg font-bold ${getScoreColor(lead.score)}`}>
                                  {lead.score}
                                </div>
                                <div className="text-xs text-slate-400">Lead Score</div>
                              </div>
                            </div>

                            <p className="text-sm text-slate-300 mb-2 line-clamp-1">{lead.bio}</p>

                            <div className="grid grid-cols-4 gap-3 mb-2">
                              <div>
                                <div className="text-xs text-slate-400">Followers</div>
                                <div className="text-sm text-white font-medium">
                                  {lead.followers.toLocaleString()}
                                </div>
                              </div>
                              <div>
                                <div className="text-xs text-slate-400">Following</div>
                                <div className="text-sm text-white font-medium">
                                  {lead.following.toLocaleString()}
                                </div>
                              </div>
                              <div>
                                <div className="text-xs text-slate-400">Posts</div>
                                <div className="text-sm text-white font-medium">{lead.posts}</div>
                              </div>
                              <div>
                                <div className="text-xs text-slate-400">Engagement</div>
                                <div className="text-sm text-green-400 font-medium">
                                  {lead.engagement_rate}%
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-4 text-xs">
                              {lead.category && (
                                <span className="px-2 py-1 bg-cyan-500/20 text-cyan-300 rounded">
                                  {lead.category}
                                </span>
                              )}
                              {lead.email && (
                                <span className="text-green-400">✉️ Email</span>
                              )}
                              {lead.phone && (
                                <span className="text-blue-400">📱 Phone</span>
                              )}
                              {lead.website && (
                                <span className="text-purple-400">🌐 Website</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSaveModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full border border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">Save Lead List</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  List Name *
                </label>
                <input
                  type="text"
                  required
                  value={listName}
                  onChange={(e) => setListName(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  placeholder="e.g., Competitor Followers Dec 2024"
                />
              </div>

              <div className="p-4 bg-white/5 rounded-lg">
                <div className="text-sm text-slate-300 mb-2">
                  <strong>{selectedLeads.size}</strong> leads will be saved
                </div>
                <div className="text-xs text-slate-400">
                  You can load this list anytime to export or analyze
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  onClick={() => {
                    setShowSaveModal(false);
                    setListName('');
                  }}
                  className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveList}
                  className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition"
                >
                  Save List
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
