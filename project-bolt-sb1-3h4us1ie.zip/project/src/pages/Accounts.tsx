import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Database } from '../lib/database.types';
import { useNavigate } from 'react-router-dom';
import { createDeviceFingerprint, getDeviceInfo, type DeviceFingerprint } from '../lib/device-fingerprint';
import { createInstagramClient } from '../lib/instagram-client';

type InstagramAccount = Database['public']['Tables']['instagram_accounts']['Row'];
type AutoReplyRule = Database['public']['Tables']['auto_reply_rules']['Row'];

export function Accounts() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<InstagramAccount[]>([]);
  const [rules, setRules] = useState<Record<string, AutoReplyRule[]>>({});
  const [loading, setLoading] = useState(true);
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [showAddRule, setShowAddRule] = useState<string | null>(null);

  const [newAccount, setNewAccount] = useState({
    username: '',
    password: '',
    deviceType: 'ios' as 'ios' | 'android',
  });

  const [deviceFingerprint, setDeviceFingerprint] = useState<DeviceFingerprint | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  const [newRule, setNewRule] = useState({
    trigger_type: 'dm' as 'dm' | 'comment' | 'mention' | 'all',
    keyword: '',
    reply_message: '',
  });

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!user) return;

    try {
      const accountsRes = await supabase
        .from('instagram_accounts')
        .select('*')
        .order('created_at', { ascending: false });

      if (accountsRes.data) {
        setAccounts(accountsRes.data);

        const rulesMap: Record<string, AutoReplyRule[]> = {};
        for (const account of accountsRes.data) {
          const rulesRes = await supabase
            .from('auto_reply_rules')
            .select('*')
            .eq('instagram_account_id', account.id)
            .order('priority', { ascending: true });

          if (rulesRes.data) {
            rulesMap[account.id] = rulesRes.data;
          }
        }
        setRules(rulesMap);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateDevice = () => {
    const fingerprint = createDeviceFingerprint(undefined, newAccount.deviceType);
    setDeviceFingerprint(fingerprint);
  };

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!deviceFingerprint) {
      alert('Please generate device fingerprint first!');
      return;
    }

    if (!newAccount.username || !newAccount.password) {
      alert('Please enter username and password!');
      return;
    }

    setLoginLoading(true);

    try {
      const igClient = createInstagramClient(deviceFingerprint);
      const loginResult = await igClient.login(newAccount.username, newAccount.password);

      if (!loginResult.success) {
        alert(`Instagram login failed: ${loginResult.error}`);
        setLoginLoading(false);
        return;
      }

      const { error } = await supabase.from('instagram_accounts').insert({
        user_id: user.id,
        username: newAccount.username,
        account_id: loginResult.user!.pk,
        access_token: loginResult.session!.cookies,
        is_active: true,
        device_id: deviceFingerprint.device_id,
        device_info: deviceFingerprint,
      });

      if (error) throw error;

      setShowAddAccount(false);
      setNewAccount({ username: '', password: '', deviceType: 'ios' });
      setDeviceFingerprint(null);
      setLoginLoading(false);
      fetchData();
      alert(`✅ Account @${loginResult.user!.username} added successfully!\nDevice: ${getDeviceInfo(deviceFingerprint)}`);
    } catch (error: any) {
      alert('Error: ' + error.message);
      setLoginLoading(false);
    }
  };

  const handleAddRule = async (accountId: string, e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { error } = await supabase.from('auto_reply_rules').insert({
        instagram_account_id: accountId,
        trigger_type: newRule.trigger_type,
        keyword: newRule.keyword || null,
        reply_message: newRule.reply_message,
        is_active: true,
      });

      if (error) throw error;

      setShowAddRule(null);
      setNewRule({ trigger_type: 'dm', keyword: '', reply_message: '' });
      fetchData();
    } catch (error: any) {
      alert('Error adding rule: ' + error.message);
    }
  };

  const toggleAccountActive = async (accountId: string, currentState: boolean) => {
    try {
      const { error } = await supabase
        .from('instagram_accounts')
        .update({ is_active: !currentState })
        .eq('id', accountId);

      if (error) throw error;
      fetchData();
    } catch (error: any) {
      alert('Error updating account: ' + error.message);
    }
  };

  const toggleRuleActive = async (ruleId: string, currentState: boolean) => {
    try {
      const { error } = await supabase
        .from('auto_reply_rules')
        .update({ is_active: !currentState })
        .eq('id', ruleId);

      if (error) throw error;
      fetchData();
    } catch (error: any) {
      alert('Error updating rule: ' + error.message);
    }
  };

  const deleteRule = async (ruleId: string) => {
    if (!confirm('Are you sure you want to delete this rule?')) return;

    try {
      const { error } = await supabase
        .from('auto_reply_rules')
        .delete()
        .eq('id', ruleId);

      if (error) throw error;
      fetchData();
    } catch (error: any) {
      alert('Error deleting rule: ' + error.message);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <button
              onClick={() => navigate('/')}
              className="text-xl font-bold text-white hover:text-slate-300 transition"
            >
              Instagram Auto-Reply Bot
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-white">Instagram Accounts</h1>
          <button
            onClick={() => setShowAddAccount(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
          >
            Add Account
          </button>
        </div>

        {showAddAccount && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-slate-800 rounded-xl p-6 w-full max-w-md border border-white/20">
              <h2 className="text-xl font-bold text-white mb-4">Add Instagram Account</h2>
              <form onSubmit={handleAddAccount} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Instagram Username
                  </label>
                  <input
                    type="text"
                    value={newAccount.username}
                    onChange={(e) => setNewAccount({ ...newAccount, username: e.target.value })}
                    required
                    disabled={loginLoading}
                    className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white disabled:opacity-50"
                    placeholder="your_instagram_username"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Instagram Password
                  </label>
                  <input
                    type="password"
                    value={newAccount.password}
                    onChange={(e) => setNewAccount({ ...newAccount, password: e.target.value })}
                    required
                    disabled={loginLoading}
                    className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white disabled:opacity-50"
                    placeholder="••••••••"
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Secure login via Instagram Private API with device fingerprint
                  </p>
                </div>

                <div className="border-t border-white/10 pt-4">
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Device Type
                  </label>
                  <div className="flex gap-3 mb-3">
                    <button
                      type="button"
                      onClick={() => setNewAccount({ ...newAccount, deviceType: 'ios' })}
                      className={`flex-1 py-2 rounded-lg transition ${
                        newAccount.deviceType === 'ios'
                          ? 'bg-blue-600 text-white'
                          : 'bg-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                    >
                      iOS
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewAccount({ ...newAccount, deviceType: 'android' })}
                      className={`flex-1 py-2 rounded-lg transition ${
                        newAccount.deviceType === 'android'
                          ? 'bg-green-600 text-white'
                          : 'bg-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                    >
                      Android
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleGenerateDevice}
                    disabled={loginLoading}
                    className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition mb-3 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Generate Device Fingerprint
                  </button>

                  {deviceFingerprint && (
                    <div className="p-3 bg-green-500/10 border border-green-500/50 rounded-lg">
                      <div className="text-xs font-semibold text-green-400 mb-1">Device Generated:</div>
                      <div className="text-sm text-white mb-1">{deviceFingerprint.device_model}</div>
                      <div className="text-xs text-slate-400">
                        {deviceFingerprint.device_type.toUpperCase()} {deviceFingerprint.os_version} • {deviceFingerprint.app_version}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        {deviceFingerprint.screen_resolution} • {deviceFingerprint.language}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  <button
                    type="submit"
                    disabled={!deviceFingerprint || loginLoading}
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loginLoading ? 'Logging in...' : 'Login & Add Account'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddAccount(false);
                      setDeviceFingerprint(null);
                      setNewAccount({ username: '', password: '', deviceType: 'ios' });
                    }}
                    disabled={loginLoading}
                    className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {accounts.map((account) => (
            <div
              key={account.id}
              className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-white">@{account.username}</h3>
                  <p className="text-sm text-slate-400">ID: {account.account_id}</p>
                  {account.device_info && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        (account.device_info as any).device_type === 'ios'
                          ? 'bg-blue-500/20 text-blue-300'
                          : 'bg-green-500/20 text-green-300'
                      }`}>
                        {((account.device_info as any).device_type as string).toUpperCase()}
                      </span>
                      <span className="text-xs text-slate-400">
                        {(account.device_info as any).device_model}
                      </span>
                      <span className="text-xs text-slate-500">
                        • v{(account.device_info as any).app_version}
                      </span>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => toggleAccountActive(account.id, account.is_active)}
                  className={`px-4 py-2 rounded-lg transition ${
                    account.is_active
                      ? 'bg-green-600 hover:bg-green-700'
                      : 'bg-gray-600 hover:bg-gray-700'
                  } text-white`}
                >
                  {account.is_active ? 'Active' : 'Inactive'}
                </button>
              </div>

              <div className="mt-6">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="font-medium text-white">Auto-Reply Rules</h4>
                  <button
                    onClick={() => setShowAddRule(account.id)}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition"
                  >
                    Add Rule
                  </button>
                </div>

                {showAddRule === account.id && (
                  <form
                    onSubmit={(e) => handleAddRule(account.id, e)}
                    className="mb-4 p-4 bg-white/5 rounded-lg space-y-3"
                  >
                    <div>
                      <label className="block text-sm text-slate-300 mb-1">Trigger Type</label>
                      <select
                        value={newRule.trigger_type}
                        onChange={(e) => setNewRule({ ...newRule, trigger_type: e.target.value as any })}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded text-white"
                      >
                        <option value="dm">Direct Message</option>
                        <option value="comment">Comment</option>
                        <option value="mention">Mention</option>
                        <option value="all">All Types</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm text-slate-300 mb-1">
                        Keyword (optional)
                      </label>
                      <input
                        type="text"
                        value={newRule.keyword}
                        onChange={(e) => setNewRule({ ...newRule, keyword: e.target.value })}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded text-white"
                        placeholder="Leave empty to reply to all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-slate-300 mb-1">Reply Message</label>
                      <textarea
                        value={newRule.reply_message}
                        onChange={(e) => setNewRule({ ...newRule, reply_message: e.target.value })}
                        required
                        rows={3}
                        className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded text-white"
                        placeholder="Thank you for your message!"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition"
                      >
                        Save Rule
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddRule(null)}
                        className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded-lg transition"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}

                <div className="space-y-2">
                  {rules[account.id]?.length ? (
                    rules[account.id].map((rule) => (
                      <div
                        key={rule.id}
                        className="p-3 bg-white/5 rounded-lg flex justify-between items-start"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-300 rounded">
                              {rule.trigger_type}
                            </span>
                            {rule.keyword && (
                              <span className="text-xs text-slate-400">
                                Keyword: {rule.keyword}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-slate-300">{rule.reply_message}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => toggleRuleActive(rule.id, rule.is_active)}
                            className={`px-3 py-1 text-xs rounded transition ${
                              rule.is_active
                                ? 'bg-green-600/20 text-green-300'
                                : 'bg-gray-600/20 text-gray-300'
                            }`}
                          >
                            {rule.is_active ? 'On' : 'Off'}
                          </button>
                          <button
                            onClick={() => deleteRule(rule.id)}
                            className="px-3 py-1 text-xs bg-red-600/20 text-red-300 rounded hover:bg-red-600/30 transition"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-slate-400 text-sm">
                      No rules yet. Add a rule to start auto-replying.
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {accounts.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              No accounts yet. Click "Add Account" to get started.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
