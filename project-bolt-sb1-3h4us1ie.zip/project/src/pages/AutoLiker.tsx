import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAutomation } from '../hooks/useAutomation';

export function AutoLiker() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [settings, setSettings] = useState<any>(null);
  const [likedPosts, setLikedPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { getDailyLimits } = useAutomation(selectedAccountId || null);
  const [dailyStats, setDailyStats] = useState<any>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadAccounts();
  }, [user, navigate]);

  useEffect(() => {
    if (selectedAccountId) {
      loadSettings();
      loadLikedPosts();
      loadDailyStats();
    }
  }, [selectedAccountId]);

  const loadAccounts = async () => {
    const { data } = await supabase
      .from('instagram_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && data.length > 0) {
      setAccounts(data);
      setSelectedAccountId(data[0].id);
    }
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from('auto_liker_settings')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .maybeSingle();

    setSettings(data || {
      enabled: false,
      target_type: 'hashtags',
      target_hashtags: [],
      target_usernames: [],
      target_locations: [],
      like_ratio: 0.6,
      scroll_before_like: true,
      view_duration_seconds: 5,
      skip_already_liked: true,
      daily_limit: 300,
    });
  };

  const loadLikedPosts = async () => {
    const { data } = await supabase
      .from('post_likes')
      .select('*')
      .eq('instagram_account_id', selectedAccountId)
      .order('liked_at', { ascending: false })
      .limit(50);

    setLikedPosts(data || []);
  };

  const loadDailyStats = async () => {
    if (!getDailyLimits) return;
    const limits = await getDailyLimits();
    const likeLimit = limits.find(l => l.action_type === 'like');
    setDailyStats(likeLimit);
  };

  const handleSave = async () => {
    if (!selectedAccountId) return;

    setSaving(true);

    try {
      const { data: existing } = await supabase
        .from('auto_liker_settings')
        .select('id')
        .eq('instagram_account_id', selectedAccountId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('auto_liker_settings')
          .update(settings)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('auto_liker_settings')
          .insert({ ...settings, instagram_account_id: selectedAccountId });
      }

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-slate-300 hover:text-white transition"
              >
                ← Back
              </button>
              <h1 className="text-xl font-bold text-white">Auto Liker</h1>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">Auto Liker Settings</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <span className="text-slate-300">Enabled</span>
                  <input
                    type="checkbox"
                    checked={settings?.enabled || false}
                    onChange={(e) => handleChange('enabled', e.target.checked)}
                    className="w-5 h-5 rounded bg-white/10 border-white/20"
                  />
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Target Type
                  </label>
                  <select
                    value={settings?.target_type || 'hashtags'}
                    onChange={(e) => handleChange('target_type', e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="hashtags">Hashtags</option>
                    <option value="users">Specific Users</option>
                    <option value="locations">Locations</option>
                    <option value="explore">Explore Page</option>
                    <option value="followers">My Followers</option>
                    <option value="following">People I Follow</option>
                  </select>
                </div>

                {settings?.target_type === 'hashtags' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Hashtags (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_hashtags || []).join('\n')}
                      onChange={(e) => handleChange('target_hashtags', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="fashion&#10;style&#10;ootd"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Enter hashtags without the # symbol
                    </p>
                  </div>
                )}

                {settings?.target_type === 'users' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Usernames (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_usernames || []).join('\n')}
                      onChange={(e) => handleChange('target_usernames', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="username1&#10;username2"
                    />
                  </div>
                )}

                {settings?.target_type === 'locations' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Target Locations (one per line)
                    </label>
                    <textarea
                      value={(settings?.target_locations || []).join('\n')}
                      onChange={(e) => handleChange('target_locations', e.target.value.split('\n').filter(Boolean))}
                      rows={5}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="New York&#10;Los Angeles"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Like Ratio (0-1)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="1"
                    step="0.1"
                    value={settings?.like_ratio || 0.6}
                    onChange={(e) => handleChange('like_ratio', parseFloat(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Percentage of posts to like (0.6 = 60%)
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    View Duration (seconds)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={settings?.view_duration_seconds || 5}
                    onChange={(e) => handleChange('view_duration_seconds', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    How long to view post before liking
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Daily Limit
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="1000"
                    value={settings?.daily_limit || 300}
                    onChange={(e) => handleChange('daily_limit', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                </div>

                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.scroll_before_like || false}
                      onChange={(e) => handleChange('scroll_before_like', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Scroll before liking (more human-like)</span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings?.skip_already_liked || false}
                      onChange={(e) => handleChange('skip_already_liked', e.target.checked)}
                      className="w-5 h-5 rounded bg-white/10 border-white/20"
                    />
                    <span className="text-white">Skip already liked posts</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              {dailyStats ? (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300">Posts Liked</span>
                    <span className="text-white font-semibold">
                      {dailyStats.current_count} / {dailyStats.limit_count}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-pink-500 to-red-500 rounded-full transition-all"
                      style={{ width: `${Math.min(dailyStats.percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    {dailyStats.percentage.toFixed(1)}% of daily limit used
                  </p>
                </div>
              ) : (
                <p className="text-slate-400">No data available</p>
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Recent Likes</h3>
              {likedPosts.length === 0 ? (
                <p className="text-slate-400 text-center py-4">No posts liked yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {likedPosts.map((like) => (
                    <div key={like.id} className="p-3 bg-white/5 rounded-lg">
                      <div className="text-white font-medium">@{like.post_owner_username}</div>
                      <div className="text-xs text-slate-400">
                        {new Date(like.liked_at).toLocaleString()}
                      </div>
                      {like.post_url && (
                        <a
                          href={like.post_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-blue-400 hover:text-blue-300"
                        >
                          View Post →
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
