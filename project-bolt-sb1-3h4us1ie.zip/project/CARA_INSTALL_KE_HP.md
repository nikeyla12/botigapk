# 📱 CARA LENGKAP: BUILD & INSTALL APK KE HP

## 🎯 STEP-BY-STEP DARI NOL SAMPAI INSTALL DI HP

**Lu udah install Android Studio? Perfect! Tinggal ikutin langkah ini:**

---

## 📋 YANG LU BUTUHIN:

1. ✅ Android Studio (udah installed)
2. ✅ HP Android (untuk testing)
3. ✅ Kabel USB (untuk connect HP ke PC)
4. ✅ Project ini (udah ready!)

---

## 🚀 LANGKAH 1: SYNC PROJECT DI ANDROID STUDIO

### **1.1 - Buka Project di Android Studio**

**Dari Terminal/Command Prompt:**

```bash
# Masuk ke folder project
cd /path/to/project

# Build web app dulu
npm run build

# Sync ke Android
npx cap sync android

# Buka di Android Studio
npx cap open android
```

**ATAU Manual:**

1. Buka Android Studio
2. Click **File > Open**
3. Pilih folder: **`/path/to/project/android`**
4. Click **OK**
5. Wait 1-2 menit (Gradle sync)

---

### **1.2 - Wait for Gradle Sync**

**Kalo muncul error "Gradle sync failed":**

1. Click **File > Sync Project with Gradle Files**
2. Wait lagi 1-2 menit
3. Kalo masih error, click **Build > Clean Project**
4. Terus **Build > Rebuild Project**

**Progress bar di bottom akan muncul:**
```
Gradle sync...
Building 'android' (1/5)
Building 'app' (2/5)
...
BUILD SUCCESSFUL
```

---

## 🔧 LANGKAH 2: SETUP DEVICE (HP)

### **2.1 - Enable Developer Options di HP**

**Cara aktifkan:**

1. Buka **Settings** di HP
2. Cari **About Phone** (atau **About Device**)
3. Cari **Build Number**
4. **TAP 7 KALI** di Build Number
5. Muncul: "You are now a developer!"

**Lokasi beda-beda per brand:**
- Samsung: Settings > About Phone > Software Information > Build Number
- Xiaomi: Settings > About Phone > MIUI Version (tap 7x)
- Oppo: Settings > About Phone > Version > Build Number
- Vivo: Settings > About Phone > Software Version > Build Number
- Realme: Settings > About Phone > Version > Build Number

---

### **2.2 - Enable USB Debugging**

1. Balik ke **Settings**
2. Cari **Developer Options** (atau **Developer Settings**)
3. Scroll ke bawah
4. Enable **USB Debugging**
5. Muncul popup, click **OK**

---

### **2.3 - Connect HP ke PC**

1. Colokin kabel USB dari HP ke PC
2. Di HP muncul popup: "Allow USB Debugging?"
3. ✅ Centang: "Always allow from this computer"
4. Click **Allow** (atau **OK**)

**Kalo gak muncul popup:**
- Cabut kabel, colok lagi
- Atau ganti kabel USB (some cables data-only)
- Atau coba port USB lain di PC

---

### **2.4 - Verify Device Connected**

**Di Android Studio:**

1. Liat toolbar di atas
2. Cari dropdown device (sebelah tombol Run ▶️)
3. Kalo HP lu udah connected, akan muncul nama HP

**Contoh:**
```
Samsung Galaxy S24 (API 34)
Xiaomi 14 Pro (API 33)
Oppo Find X7 (API 34)
```

**Kalo belum muncul:**
1. Click dropdown device
2. Click **Troubleshoot Device Connections**
3. Follow instructions
4. Atau restart Android Studio

---

## 🏗️ LANGKAH 3: BUILD & INSTALL (RUN)

### **3.1 - Run di Device (Testing)**

**Cara tercepat untuk testing:**

1. Click tombol **Run ▶️** (atau tekan Shift + F10)
2. Wait 2-5 menit (first build takes time)
3. App otomatis ke-install & terbuka di HP!

**Progress:**
```
Building...
Gradle build running...
:app:assembleDebug
Installing APK...
Launching app...
BUILD SUCCESSFUL in 2m 15s
```

**First time:**
- Download dependencies: 1-2 menit
- Build project: 2-3 menit
- Install: 10-20 detik
- **TOTAL: 3-5 menit**

**Next time (udah di-build sekali):**
- Build incremental: 30 detik - 1 menit
- Install: 10 detik
- **TOTAL: 40 detik - 1 menit**

---

### **3.2 - Troubleshooting Build Errors**

**Error: "SDK not found"**

```bash
# Fix:
# Di Android Studio:
Tools > SDK Manager > Install SDK
```

**Error: "Gradle version incompatible"**

```bash
# Fix:
# Di Android Studio:
File > Project Structure > Project > Gradle Version
# Set to: Latest version
```

**Error: "JAVA_HOME not set"**

```bash
# Fix:
# Di Android Studio:
File > Settings > Build, Execution, Deployment > Build Tools > Gradle
# Set: Gradle JDK to "Embedded JDK"
```

**Error: "Device offline" atau "unauthorized"**

```bash
# Fix:
# 1. Cabut kabel USB
# 2. Di HP: Settings > Developer Options > Revoke USB Debugging
# 3. Colok kabel lagi
# 4. Allow USB Debugging lagi
```

---

## 📦 LANGKAH 4: BUILD APK FILE (Optional)

### **4.1 - Build Debug APK**

**Kalo lu mau APK file untuk share atau backup:**

**Via Android Studio:**

1. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**
2. Wait 1-2 menit
3. Popup muncul: **"APK(s) generated successfully"**
4. Click **locate**

**Lokasi APK:**
```
/path/to/project/android/app/build/outputs/apk/debug/app-debug.apk
```

**Via Command Line:**

```bash
# Dari folder project
cd android
./gradlew assembleDebug

# APK ada di:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

### **4.2 - Install APK Manual ke HP**

**Cara 1: Via ADB (dari PC)**

```bash
# Install via ADB
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Kalo udah installed sebelumnya:
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

**Cara 2: Copy File ke HP**

1. Copy file `app-debug.apk` ke HP (via USB, Bluetooth, atau upload)
2. Di HP, buka File Manager
3. Tap `app-debug.apk`
4. Muncul: "Install blocked" (first time)
5. Click **Settings**
6. Enable **"Allow from this source"**
7. Back, tap APK lagi
8. Click **Install**
9. Wait 5-10 detik
10. Click **Open**

---

### **4.3 - Build Release APK (Production)**

**Untuk production/publish ke Play Store:**

**Step 1: Generate Keystore**

```bash
# Di folder project/android
keytool -genkey -v -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

# Isi data:
# Password: [password lu, JANGAN LUPA!]
# First and Last Name: [Nama lu]
# Organizational Unit: [Nama company]
# ...dst
```

**Step 2: Configure Gradle**

Create file: `android/key.properties`

```properties
storePassword=[password keystore]
keyPassword=[password key]
keyAlias=my-key-alias
storeFile=my-release-key.keystore
```

**Step 3: Update build.gradle**

File: `android/app/build.gradle`

Add before `android {}`:

```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
```

Add inside `android {}`:

```gradle
signingConfigs {
    release {
        keyAlias keystoreProperties['keyAlias']
        keyPassword keystoreProperties['keyPassword']
        storeFile file(keystoreProperties['storeFile'])
        storePassword keystoreProperties['storePassword']
    }
}

buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false
        proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
    }
}
```

**Step 4: Build Release**

```bash
cd android
./gradlew assembleRelease

# APK ada di:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🎯 LANGKAH 5: TESTING DI HP

### **5.1 - First Launch**

**Saat app pertama kali dibuka:**

1. ✅ App icon muncul di home screen
2. ✅ Tap icon, app terbuka
3. ✅ Loading screen muncul
4. ✅ Login page muncul

**Kalo stuck di splash screen:**
- Wait 10-20 detik (first load)
- Atau force close & buka lagi

---

### **5.2 - Check Permissions**

**Android akan auto-request permissions yang lu butuhin:**

1. Internet access → AUTO (no prompt)
2. Network state → AUTO (no prompt)
3. Other permissions → Prompt saat dibutuhin

**Kalo ada issue permissions:**
1. Settings > Apps > [App Name]
2. Permissions
3. Enable manually

---

### **5.3 - Testing Features**

**Test Checklist:**

1. ✅ Login works
2. ✅ Add Instagram account
3. ✅ Generate device fingerprint
4. ✅ Login to Instagram works
5. ✅ Account shows in list
6. ✅ Navigation works
7. ✅ All pages load
8. ✅ Automation features work

---

## 🔄 LANGKAH 6: UPDATE APP (Setiap Kali Edit Code)

### **6.1 - Update Process**

**Setiap kali lu edit code:**

```bash
# 1. Build web app
npm run build

# 2. Sync ke Android
npx cap sync android

# 3. Run di HP (di Android Studio)
# Click tombol Run ▶️

# ATAU build APK baru
cd android
./gradlew assembleDebug
```

---

### **6.2 - Hot Reload (Optional)**

**Untuk development cepat:**

```bash
# Run dev server
npm run dev

# Di file capacitor.config.json, set:
{
  "server": {
    "url": "http://192.168.1.100:5173",
    "cleartext": true
  }
}

# Sync
npx cap sync android

# Run di Android Studio
# App akan load dari dev server (live reload!)
```

**Ganti IP `192.168.1.100` dengan IP PC lu di local network.**

**Cara cek IP PC:**

Windows:
```bash
ipconfig
# Cari: IPv4 Address
```

Mac/Linux:
```bash
ifconfig
# Cari: inet [IP]
```

---

## 🎨 LANGKAH 7: CUSTOM APP ICON & NAME (Optional)

### **7.1 - Change App Name**

**File:** `android/app/src/main/res/values/strings.xml`

```xml
<resources>
    <string name="app_name">Instagram Auto Bot</string>
    <string name="title_activity_main">Instagram Auto Bot</string>
</resources>
```

**Ganti "Instagram Auto Bot" dengan nama app lu.**

---

### **7.2 - Change App Icon**

**Butuh icon dalam beberapa ukuran:**

- mipmap-mdpi: 48x48
- mipmap-hdpi: 72x72
- mipmap-xhdpi: 96x96
- mipmap-xxhdpi: 144x144
- mipmap-xxxhdpi: 192x192

**Easy way - pakai tool:**

1. Buat icon 512x512 (PNG)
2. Upload ke: https://romannurik.github.io/AndroidAssetStudio/
3. Choose "Launcher icons"
4. Upload image
5. Download ZIP
6. Extract & replace files di: `android/app/src/main/res/`

---

## 📊 LANGKAH 8: CHECK APK SIZE

### **8.1 - Analyze APK**

**Di Android Studio:**

1. Build > Analyze APK
2. Select APK file
3. See breakdown:
   - Total size
   - Resources size
   - Native libraries
   - DEX files
   - etc

**Expected size:**
- Debug APK: ~50-80 MB
- Release APK (minified): ~30-50 MB

---

## 🚨 COMMON ISSUES & FIXES

### **Issue 1: "App not installed"**

**Fix:**
```
1. Uninstall app first
2. Install again
```

### **Issue 2: "Parse error"**

**Fix:**
```
APK corrupted or incompatible
- Re-download APK
- Atau rebuild
```

### **Issue 3: "Device not compatible"**

**Fix:**
```
Check minSdkVersion di build.gradle
Should be 22 or lower untuk old devices
```

### **Issue 4: "App crashes on launch"**

**Fix:**
```
1. Check logcat di Android Studio
2. View > Tool Windows > Logcat
3. Filter by app package name
4. Look for errors
```

### **Issue 5: "White screen / stuck"**

**Fix:**
```
1. Check if web app built correctly
2. npm run build
3. npx cap sync android
4. Try again
```

---

## 🎯 QUICK REFERENCE

### **Build Commands:**

```bash
# Build web app
npm run build

# Sync to Android
npx cap sync android

# Open Android Studio
npx cap open android

# Build debug APK (via Gradle)
cd android
./gradlew assembleDebug

# Build release APK (via Gradle)
cd android
./gradlew assembleRelease

# Install APK via ADB
adb install path/to/app.apk

# Uninstall app
adb uninstall com.instagram.automation
```

---

### **File Locations:**

```
Project Root:
├── android/                              # Android project folder
│   ├── app/
│   │   ├── build/
│   │   │   └── outputs/
│   │   │       └── apk/
│   │   │           ├── debug/
│   │   │           │   └── app-debug.apk      # Debug APK
│   │   │           └── release/
│   │   │               └── app-release.apk     # Release APK
│   │   └── src/
│   │       └── main/
│   │           ├── AndroidManifest.xml         # App manifest
│   │           └── res/
│   │               ├── values/
│   │               │   └── strings.xml         # App name
│   │               └── mipmap-*/
│   │                   └── ic_launcher.png     # App icons
│   └── build.gradle                            # Build config
└── capacitor.config.json                       # Capacitor config
```

---

## 📱 FINAL CHECKLIST

### **Before Release:**

- [ ] App name correct
- [ ] App icon looks good
- [ ] Version number updated
- [ ] All features working
- [ ] No crashes
- [ ] Performance good
- [ ] Memory usage OK
- [ ] Battery usage OK
- [ ] Network usage OK
- [ ] Permissions correct
- [ ] Release APK built
- [ ] APK signed
- [ ] APK tested on multiple devices

---

## 🎊 SUCCESS!

**Kalo semua langkah udah diikutin, lu sekarang punya:**

1. ✅ App running di HP lu
2. ✅ APK file untuk share/backup
3. ✅ Bisa install di HP manapun
4. ✅ Ready untuk production!

**Next steps:**

1. Test semua features
2. Fix bugs (kalo ada)
3. Polish UI/UX
4. Build release APK
5. Distribute atau publish!

---

## 💡 TIPS PRO

### **Development:**

1. **Use Android Emulator** untuk testing cepat (tanpa HP)
   - Android Studio > Tools > AVD Manager
   - Create Virtual Device
   - Choose device model
   - Choose system image (API 33 atau 34)
   - Launch emulator

2. **Enable Instant Run** untuk faster builds
   - File > Settings > Build, Execution, Deployment > Compiler
   - Enable "Build project automatically"

3. **Use Logcat** untuk debugging
   - View > Tool Windows > Logcat
   - Filter errors dengan "Error" atau "Exception"

4. **Profile App** untuk optimize performance
   - Run > Profile 'app'
   - Check CPU, Memory, Network usage

---

## 🔥 DONE BRO!

**Lu sekarang tau cara:**
- ✅ Buka project di Android Studio
- ✅ Setup HP untuk development
- ✅ Run app di HP
- ✅ Build APK file
- ✅ Install APK di HP
- ✅ Update app setiap edit
- ✅ Troubleshoot issues
- ✅ Optimize & release

**Kalo ada masalah, check troubleshooting section atau tanya gua!**

Good luck building your Instagram automation empire! 🚀💎
