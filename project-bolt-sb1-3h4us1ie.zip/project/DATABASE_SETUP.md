# Database Setup Instructions

## Overview
This Instagram Auto-Reply Bot uses Supabase as the database. The database schema needs to be set up manually via the Supabase SQL Editor.

## Database Schema

### Tables

#### 1. instagram_accounts
Stores Instagram account credentials and configuration.

```sql
CREATE TABLE IF NOT EXISTS instagram_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  access_token text NOT NULL,
  account_id text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, username)
);
```

#### 2. auto_reply_rules
Defines auto-reply rules and triggers.

```sql
CREATE TABLE IF NOT EXISTS auto_reply_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  trigger_type text NOT NULL CHECK (trigger_type IN ('dm', 'comment', 'mention', 'all')),
  keyword text,
  reply_message text NOT NULL,
  is_active boolean DEFAULT true,
  priority integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
```

#### 3. messages
Tracks all incoming messages and sent replies.

```sql
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  sender_username text NOT NULL,
  sender_id text NOT NULL,
  message_type text NOT NULL CHECK (message_type IN ('dm', 'comment', 'mention')),
  message_text text NOT NULL,
  reply_text text,
  rule_id uuid REFERENCES auto_reply_rules(id) ON DELETE SET NULL,
  status text DEFAULT 'received' CHECK (status IN ('received', 'replied', 'failed', 'ignored')),
  received_at timestamptz DEFAULT now(),
  replied_at timestamptz,
  created_at timestamptz DEFAULT now()
);
```

#### 4. analytics
Aggregated analytics data per account per day.

```sql
CREATE TABLE IF NOT EXISTS analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  date date NOT NULL,
  total_messages integer DEFAULT 0,
  total_replies integer DEFAULT 0,
  total_dms integer DEFAULT 0,
  total_comments integer DEFAULT 0,
  total_mentions integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, date)
);
```

### Indexes

```sql
CREATE INDEX IF NOT EXISTS idx_instagram_accounts_user_id ON instagram_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_auto_reply_rules_account_id ON auto_reply_rules(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_messages_account_id ON messages(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_messages_received_at ON messages(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_analytics_account_date ON analytics(instagram_account_id, date DESC);
```

### Row Level Security (RLS)

Enable RLS on all tables:

```sql
ALTER TABLE instagram_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_reply_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;
```

#### RLS Policies for instagram_accounts

```sql
CREATE POLICY "Users can view own Instagram accounts"
  ON instagram_accounts FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own Instagram accounts"
  ON instagram_accounts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own Instagram accounts"
  ON instagram_accounts FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own Instagram accounts"
  ON instagram_accounts FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
```

#### RLS Policies for auto_reply_rules

```sql
CREATE POLICY "Users can view own auto-reply rules"
  ON auto_reply_rules FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = auto_reply_rules.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can insert own auto-reply rules"
  ON auto_reply_rules FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = auto_reply_rules.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can update own auto-reply rules"
  ON auto_reply_rules FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = auto_reply_rules.instagram_account_id AND instagram_accounts.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = auto_reply_rules.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can delete own auto-reply rules"
  ON auto_reply_rules FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = auto_reply_rules.instagram_account_id AND instagram_accounts.user_id = auth.uid()));
```

#### RLS Policies for messages

```sql
CREATE POLICY "Users can view own messages"
  ON messages FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = messages.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can insert own messages"
  ON messages FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = messages.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can update own messages"
  ON messages FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = messages.instagram_account_id AND instagram_accounts.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = messages.instagram_account_id AND instagram_accounts.user_id = auth.uid()));
```

#### RLS Policies for analytics

```sql
CREATE POLICY "Users can view own analytics"
  ON analytics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = analytics.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can insert own analytics"
  ON analytics FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = analytics.instagram_account_id AND instagram_accounts.user_id = auth.uid()));

CREATE POLICY "Users can update own analytics"
  ON analytics FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = analytics.instagram_account_id AND instagram_accounts.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM instagram_accounts WHERE instagram_accounts.id = analytics.instagram_account_id AND instagram_accounts.user_id = auth.uid()));
```

### Triggers

```sql
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_instagram_accounts_updated_at
  BEFORE UPDATE ON instagram_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_auto_reply_rules_updated_at
  BEFORE UPDATE ON auto_reply_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_analytics_updated_at
  BEFORE UPDATE ON analytics FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

## Setup Steps

1. Open your Supabase project dashboard
2. Navigate to the SQL Editor
3. Copy and paste all the SQL statements above (in order)
4. Execute them to create the database schema
5. Verify that all tables, indexes, policies, and triggers have been created successfully

## Edge Function Setup

The Edge Function for handling Instagram webhooks is located at:
`supabase/functions/instagram-webhook/index.ts`

To deploy it manually via Supabase CLI:
```bash
supabase functions deploy instagram-webhook --no-verify-jwt
```

Note: The `--no-verify-jwt` flag is used because this is a public webhook endpoint that Instagram will call directly.

## Important Notes

- All user data is protected by Row Level Security (RLS)
- Users can only access their own Instagram accounts and related data
- Access tokens are stored in the database and should be encrypted at the application level for production use
- The webhook function requires Instagram API access tokens to send replies
- Analytics data is aggregated daily and can be used for reporting

## Instagram API Setup

To use this bot, you need to:

1. Create a Facebook Developer account
2. Create a Facebook App
3. Add Instagram Basic Display or Instagram Graph API
4. Get the required access tokens and account IDs
5. Configure webhook subscriptions pointing to your Edge Function URL
6. Use the verify token: `instagram_webhook_token`
