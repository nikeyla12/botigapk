# 🚀 QUICK START - 5 MENIT INSTALL KE HP!

## ✅ LU UDAH PUNYA: Android Studio

## 🎯 LANGKAH SINGKAT:

---

## 1️⃣ BUILD WEB APP (30 detik)

```bash
npm run build
```

**Output:**
```
✓ built in 5.33s
```

---

## 2️⃣ SYNC KE ANDROID (20 detik)

```bash
npx cap sync android
```

**Output:**
```
✔ Copying web assets from dist to android/app/src/main/assets/public in 2.45s
✔ Creating capacitor.config.json in android/app/src/main/assets in 1.23ms
✔ Updating Android plugins in 45.67ms
✔ Syncing Gradle in 1.23s
✔ update android in 3.78s
```

---

## 3️⃣ BUKA DI ANDROID STUDIO (10 detik)

```bash
npx cap open android
```

**Atau manual:**
1. Buka Android Studio
2. File > Open
3. Pilih folder: `android`

---

## 4️⃣ SETUP HP (2 menit)

### **A. Enable Developer Mode:**
1. Settings > About Phone
2. Tap **Build Number** 7 kali
3. Muncul: "You are now a developer!"

### **B. Enable USB Debugging:**
1. Settings > Developer Options
2. ON: **USB Debugging**

### **C. Connect HP:**
1. Colok USB ke PC
2. Di HP: Allow USB Debugging
3. ✅ Always allow from this computer

---

## 5️⃣ RUN APP (2 menit)

**Di Android Studio:**

1. Wait Gradle sync selesai (bottom progress bar)
2. Pilih HP lu di dropdown device (atas)
3. Click tombol **Run ▶️** (hijau)
4. Wait 2-3 menit (first build)
5. ✅ App otomatis terbuka di HP!

---

## ✅ DONE!

**App udah jalan di HP lu!**

---

## 🎯 NEXT TIME (UPDATE APP):

**Setiap kali edit code:**

```bash
# 1. Build
npm run build

# 2. Sync
npx cap sync android

# 3. Run di Android Studio (click ▶️)
```

**That's it!** 🎉

---

## 📦 OPTIONAL: BUILD APK FILE

**Kalo mau APK file untuk share:**

**Di Android Studio:**
1. Build > Build Bundle(s) / APK(s) > Build APK(s)
2. Wait 1-2 menit
3. Click **locate**

**APK location:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

**Install manual:**
1. Copy APK ke HP
2. Tap APK file
3. Install
4. Done!

---

## 🚨 TROUBLESHOOTING CEPAT

### **"Device not detected"**
```
✓ Cabut & colok USB lagi
✓ Atau: ADB > Troubleshoot Device Connections
```

### **"Gradle sync failed"**
```
✓ File > Sync Project with Gradle Files
✓ Atau: Build > Clean Project
```

### **"App crashes"**
```
✓ Check: View > Tool Windows > Logcat
✓ Look for red errors
```

### **"White screen"**
```
✓ npm run build
✓ npx cap sync android
✓ Run lagi
```

---

## 📚 DETAILED GUIDES:

Kalo butuh step-by-step lengkap, baca:

- **`CARA_INSTALL_KE_HP.md`** - Complete guide with troubleshooting
- **`BUILD_APK_COMPLETE_GUIDE.md`** - All build methods & configurations
- **`ANDROID_BUILD_INSTRUCTIONS.md`** - Original build instructions

---

## 🎊 THAT'S IT BRO!

**5 MENIT DARI CODE KE HP!**

1. ✅ Build web
2. ✅ Sync Android
3. ✅ Setup HP
4. ✅ Run app
5. ✅ DONE!

**Simple kan?** 🔥

Good luck! 🚀
