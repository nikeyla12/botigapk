# 🚀 DEPLOYMENT GUIDE - GO LIVE IN 5 MINUTES!

## ⚡ FASTEST WAY: VERCEL (RECOMMENDED)

### Step 1: Install Vercel CLI

```bash
npm install -g vercel
```

### Step 2: Login

```bash
vercel login
# Enter your email
# Click verification link
```

### Step 3: Deploy

```bash
# From project root
vercel --prod

# Follow prompts:
# - Set up and deploy? Y
# - Which scope? Your account
# - Link to existing project? N
# - Project name? instagram-automation
# - Directory? ./
# - Override settings? N
```

### Step 4: Done! 🎉

```
✅ Deployed to: https://instagram-automation-xxx.vercel.app
```

**Live URL in 2 minutes!**

---

## 🌐 OPTION 2: NETLIFY

### Step 1: Install Netlify CLI

```bash
npm install -g netlify-cli
```

### Step 2: Login

```bash
netlify login
```

### Step 3: Deploy

```bash
# Build first
npm run build

# Deploy
netlify deploy --prod --dir=dist
```

### Step 4: Done!

```
✅ Live: https://your-app.netlify.app
```

---

## 🔥 OPTION 3: FIREBASE HOSTING

### Step 1: Install Firebase CLI

```bash
npm install -g firebase-tools
```

### Step 2: Login

```bash
firebase login
```

### Step 3: Initialize

```bash
firebase init hosting

# Choose:
# - Use existing project or create new
# - Public directory: dist
# - Single page app: Yes
# - Automatic builds: No
```

### Step 4: Deploy

```bash
# Build first
npm run build

# Deploy
firebase deploy --only hosting
```

### Step 5: Done!

```
✅ Live: https://your-app.web.app
```

---

## 🎯 MOBILE APP DEPLOYMENT

### Android (APK Distribution)

#### Option A: Direct Distribution

```bash
# 1. Build release APK
cd android
./gradlew assembleRelease

# 2. APK location:
android/app/build/outputs/apk/release/app-release.apk

# 3. Share via:
# - Google Drive
# - Dropbox
# - Email
# - Direct download from your website
```

#### Option B: Google Play Store

```bash
# 1. Create Play Console account ($25)
https://play.google.com/console

# 2. Generate signed APK
# In Android Studio:
Build > Generate Signed Bundle / APK

# 3. Create app in Play Console
# 4. Upload APK
# 5. Fill store listing
# 6. Submit for review
# 7. Wait 3-7 days
# 8. LIVE ON PLAY STORE! 🎉
```

---

## 📱 PWA INSTALLATION (USERS)

### For Android Users:

1. Visit deployed URL in Chrome
2. Chrome shows "Add to Home Screen" banner
3. Tap "Add"
4. Icon appears on home screen
5. Works like native app!

### For iOS Users:

1. Visit URL in Safari
2. Tap Share button
3. Tap "Add to Home Screen"
4. Enter name
5. Tap "Add"
6. Done!

---

## 🔧 ENVIRONMENT VARIABLES

### For Vercel:

```bash
# Add via dashboard:
vercel.com > Project > Settings > Environment Variables

# Or via CLI:
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY

# Then redeploy:
vercel --prod
```

### For Netlify:

```bash
# Via dashboard:
app.netlify.com > Site > Settings > Environment Variables

# Or via CLI:
netlify env:set VITE_SUPABASE_URL "your-url"
netlify env:set VITE_SUPABASE_ANON_KEY "your-key"
```

### For Firebase:

```bash
# Set via CLI:
firebase functions:config:set supabase.url="your-url"
firebase functions:config:set supabase.key="your-key"

# Deploy:
firebase deploy
```

---

## 🎨 CUSTOM DOMAIN

### Vercel:

```bash
# 1. Go to: vercel.com > Project > Settings > Domains
# 2. Add domain: yourdomain.com
# 3. Update DNS records (Vercel provides)
# 4. Wait for verification (5-30 min)
# 5. SSL auto-configured!
```

### Netlify:

```bash
# 1. Go to: Site Settings > Domain Management
# 2. Add custom domain
# 3. Update DNS
# 4. Enable HTTPS (automatic)
```

---

## ⚙️ BUILD OPTIMIZATION

### Reduce Bundle Size:

```bash
# 1. Analyze bundle
npm run build
npx vite-bundle-visualizer

# 2. Code splitting
# Edit vite.config.js:
export default {
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          supabase: ['@supabase/supabase-js'],
          router: ['react-router-dom']
        }
      }
    }
  }
}

# 3. Rebuild
npm run build
```

### Enable Compression:

```js
// vite.config.js
import { defineConfig } from 'vite';
import { compression } from 'vite-plugin-compression';

export default defineConfig({
  plugins: [
    compression({
      algorithm: 'gzip',
      ext: '.gz'
    })
  ]
});
```

---

## 🔐 SECURITY CHECKLIST

Before going live:

- [ ] All Supabase RLS policies enabled
- [ ] Environment variables secured
- [ ] CORS configured properly
- [ ] API rate limiting enabled
- [ ] Input validation implemented
- [ ] SQL injection prevention
- [ ] XSS protection enabled
- [ ] HTTPS enforced
- [ ] No secrets in code
- [ ] Error messages sanitized

---

## 📊 MONITORING & ANALYTICS

### Add Google Analytics:

```html
<!-- Add to index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Sentry for Error Tracking:

```bash
npm install @sentry/react

# Add to main.tsx:
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: "production"
});
```

---

## 🚀 PERFORMANCE TIPS

### 1. Enable Caching:

```js
// In netlify.toml or vercel.json
{
  "headers": [
    {
      "source": "/assets/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ]
}
```

### 2. Lazy Load Routes:

```tsx
// App.tsx
import { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import('./pages/Dashboard'));
const Analytics = lazy(() => import('./pages/Analytics'));

function App() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/analytics" element={<Analytics />} />
      </Routes>
    </Suspense>
  );
}
```

### 3. Image Optimization:

```bash
# Use optimized images
npm install vite-plugin-image-optimizer

# Or use CDN:
# - Cloudinary
# - Imgix
# - ImageKit
```

---

## 📱 PROGRESSIVE WEB APP (PWA)

### Make it installable:

```bash
# 1. Install PWA plugin
npm install vite-plugin-pwa -D

# 2. Configure vite.config.js
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'Instagram Automation',
        short_name: 'InstaAuto',
        description: 'Instagram Growth & Automation Platform',
        theme_color: '#1e293b',
        background_color: '#0f172a',
        display: 'standalone',
        icons: [
          {
            src: '/icon-192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: '/icon-512.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      }
    })
  ]
});

# 3. Rebuild
npm run build
```

---

## 🐛 TROUBLESHOOTING

### Build Fails?

```bash
# Clear cache
rm -rf node_modules dist .vite
npm install
npm run build
```

### Environment Variables Not Working?

```bash
# Must start with VITE_
VITE_SUPABASE_URL=xxx

# Rebuild after adding
npm run build
vercel --prod
```

### White Screen After Deploy?

```bash
# Check base URL in vite.config.js
export default {
  base: '/'
}

# Or for subdirectory:
export default {
  base: '/subdir/'
}
```

---

## ✅ POST-DEPLOYMENT CHECKLIST

- [ ] App loads correctly
- [ ] All pages accessible
- [ ] Login/logout works
- [ ] Database connections work
- [ ] API calls succeed
- [ ] Images load
- [ ] Mobile responsive
- [ ] PWA installable
- [ ] Fast load times (<3s)
- [ ] No console errors

---

## 🎯 QUICK DEPLOY COMMANDS

```bash
# VERCEL (Fastest)
vercel --prod

# NETLIFY
npm run build && netlify deploy --prod --dir=dist

# FIREBASE
npm run build && firebase deploy --only hosting

# SURGE (Alternative)
npm i -g surge
npm run build && surge dist
```

---

## 💡 TIPS FOR SUCCESS

1. **Test locally first:**
```bash
npm run build
npm run preview
```

2. **Check bundle size:**
```bash
npm run build
# Look for "dist" folder size
```

3. **Test on mobile:**
```bash
# Use ngrok for mobile testing
npx ngrok http 5173
# Open URL on phone
```

4. **Monitor performance:**
```bash
# Use Lighthouse
# Chrome DevTools > Lighthouse > Run
```

---

## 🆘 SUPPORT

Need help?

- Vercel docs: https://vercel.com/docs
- Netlify docs: https://docs.netlify.com
- Firebase docs: https://firebase.google.com/docs
- Capacitor docs: https://capacitorjs.com

**Good luck going live! 🚀**
