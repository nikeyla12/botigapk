export default {
  plugins: [],
}
