/**
 * Instagram Service API Client
 * Communicates with Instagram automation FastAPI service
 */

import axios from 'axios';
import { logger } from '../utils/logger.js';

const INSTAGRAM_API_URL = process.env.INSTAGRAM_SERVICE_URL || 'http://localhost:8000';

export const instagramAPI = {
  /**
   * Authentication
   */
  async login(username, password, verificationCode = null) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/auth/login`, {
        username,
        password,
        verification_code: verificationCode
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API login error:', error.response?.data || error.message);
      throw error;
    }
  },

  async logout(username) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/auth/logout`, {
        username
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API logout error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getAccountInfo(username) {
    try {
      const response = await axios.get(`${INSTAGRAM_API_URL}/api/auth/account-info/${username}`);
      return response.data;
    } catch (error) {
      logger.error('Instagram API get account info error:', error.response?.data || error.message);
      throw error;
    }
  },

  /**
   * Actions
   */
  async follow(username, targetUsername) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/actions/follow`, {
        username,
        target_username: targetUsername
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API follow error:', error.response?.data || error.message);
      throw error;
    }
  },

  async unfollow(username, targetUsername) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/actions/unfollow`, {
        username,
        target_username: targetUsername
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API unfollow error:', error.response?.data || error.message);
      throw error;
    }
  },

  async like(username, mediaId) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/actions/like`, {
        username,
        media_id: mediaId
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API like error:', error.response?.data || error.message);
      throw error;
    }
  },

  async comment(username, mediaId, text) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/actions/comment`, {
        username,
        media_id: mediaId,
        text
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API comment error:', error.response?.data || error.message);
      throw error;
    }
  },

  async bulkFollow(username, targetUsernames, respectLimits = true) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/actions/bulk-follow`, {
        username,
        target_usernames: targetUsernames,
        respect_limits: respectLimits
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API bulk follow error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getLimits(username) {
    try {
      const response = await axios.get(`${INSTAGRAM_API_URL}/api/actions/limits/${username}`);
      return response.data;
    } catch (error) {
      logger.error('Instagram API get limits error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getAccountLimits(username) {
    try {
      const response = await axios.get(`${INSTAGRAM_API_URL}/api/actions/limits/${username}`);
      return response.data;
    } catch (error) {
      logger.error('Instagram API get account limits error:', error.response?.data || error.message);
      return { success: false, message: error.message };
    }
  },

  /**
   * Direct Messages
   */
  async sendDM(username, targetUsernames, message) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/dm/send`, {
        username,
        target_usernames: targetUsernames,
        message
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API send DM error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getInbox(username, amount = 20) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/dm/inbox`, {
        username,
        amount
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API get inbox error:', error.response?.data || error.message);
      throw error;
    }
  },

  /**
   * Stories
   */
  async viewStory(username, targetUsername) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/story/view`, {
        username,
        target_username: targetUsername
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API view story error:', error.response?.data || error.message);
      throw error;
    }
  },

  async bulkViewStories(username, targetUsernames) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/story/bulk-view`, {
        username,
        target_usernames: targetUsernames
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API bulk view stories error:', error.response?.data || error.message);
      throw error;
    }
  },

  /**
   * Scraper
   */
  async getFollowers(username, targetUsername, amount = 100) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/scraper/followers`, {
        username,
        target_username: targetUsername,
        amount
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API get followers error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getFollowing(username, targetUsername, amount = 100) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/scraper/following`, {
        username,
        target_username: targetUsername,
        amount
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API get following error:', error.response?.data || error.message);
      throw error;
    }
  },

  async searchUsers(username, query) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/scraper/search-users`, {
        username,
        query
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API search users error:', error.response?.data || error.message);
      throw error;
    }
  },

  async getHashtagMedias(username, hashtag, amount = 20) {
    try {
      const response = await axios.post(`${INSTAGRAM_API_URL}/api/scraper/hashtag-medias`, {
        username,
        hashtag,
        amount
      });
      return response.data;
    } catch (error) {
      logger.error('Instagram API get hashtag medias error:', error.response?.data || error.message);
      throw error;
    }
  }
};
