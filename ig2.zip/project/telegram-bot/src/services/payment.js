/**
 * Payment service for Midtrans integration
 */

import midtransClient from 'midtrans-client';
import { db } from '../database/client.js';
import { PLANS } from '../config/constants.js';
import { logger } from '../utils/logger.js';

// Initialize Midtrans Snap
const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY,
  clientKey: process.env.MIDTRANS_CLIENT_KEY
});

export const paymentService = {
  /**
   * Create Midtrans payment
   */
  async createMidtransPayment(userId, planKey) {
    try {
      const plan = PLANS[planKey];
      if (!plan) {
        throw new Error('Invalid plan');
      }

      // Create payment record
      const payment = await db.createPayment(userId, planKey.toLowerCase(), plan.price, 'midtrans');

      if (!payment) {
        throw new Error('Failed to create payment record');
      }

      // Create Midtrans transaction
      const parameter = {
        transaction_details: {
          order_id: payment.id,
          gross_amount: plan.price
        },
        item_details: [{
          id: planKey,
          price: plan.price,
          quantity: 1,
          name: `${plan.name} Plan - ${plan.duration_days} days`
        }],
        customer_details: {
          first_name: 'User',
          email: `user_${userId}@instagram-automation.com`
        }
      };

      const transaction = await snap.createTransaction(parameter);

      // Update payment with Midtrans details
      await db.updatePayment(payment.id, {
        midtrans_order_id: payment.id,
        payment_url: transaction.redirect_url,
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
      });

      return {
        success: true,
        payment_id: payment.id,
        payment_url: transaction.redirect_url,
        token: transaction.token
      };

    } catch (error) {
      logger.error('Midtrans payment creation error:', error);
      throw error;
    }
  },

  /**
   * Handle Midtrans webhook notification
   */
  async handleMidtransNotification(notification) {
    try {
      const statusResponse = await snap.transaction.notification(notification);

      const orderId = statusResponse.order_id;
      const transactionStatus = statusResponse.transaction_status;
      const fraudStatus = statusResponse.fraud_status;

      logger.info(`Midtrans notification: ${orderId} - ${transactionStatus}`);

      let paymentStatus = 'pending';

      if (transactionStatus === 'capture') {
        if (fraudStatus === 'accept') {
          paymentStatus = 'paid';
        }
      } else if (transactionStatus === 'settlement') {
        paymentStatus = 'paid';
      } else if (transactionStatus === 'cancel' || transactionStatus === 'deny' || transactionStatus === 'expire') {
        paymentStatus = 'failed';
      } else if (transactionStatus === 'pending') {
        paymentStatus = 'pending';
      }

      // Update payment status
      const updateData = {
        status: paymentStatus,
        midtrans_transaction_id: statusResponse.transaction_id,
        midtrans_payment_type: statusResponse.payment_type
      };

      if (paymentStatus === 'paid') {
        updateData.paid_at = new Date().toISOString();
      }

      const payment = await db.updatePayment(orderId, updateData);

      // If paid, update user subscription
      if (paymentStatus === 'paid' && payment) {
        await this.activateSubscription(payment.user_id, payment.plan);
      }

      return { success: true, status: paymentStatus };

    } catch (error) {
      logger.error('Midtrans notification error:', error);
      throw error;
    }
  },

  /**
   * Verify manual payment
   */
  async verifyManualPayment(paymentId, adminId) {
    try {
      const payment = await db.updatePayment(paymentId, {
        status: 'paid',
        paid_at: new Date().toISOString()
      });

      if (!payment) {
        throw new Error('Payment not found');
      }

      // Update payment proof as verified
      await db.supabase
        .from('payment_proofs')
        .update({
          verified: true,
          verified_by: adminId,
          verified_at: new Date().toISOString()
        })
        .eq('payment_id', paymentId);

      // Activate subscription
      await this.activateSubscription(payment.user_id, payment.plan);

      return { success: true, payment };

    } catch (error) {
      logger.error('Manual payment verification error:', error);
      throw error;
    }
  },

  /**
   * Activate user subscription
   */
  async activateSubscription(userId, planKey) {
    try {
      const plan = PLANS[planKey.toUpperCase()];
      if (!plan) {
        throw new Error('Invalid plan');
      }

      const expiresAt = new Date(Date.now() + plan.duration_days * 24 * 60 * 60 * 1000);

      await db.updateUser(userId, {
        subscription_status: planKey.toLowerCase(),
        subscription_expires_at: expiresAt.toISOString()
      });

      logger.info(`Subscription activated for user ${userId}: ${planKey} until ${expiresAt}`);

      return { success: true, expires_at: expiresAt };

    } catch (error) {
      logger.error('Subscription activation error:', error);
      throw error;
    }
  },

  /**
   * Check subscription status
   */
  async checkSubscription(userId) {
    try {
      const user = await db.getUser(userId);

      if (!user) {
        return { active: false, reason: 'User not found' };
      }

      const now = new Date();
      const expiresAt = user.subscription_expires_at ? new Date(user.subscription_expires_at) : null;

      if (!expiresAt || now > expiresAt) {
        // Expired - update status
        if (user.subscription_status !== 'expired') {
          await db.updateUser(userId, { subscription_status: 'expired' });
        }
        return { active: false, reason: 'Subscription expired', expires_at: expiresAt };
      }

      return {
        active: true,
        plan: user.subscription_status,
        expires_at: expiresAt,
        days_remaining: Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24))
      };

    } catch (error) {
      logger.error('Check subscription error:', error);
      return { active: false, reason: 'Error checking subscription' };
    }
  }
};
