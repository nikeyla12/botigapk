/**
 * Command handlers setup
 */

import { mainKeyboard } from '../keyboards/main.js';
import { logger } from '../utils/logger.js';
import { db } from '../database/client.js';
import { instagramAPI } from '../services/instagram-api.js';

export function setupCommands(bot) {
  // Start command
  bot.command('start', async (ctx) => {
    const user = ctx.state.user;

    const welcomeMessage =
      `🎉 Welcome to Instagram Automation Bot!\n\n` +
      `Hi ${user.first_name}! I'm here to help you automate your Instagram growth.\n\n` +
      `📱 Features:\n` +
      `• Auto Follow/Unfollow\n` +
      `• Auto Like & Comment\n` +
      `• DM Automation\n` +
      `• Story Viewer\n` +
      `• Analytics & Reports\n\n` +
      `🎁 You're on: ${user.subscription_status.toUpperCase()} plan\n` +
      `⏰ Expires: ${new Date(user.subscription_expires_at).toLocaleDateString()}\n\n` +
      `Let's get started! 🚀`;

    await ctx.reply(welcomeMessage, mainKeyboard);
  });

  // Help command
  bot.command('help', async (ctx) => {
    const helpMessage =
      `❓ Help & Support\n\n` +
      `📚 Available Commands:\n` +
      `/start - Show main menu\n` +
      `/help - Show this help message\n` +
      `/accounts - Manage Instagram accounts\n` +
      `/automation - Setup automation\n` +
      `/analytics - View statistics\n` +
      `/limits - Check today's usage limits\n` +
      `/features - See all features & limits\n` +
      `/guide - Complete user guide\n` +
      `/settings - Bot settings\n` +
      `/payment - Subscription & payment\n\n` +
      `💡 Tips:\n` +
      `• Add your Instagram account first\n` +
      `• Setup DM templates before campaigns\n` +
      `• Monitor daily limits to avoid bans\n` +
      `• Use warmup mode for new accounts\n\n` +
      `📖 Read PANDUAN_LENGKAP.md for detailed guide!\n\n` +
      `🆘 Need Help?\n` +
      `Contact: @your_support_username`;

    await ctx.reply(helpMessage, mainKeyboard);
  });

  // Features command
  bot.command('features', async (ctx) => {
    const user = ctx.state.user;
    const plan = user.subscription_status.toUpperCase();

    const featuresMessage =
      `🎯 Features & Limits (${plan} Plan)\n\n` +
      `📱 INSTAGRAM ACCOUNTS:\n` +
      `Trial: 1 account\n` +
      `Basic: 3 accounts\n` +
      `Pro: 10 accounts\n` +
      `Enterprise: Unlimited\n\n` +
      `🤖 AUTO FOLLOW/UNFOLLOW:\n` +
      `Trial: 50/day\n` +
      `Basic: 200/day\n` +
      `Pro: 500/day\n` +
      `Enterprise: 1000/day\n` +
      `⚠️ Warmup mode: -70% for first 7 days\n\n` +
      `❤️ AUTO LIKE:\n` +
      `Trial: 100/day\n` +
      `Basic: 500/day\n` +
      `Pro: 1000/day\n` +
      `Enterprise: 2000/day\n\n` +
      `💬 AUTO COMMENT:\n` +
      `Trial: 20/day\n` +
      `Basic: 100/day\n` +
      `Pro: 200/day\n` +
      `Enterprise: 500/day\n\n` +
      `📨 AUTO DM:\n` +
      `Trial: 10/day\n` +
      `Basic: 50/day\n` +
      `Pro: 150/day\n` +
      `Enterprise: 500/day\n` +
      `⚠️ Most restricted by Instagram!\n\n` +
      `👁️ STORY VIEWER:\n` +
      `Trial: 50/day\n` +
      `Basic: 300/day\n` +
      `Pro: 800/day\n` +
      `Enterprise: 2000/day\n\n` +
      `🔒 SAFETY FEATURES:\n` +
      `✅ Smart delays (30-600s)\n` +
      `✅ Warmup mode for new accounts\n` +
      `✅ Auto-pause on errors\n` +
      `✅ Real-time limit tracking\n\n` +
      `Use /limits to check today's usage!`;

    await ctx.reply(featuresMessage, mainKeyboard);
  });

  // Limits command
  bot.command('limits', async (ctx) => {
    try {
      const accounts = await db.getAccounts(ctx.state.user.id);

      if (accounts.length === 0) {
        await ctx.reply(
          '📱 No Instagram accounts connected.\n\n' +
          'Add an account first: /start → 📱 Accounts → ➕ Add Account',
          mainKeyboard
        );
        return;
      }

      let limitsMessage = '📊 Today\'s Usage Limits\n\n';

      for (const account of accounts) {
        const response = await instagramAPI.getAccountLimits(account.username);

        if (response.success && response.limits) {
          const limits = response.limits;
          limitsMessage +=
            `📱 @${account.username}\n` +
            `✅ Follows: ${limits.follow.count_today}/${limits.follow.limit} (${limits.follow.remaining} left)\n` +
            `✅ Likes: ${limits.like.count_today}/${limits.like.limit} (${limits.like.remaining} left)\n` +
            `✅ Comments: ${limits.comment.count_today}/${limits.comment.limit} (${limits.comment.remaining} left)\n` +
            `✅ DMs: ${limits.dm.count_today}/${limits.dm.limit} (${limits.dm.remaining} left)\n` +
            `✅ Story Views: ${limits.story_view.count_today}/${limits.story_view.limit} (${limits.story_view.remaining} left)\n\n`;
        } else {
          limitsMessage += `📱 @${account.username}\n❌ Error fetching limits\n\n`;
        }
      }

      limitsMessage += '⏰ Limits reset at midnight (00:00)';

      await ctx.reply(limitsMessage, mainKeyboard);
    } catch (error) {
      logger.error('Error fetching limits:', error);
      await ctx.reply('❌ Error fetching limits. Please try again later.', mainKeyboard);
    }
  });

  // Guide command
  bot.command('guide', async (ctx) => {
    const guideMessage =
      `📖 Quick Start Guide\n\n` +
      `1️⃣ SETUP AKUN INSTAGRAM\n` +
      `/start → 📱 Accounts → ➕ Add Account\n` +
      `Masukkan username & password IG lu\n\n` +
      `2️⃣ AUTO FOLLOW/UNFOLLOW\n` +
      `/automation → Auto Follow\n` +
      `• Pilih target (competitor/influencer)\n` +
      `• Bot follow follower mereka\n` +
      `• Auto unfollow yang ga follow balik\n\n` +
      `3️⃣ AUTO LIKE & COMMENT\n` +
      `/automation → Auto Like\n` +
      `• Target: hashtag, location, atau user\n` +
      `• Optional: auto comment\n` +
      `• Setup template di /settings\n\n` +
      `4️⃣ DM AUTOMATION\n` +
      `/automation → Auto DM\n` +
      `• Welcome DM ke new followers\n` +
      `• Lead generation dari kompetitor\n` +
      `• Buat template dengan variables: {name}, {link}\n\n` +
      `5️⃣ MONITOR ANALYTICS\n` +
      `/analytics\n` +
      `• Follower growth\n` +
      `• Engagement rate\n` +
      `• Action history\n\n` +
      `⚠️ SAFETY TIPS:\n` +
      `• Jangan maksain limit harian\n` +
      `• Warmup mode otomatis untuk akun baru\n` +
      `• Check /limits tiap hari\n` +
      `• Variasi template DM/comment\n\n` +
      `📖 Full guide: PANDUAN_LENGKAP.md\n` +
      `🆘 Support: @your_support_username`;

    await ctx.reply(guideMessage, mainKeyboard);
  });

  // Accounts command
  bot.command('accounts', async (ctx) => {
    await ctx.reply(
      '📱 Instagram Accounts\n\nManage your connected Instagram accounts here.',
      { reply_markup: (await import('../keyboards/main.js')).accountsKeyboard.reply_markup }
    );
  });

  // Automation command
  bot.command('automation', async (ctx) => {
    await ctx.reply(
      '🤖 Automation Features\n\nSetup and manage your Instagram automation.',
      { reply_markup: (await import('../keyboards/main.js')).automationKeyboard.reply_markup }
    );
  });

  // Analytics command
  bot.command('analytics', async (ctx) => {
    await ctx.reply(
      '📊 Analytics & Reports\n\nView your Instagram growth statistics.',
      { reply_markup: (await import('../keyboards/main.js')).analyticsKeyboard.reply_markup }
    );
  });

  // Settings command
  bot.command('settings', async (ctx) => {
    await ctx.reply(
      '⚙️ Settings\n\nCustomize your bot preferences.',
      { reply_markup: (await import('../keyboards/main.js')).settingsKeyboard.reply_markup }
    );
  });

  // Payment command
  bot.command('payment', async (ctx) => {
    await ctx.reply(
      '💳 Subscription & Payment\n\nManage your subscription plan.',
      { reply_markup: (await import('../keyboards/main.js')).subscriptionKeyboard.reply_markup }
    );
  });

  logger.info('Commands registered successfully');
}
