/**
 * i18n internationalization helper
 */

import i18next from 'i18next';
import en from '../locales/en.json' assert { type: 'json' };
import id from '../locales/id.json' assert { type: 'json' };

i18next.init({
  lng: 'id', // default language
  fallbackLng: 'en',
  resources: {
    en: { translation: en },
    id: { translation: id }
  }
});

export function t(key, options = {}) {
  return i18next.t(key, options);
}

export function changeLanguage(lng) {
  return i18next.changeLanguage(lng);
}

export default i18next;
