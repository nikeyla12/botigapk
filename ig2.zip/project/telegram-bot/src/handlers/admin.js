/**
 * Admin command handlers
 */

import { db } from '../database/client.js';
import { paymentService } from '../services/payment.js';
import { logger } from '../utils/logger.js';

export function setupAdminCommands(bot) {
  // Admin stats
  bot.command('adminstats', async (ctx) => {
    try {
      // Get stats
      const { data: users } = await db.supabase.from('users').select('*', { count: 'exact' });
      const { data: accounts } = await db.supabase.from('instagram_accounts').select('*', { count: 'exact' });
      const { data: payments } = await db.supabase.from('payments').select('*');

      const totalUsers = users?.length || 0;
      const totalAccounts = accounts?.length || 0;
      const activeUsers = users?.filter(u => u.is_active).length || 0;
      const paidUsers = users?.filter(u => u.subscription_status !== 'trial' && u.subscription_status !== 'expired').length || 0;

      const totalRevenue = payments?.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0) || 0;
      const pendingPayments = payments?.filter(p => p.status === 'pending').length || 0;

      const message =
        `📊 Admin Statistics\n\n` +
        `👥 Users:\n` +
        `• Total: ${totalUsers}\n` +
        `• Active: ${activeUsers}\n` +
        `• Paid: ${paidUsers}\n\n` +
        `📱 Instagram Accounts: ${totalAccounts}\n\n` +
        `💰 Revenue:\n` +
        `• Total: Rp ${totalRevenue.toLocaleString()}\n` +
        `• Pending: ${pendingPayments} payments\n`;

      await ctx.reply(message);

    } catch (error) {
      logger.error('Admin stats error:', error);
      await ctx.reply('❌ Error fetching stats');
    }
  });

  // List pending payments
  bot.command('adminpayments', async (ctx) => {
    try {
      const { data: payments } = await db.supabase
        .from('payments')
        .select('*, users(telegram_id, first_name, telegram_username)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(10);

      if (!payments || payments.length === 0) {
        await ctx.reply('✅ No pending payments');
        return;
      }

      let message = '💳 Pending Payments:\n\n';

      for (const payment of payments) {
        const user = payment.users;
        message += `📦 ${payment.plan.toUpperCase()} - Rp ${payment.amount.toLocaleString()}\n`;
        message += `👤 User: @${user.telegram_username || user.first_name}\n`;
        message += `🆔 Payment ID: ${payment.id}\n`;
        message += `📅 Created: ${new Date(payment.created_at).toLocaleDateString()}\n\n`;
      }

      await ctx.reply(message);

    } catch (error) {
      logger.error('Admin payments error:', error);
      await ctx.reply('❌ Error fetching payments');
    }
  });

  // Verify payment
  bot.command('verifypayment', async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      await ctx.reply('Usage: /verifypayment <payment_id>');
      return;
    }

    const paymentId = args[1];

    try {
      const result = await paymentService.verifyManualPayment(paymentId, ctx.from.id);

      if (result.success) {
        await ctx.reply(`✅ Payment verified successfully!\n\nUser subscription has been activated.`);

        // Notify user
        const payment = result.payment;
        const user = await db.getUser(payment.user_id);

        if (user) {
          await ctx.telegram.sendMessage(
            user.telegram_id,
            `✅ Your payment has been verified!\n\n` +
            `📦 Plan: ${payment.plan.toUpperCase()}\n` +
            `⏰ Valid until: ${new Date(user.subscription_expires_at).toLocaleDateString()}\n\n` +
            `Thank you for your payment!`
          );
        }
      }

    } catch (error) {
      logger.error('Verify payment error:', error);
      await ctx.reply(`❌ Error: ${error.message}`);
    }
  });

  // Broadcast message
  bot.command('broadcast', async (ctx) => {
    const message = ctx.message.text.replace('/broadcast', '').trim();

    if (!message) {
      await ctx.reply('Usage: /broadcast <message>');
      return;
    }

    try {
      const { data: users } = await db.supabase
        .from('users')
        .select('telegram_id')
        .eq('is_active', true);

      if (!users || users.length === 0) {
        await ctx.reply('No active users found');
        return;
      }

      await ctx.reply(`📢 Broadcasting to ${users.length} users...`);

      let sent = 0;
      let failed = 0;

      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.telegram_id, message);
          sent++;
          await new Promise(resolve => setTimeout(resolve, 100)); // Rate limit
        } catch (error) {
          failed++;
          logger.error(`Broadcast error for user ${user.telegram_id}:`, error);
        }
      }

      await ctx.reply(`✅ Broadcast complete!\n\nSent: ${sent}\nFailed: ${failed}`);

    } catch (error) {
      logger.error('Broadcast error:', error);
      await ctx.reply('❌ Error broadcasting message');
    }
  });

  logger.info('Admin commands registered');
}
