/**
 * Callback query handlers
 */

import { db } from '../database/client.js';
import { instagramAPI } from '../services/instagram-api.js';
import { mainKeyboard, accountsKeyboard, automationKeyboard, analyticsKeyboard, settingsKeyboard, subscriptionKeyboard, accountListKeyboard, accountDetailKeyboard } from '../keyboards/main.js';
import { PLANS } from '../config/constants.js';
import { logger } from '../utils/logger.js';

export function setupCallbacks(bot) {
  // Back to main menu
  bot.action('back_to_main', async (ctx) => {
    await ctx.editMessageText('🏠 Main Menu', mainKeyboard);
    await ctx.answerCbQuery();
  });

  // Menu navigation
  bot.action('menu_accounts', async (ctx) => {
    await ctx.editMessageText('📱 Instagram Accounts\n\nManage your connected Instagram accounts here.', accountsKeyboard);
    await ctx.answerCbQuery();
  });

  bot.action('menu_automation', async (ctx) => {
    await ctx.editMessageText('🤖 Automation Features\n\nSetup and manage your Instagram automation.', automationKeyboard);
    await ctx.answerCbQuery();
  });

  bot.action('menu_analytics', async (ctx) => {
    await ctx.editMessageText('📊 Analytics & Reports\n\nView your Instagram growth statistics.', analyticsKeyboard);
    await ctx.answerCbQuery();
  });

  bot.action('menu_settings', async (ctx) => {
    await ctx.editMessageText('⚙️ Settings\n\nCustomize your bot preferences.', settingsKeyboard);
    await ctx.answerCbQuery();
  });

  bot.action('menu_subscription', async (ctx) => {
    const user = ctx.state.user;
    const message =
      `💳 Your Subscription\n\n` +
      `📦 Plan: ${user.subscription_status.toUpperCase()}\n` +
      `⏰ Expires: ${new Date(user.subscription_expires_at).toLocaleDateString()}\n` +
      `🆔 User ID: ${user.id}`;

    await ctx.editMessageText(message, subscriptionKeyboard);
    await ctx.answerCbQuery();
  });

  bot.action('menu_help', async (ctx) => {
    const helpMessage =
      `❓ Help & Support\n\n` +
      `📚 Quick Guide:\n` +
      `1. Add Instagram account\n` +
      `2. Setup automation features\n` +
      `3. Monitor analytics\n` +
      `4. Adjust settings as needed\n\n` +
      `🆘 Need Help?\n` +
      `Contact: @your_support_username`;

    await ctx.editMessageText(helpMessage, mainKeyboard);
    await ctx.answerCbQuery();
  });

  // Account management
  bot.action('account_add', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.reply(
      '➕ Add Instagram Account\n\n' +
      'To add an account, use this format:\n' +
      '/addaccount username password\n\n' +
      'Example: /addaccount myusername mypassword\n\n' +
      '⚠️ Your credentials are encrypted and secure.'
    );
  });

  bot.action('account_list', async (ctx) => {
    const accounts = await db.getAccounts(ctx.state.user.id);

    if (accounts.length === 0) {
      await ctx.editMessageText(
        '📱 You have no Instagram accounts connected.\n\n' +
        'Add your first account to get started!',
        accountsKeyboard
      );
    } else {
      await ctx.editMessageText(
        `📱 Your Instagram Accounts (${accounts.length})\n\n` +
        'Select an account to view details:',
        accountListKeyboard(accounts)
      );
    }

    await ctx.answerCbQuery();
  });

  // Account detail view
  bot.action(/account_view_(.+)/, async (ctx) => {
    const accountId = ctx.match[1];
    const account = await db.getAccount(accountId);

    if (!account) {
      await ctx.answerCbQuery('Account not found');
      return;
    }

    const statusEmoji = account.status === 'active' ? '✅' : '⭕';
    const message =
      `${statusEmoji} @${account.username}\n\n` +
      `Status: ${account.status.toUpperCase()}\n` +
      `Added: ${new Date(account.created_at).toLocaleDateString()}\n` +
      `Last used: ${account.last_used_at ? new Date(account.last_used_at).toLocaleDateString() : 'Never'}`;

    await ctx.editMessageText(message, accountDetailKeyboard(accountId));
    await ctx.answerCbQuery();
  });

  // Delete account
  bot.action(/account_delete_(.+)/, async (ctx) => {
    const accountId = ctx.match[1];

    await ctx.editMessageText(
      '🗑️ Delete Account\n\n' +
      'Are you sure you want to remove this account?\n' +
      'This action cannot be undone.',
      {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '✅ Yes, Delete', callback_data: `account_delete_confirm_${accountId}` },
              { text: '❌ Cancel', callback_data: 'account_list' }
            ]
          ]
        }
      }
    );

    await ctx.answerCbQuery();
  });

  bot.action(/account_delete_confirm_(.+)/, async (ctx) => {
    const accountId = ctx.match[1];
    const account = await db.getAccount(accountId);

    if (account) {
      // Logout from Instagram
      try {
        await instagramAPI.logout(account.username);
      } catch (error) {
        logger.error('Error logging out:', error);
      }

      // Delete from database
      await db.deleteAccount(accountId);

      await ctx.answerCbQuery('✅ Account deleted');
      await ctx.editMessageText(
        '✅ Account removed successfully!',
        accountsKeyboard
      );
    } else {
      await ctx.answerCbQuery('Account not found');
    }
  });

  // Payment plans
  bot.action('payment_plans', async (ctx) => {
    let message = '💎 Subscription Plans\n\n';

    Object.entries(PLANS).forEach(([key, plan]) => {
      if (key === 'TRIAL') return;

      message += `📦 ${plan.name} - Rp ${plan.price.toLocaleString()}/month\n`;
      plan.features.forEach(feature => {
        message += `  ✓ ${feature}\n`;
      });
      message += '\n';
    });

    message += 'Select a plan to continue:';

    await ctx.editMessageText(message, {
      reply_markup: {
        inline_keyboard: [
          [{ text: '💎 Basic Plan', callback_data: 'payment_select_BASIC' }],
          [{ text: '🌟 Pro Plan', callback_data: 'payment_select_PRO' }],
          [{ text: '🚀 Enterprise Plan', callback_data: 'payment_select_ENTERPRISE' }],
          [{ text: '🔙 Back', callback_data: 'menu_subscription' }]
        ]
      }
    });

    await ctx.answerCbQuery();
  });

  // Payment method selection
  bot.action(/payment_select_(.+)/, async (ctx) => {
    const planKey = ctx.match[1];
    const plan = PLANS[planKey];

    ctx.session.selectedPlan = planKey;

    await ctx.editMessageText(
      `💳 Payment for ${plan.name} Plan\n\n` +
      `💰 Amount: Rp ${plan.price.toLocaleString()}\n` +
      `⏰ Duration: ${plan.duration_days} days\n\n` +
      `Choose payment method:`,
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏦 Bank Transfer', callback_data: 'payment_method_manual' }],
            [{ text: '💳 Midtrans (Credit Card/E-Wallet)', callback_data: 'payment_method_midtrans' }],
            [{ text: '🔙 Back', callback_data: 'payment_plans' }]
          ]
        }
      }
    );

    await ctx.answerCbQuery();
  });

  // Manual payment (Bank transfer)
  bot.action('payment_method_manual', async (ctx) => {
    const planKey = ctx.session.selectedPlan;
    const plan = PLANS[planKey];
    const { BANK_INFO } = await import('../config/constants.js');

    // Create payment record
    const payment = await db.createPayment(
      ctx.state.user.id,
      planKey.toLowerCase(),
      plan.price,
      'manual'
    );

    const message =
      `🏦 Bank Transfer Payment\n\n` +
      `💰 Amount: Rp ${plan.price.toLocaleString()}\n` +
      `📦 Plan: ${plan.name}\n\n` +
      `🏦 Bank Details:\n` +
      `Bank: ${BANK_INFO.name}\n` +
      `Account: ${BANK_INFO.account_number}\n` +
      `Name: ${BANK_INFO.account_name}\n\n` +
      `📝 Payment ID: ${payment.id}\n\n` +
      `⚠️ Important:\n` +
      `1. Transfer exact amount: Rp ${plan.price.toLocaleString()}\n` +
      `2. Save your payment proof\n` +
      `3. Send proof with: /payment_proof ${payment.id}\n\n` +
      `✅ Payment will be verified within 24 hours.`;

    await ctx.editMessageText(message, {
      reply_markup: {
        inline_keyboard: [[
          { text: '🔙 Back to Plans', callback_data: 'payment_plans' }
        ]]
      }
    });

    await ctx.answerCbQuery();
  });

  logger.info('Callback handlers registered successfully');
}
