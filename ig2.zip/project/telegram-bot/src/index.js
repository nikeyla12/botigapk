/**
 * Telegram Bot for Instagram Automation
 * Main entry point
 */

import { Telegraf, session } from 'telegraf';
import dotenv from 'dotenv';
import { logger } from './utils/logger.js';
import { supabase } from './database/client.js';
import { setupMiddlewares } from './middlewares/index.js';
import { setupCommands } from './commands/index.js';
import { setupCallbacks } from './handlers/callbacks.js';
import { setupScenes } from './scenes/index.js';

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = ['TELEGRAM_BOT_TOKEN', 'SUPABASE_URL', 'SUPABASE_ANON_KEY'];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    logger.error(`Missing required environment variable: ${envVar}`);
    process.exit(1);
  }
}

// Initialize bot
const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);

// Use session middleware
bot.use(session());

// Setup middlewares (auth, logging, error handling)
setupMiddlewares(bot);

// Setup scenes (multi-step conversations)
setupScenes(bot);

// Setup command handlers
setupCommands(bot);

// Setup callback query handlers
setupCallbacks(bot);

// Setup admin commands
import { setupAdminCommands } from './handlers/admin.js';
import { adminMiddleware } from './middlewares/index.js';
bot.use(adminMiddleware);
setupAdminCommands(bot);

// Error handling
bot.catch((err, ctx) => {
  logger.error(`Bot error for ${ctx.updateType}:`, err);
  ctx.reply('❌ An error occurred. Please try again later.').catch(() => {});
});

// Graceful shutdown
process.once('SIGINT', () => {
  logger.info('SIGINT received, stopping bot...');
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  logger.info('SIGTERM received, stopping bot...');
  bot.stop('SIGTERM');
});

// Start bot
logger.info('Starting Telegram bot...');
bot.launch()
  .then(() => {
    logger.info(`Bot started successfully: @${bot.botInfo.username}`);
  })
  .catch((error) => {
    logger.error('Failed to start bot:', error);
    process.exit(1);
  });
