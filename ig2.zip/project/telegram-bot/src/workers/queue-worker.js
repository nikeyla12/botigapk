/**
 * Queue worker for processing automation jobs
 * Uses Bull queue with Redis
 */

import Queue from 'bull';
import dotenv from 'dotenv';
import { db } from '../database/client.js';
import { instagramAPI } from '../services/instagram-api.js';
import { logger } from '../utils/logger.js';

dotenv.config();

// Create queues
const followQueue = new Queue('instagram-follow', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || undefined
  }
});

const dmQueue = new Queue('instagram-dm', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || undefined
  }
});

const storyQueue = new Queue('instagram-story', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || undefined
  }
});

// Follow job processor
followQueue.process(async (job) => {
  const { accountId, targetUsernames, mode } = job.data;

  logger.info(`Processing follow job for account ${accountId}, targets: ${targetUsernames.length}`);

  const account = await db.getAccount(accountId);
  if (!account) {
    throw new Error('Account not found');
  }

  try {
    if (mode === 'bulk') {
      const result = await instagramAPI.bulkFollow(account.username, targetUsernames, true);
      return result;
    } else {
      // Process one by one
      const results = [];
      for (const targetUsername of targetUsernames) {
        try {
          const result = await instagramAPI.follow(account.username, targetUsername);
          results.push({ username: targetUsername, success: result.success });

          // Update progress
          job.progress((results.length / targetUsernames.length) * 100);

          // Delay between actions
          await new Promise(resolve => setTimeout(resolve, 30000 + Math.random() * 60000));
        } catch (error) {
          logger.error(`Error following ${targetUsername}:`, error);
          results.push({ username: targetUsername, success: false, error: error.message });
        }
      }
      return results;
    }
  } catch (error) {
    logger.error('Follow job error:', error);
    throw error;
  }
});

// DM job processor
dmQueue.process(async (job) => {
  const { accountId, targets, message, templateId } = job.data;

  logger.info(`Processing DM job for account ${accountId}, targets: ${targets.length}`);

  const account = await db.getAccount(accountId);
  if (!account) {
    throw new Error('Account not found');
  }

  const results = [];

  for (const target of targets) {
    try {
      const result = await instagramAPI.sendDM(
        account.username,
        [target],
        message
      );

      results.push({ target, success: result.success });

      // Update progress
      job.progress((results.length / targets.length) * 100);

      // Delay between DMs
      await new Promise(resolve => setTimeout(resolve, 60000 + Math.random() * 120000));
    } catch (error) {
      logger.error(`Error sending DM to ${target}:`, error);
      results.push({ target, success: false, error: error.message });
    }
  }

  return results;
});

// Story view job processor
storyQueue.process(async (job) => {
  const { accountId, targetUsernames } = job.data;

  logger.info(`Processing story view job for account ${accountId}, targets: ${targetUsernames.length}`);

  const account = await db.getAccount(accountId);
  if (!account) {
    throw new Error('Account not found');
  }

  try {
    const result = await instagramAPI.bulkViewStories(account.username, targetUsernames);
    return result;
  } catch (error) {
    logger.error('Story view job error:', error);
    throw error;
  }
});

// Error handlers
followQueue.on('failed', (job, err) => {
  logger.error(`Follow job ${job.id} failed:`, err);
});

dmQueue.on('failed', (job, err) => {
  logger.error(`DM job ${job.id} failed:`, err);
});

storyQueue.on('failed', (job, err) => {
  logger.error(`Story job ${job.id} failed:`, err);
});

// Completed handlers
followQueue.on('completed', (job) => {
  logger.info(`Follow job ${job.id} completed`);
});

dmQueue.on('completed', (job) => {
  logger.info(`DM job ${job.id} completed`);
});

storyQueue.on('completed', (job) => {
  logger.info(`Story job ${job.id} completed`);
});

logger.info('Queue workers started successfully');

// Export queues for adding jobs
export { followQueue, dmQueue, storyQueue };
