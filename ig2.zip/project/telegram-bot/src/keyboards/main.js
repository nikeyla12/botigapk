/**
 * Main menu keyboards
 */

export const mainKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '📱 My Accounts', callback_data: 'menu_accounts' },
        { text: '🤖 Automation', callback_data: 'menu_automation' }
      ],
      [
        { text: '📊 Analytics', callback_data: 'menu_analytics' },
        { text: '⚙️ Settings', callback_data: 'menu_settings' }
      ],
      [
        { text: '💳 Subscription', callback_data: 'menu_subscription' },
        { text: '❓ Help', callback_data: 'menu_help' }
      ]
    ]
  }
};

export const accountsKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '➕ Add Account', callback_data: 'account_add' },
        { text: '📋 My Accounts', callback_data: 'account_list' }
      ],
      [
        { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
      ]
    ]
  }
};

export const automationKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '💬 DM Automation', callback_data: 'auto_dm' },
        { text: '👥 Auto Follow', callback_data: 'auto_follow' }
      ],
      [
        { text: '❤️ Auto Like', callback_data: 'auto_like' },
        { text: '💭 Auto Comment', callback_data: 'auto_comment' }
      ],
      [
        { text: '👁️ Story Viewer', callback_data: 'auto_story' },
        { text: '🔄 Auto Unfollow', callback_data: 'auto_unfollow' }
      ],
      [
        { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
      ]
    ]
  }
};

export const dmAutomationKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '📝 DM Templates', callback_data: 'dm_templates' },
        { text: '🚀 Start Campaign', callback_data: 'dm_campaign' }
      ],
      [
        { text: '🤖 Auto-Reply', callback_data: 'dm_auto_reply' },
        { text: '👋 Welcome DM', callback_data: 'dm_welcome' }
      ],
      [
        { text: '🔙 Back', callback_data: 'menu_automation' }
      ]
    ]
  }
};

export const analyticsKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '📈 Growth Stats', callback_data: 'analytics_growth' },
        { text: '💼 Engagement', callback_data: 'analytics_engagement' }
      ],
      [
        { text: '📊 Action Logs', callback_data: 'analytics_logs' },
        { text: '📉 Reports', callback_data: 'analytics_reports' }
      ],
      [
        { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
      ]
    ]
  }
};

export const settingsKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '🌐 Language', callback_data: 'settings_language' },
        { text: '⏰ Active Hours', callback_data: 'settings_hours' }
      ],
      [
        { text: '🎯 Targeting', callback_data: 'settings_targeting' },
        { text: '🛡️ Safety', callback_data: 'settings_safety' }
      ],
      [
        { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
      ]
    ]
  }
};

export const subscriptionKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: '💎 View Plans', callback_data: 'payment_plans' },
        { text: '💳 Payment History', callback_data: 'payment_history' }
      ],
      [
        { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
      ]
    ]
  }
};

export function accountListKeyboard(accounts) {
  const buttons = accounts.map(account => ([
    {
      text: `${account.status === 'active' ? '✅' : '⭕'} @${account.username}`,
      callback_data: `account_view_${account.id}`
    }
  ]));

  buttons.push([{ text: '➕ Add Account', callback_data: 'account_add' }]);
  buttons.push([{ text: '🔙 Back', callback_data: 'menu_accounts' }]);

  return { reply_markup: { inline_keyboard: buttons } };
}

export function accountDetailKeyboard(accountId) {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Refresh Status', callback_data: `account_refresh_${accountId}` },
          { text: '📊 View Stats', callback_data: `account_stats_${accountId}` }
        ],
        [
          { text: '🗑️ Remove Account', callback_data: `account_delete_${accountId}` }
        ],
        [
          { text: '🔙 Back', callback_data: 'account_list' }
        ]
      ]
    }
  };
}

export const backButton = {
  reply_markup: {
    inline_keyboard: [[
      { text: '🔙 Back to Menu', callback_data: 'back_to_main' }
    ]]
  }
};
