/**
 * Middleware setup
 */

import { db } from '../database/client.js';
import { logger } from '../utils/logger.js';

/**
 * Auth middleware - ensures user exists in database
 */
export async function authMiddleware(ctx, next) {
  if (!ctx.from) {
    return;
  }

  try {
    let user = await db.getUser(ctx.from.id);

    if (!user) {
      // Create new user
      user = await db.createUser(
        ctx.from.id,
        ctx.from.username,
        ctx.from.first_name,
        ctx.from.last_name
      );
      logger.info(`New user registered: ${ctx.from.id} (@${ctx.from.username})`);
    }

    // Store user in context
    ctx.state.user = user;

    return next();
  } catch (error) {
    logger.error('Auth middleware error:', error);
    return next();
  }
}

/**
 * Subscription check middleware
 */
export async function subscriptionMiddleware(ctx, next) {
  if (!ctx.state.user) {
    return ctx.reply('❌ User not found. Please restart the bot with /start');
  }

  const user = ctx.state.user;
  const now = new Date();
  const expiresAt = user.subscription_expires_at ? new Date(user.subscription_expires_at) : null;

  if (!expiresAt || now > expiresAt) {
    return ctx.reply(
      '⚠️ Your subscription has expired!\n\n' +
      'Please renew your subscription to continue using the bot.\n' +
      'Use /payment to see available plans.',
      {
        reply_markup: {
          inline_keyboard: [[
            { text: '💳 View Plans', callback_data: 'payment_plans' }
          ]]
        }
      }
    );
  }

  return next();
}

/**
 * Admin check middleware
 */
export function adminMiddleware(ctx, next) {
  const adminIds = process.env.ADMIN_TELEGRAM_IDS?.split(',').map(id => parseInt(id)) || [];

  if (!adminIds.includes(ctx.from.id)) {
    return ctx.reply('❌ This command is only available for administrators.');
  }

  return next();
}

/**
 * Logging middleware
 */
export async function loggingMiddleware(ctx, next) {
  const start = Date.now();

  try {
    await next();
  } finally {
    const ms = Date.now() - start;
    const updateType = ctx.updateType;
    const userId = ctx.from?.id;
    const username = ctx.from?.username;

    logger.info(`${updateType} from ${userId} (@${username}) - ${ms}ms`);
  }
}

/**
 * Error handling middleware
 */
export async function errorMiddleware(ctx, next) {
  try {
    await next();
  } catch (error) {
    logger.error('Error in handler:', error);

    const errorMessage = error.response?.data?.detail || error.message || 'An unexpected error occurred';

    await ctx.reply(`❌ Error: ${errorMessage}`).catch(() => {});
  }
}

/**
 * Setup all middlewares
 */
export function setupMiddlewares(bot) {
  bot.use(loggingMiddleware);
  bot.use(errorMiddleware);
  bot.use(authMiddleware);
}
