/**
 * Application constants
 */

export const PLANS = {
  TRIAL: {
    name: 'Trial',
    price: 0,
    duration_days: parseInt(process.env.TRIAL_DAYS) || 7,
    features: ['Basic automation', 'Limited actions', '1 account']
  },
  BASIC: {
    name: 'Basic',
    price: parseInt(process.env.BASIC_PLAN_PRICE) || 99000,
    duration_days: 30,
    features: ['Full automation', 'Unlimited actions', '3 accounts', 'DM automation', 'Analytics']
  },
  PRO: {
    name: 'Pro',
    price: parseInt(process.env.PRO_PLAN_PRICE) || 199000,
    duration_days: 30,
    features: ['Everything in Basic', '10 accounts', 'Advanced analytics', 'Priority support', 'Custom targeting']
  },
  ENTERPRISE: {
    name: 'Enterprise',
    price: parseInt(process.env.ENTERPRISE_PLAN_PRICE) || 499000,
    duration_days: 30,
    features: ['Everything in Pro', 'Unlimited accounts', 'White-label', 'Dedicated support', 'API access']
  }
};

export const ACTION_TYPES = {
  FOLLOW: 'follow',
  UNFOLLOW: 'unfollow',
  LIKE: 'like',
  COMMENT: 'comment',
  DM: 'dm',
  STORY_VIEW: 'story_view'
};

export const PAYMENT_STATUS = {
  PENDING: 'pending',
  PAID: 'paid',
  FAILED: 'failed',
  EXPIRED: 'expired'
};

export const PAYMENT_METHODS = {
  MIDTRANS: 'midtrans',
  MANUAL: 'manual'
};

export const AUTOMATION_STATUS = {
  ACTIVE: 'active',
  PAUSED: 'paused',
  STOPPED: 'stopped'
};

export const BANK_INFO = {
  name: process.env.BANK_NAME || 'BCA',
  account_number: process.env.BANK_ACCOUNT_NUMBER || '1234567890',
  account_name: process.env.BANK_ACCOUNT_NAME || 'Instagram Automation'
};
