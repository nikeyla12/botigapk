/**
 * Supabase database client
 */

import { createClient } from '@supabase/supabase-js';
import { logger } from '../utils/logger.js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * Database operations wrapper
 */
export const db = {
  // Users
  async getUser(telegramId) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('telegram_id', telegramId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error getting user:', error);
      return null;
    }
  },

  async createUser(telegramId, username, firstName, lastName) {
    try {
      const { data, error } = await supabase
        .from('users')
        .insert({
          telegram_id: telegramId,
          telegram_username: username,
          first_name: firstName,
          last_name: lastName,
          subscription_status: 'trial',
          subscription_expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating user:', error);
      return null;
    }
  },

  async updateUser(userId, updates) {
    try {
      const { data, error } = await supabase
        .from('users')
        .update(updates)
        .eq('id', userId)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error updating user:', error);
      return null;
    }
  },

  // Instagram Accounts
  async getAccounts(userId) {
    try {
      const { data, error } = await supabase
        .from('instagram_accounts')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting accounts:', error);
      return [];
    }
  },

  async getAccount(accountId) {
    try {
      const { data, error } = await supabase
        .from('instagram_accounts')
        .select('*')
        .eq('id', accountId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error getting account:', error);
      return null;
    }
  },

  async createAccount(userId, username, password) {
    try {
      const { data, error } = await supabase
        .from('instagram_accounts')
        .insert({
          user_id: userId,
          username,
          password,
          status: 'inactive'
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating account:', error);
      return null;
    }
  },

  async deleteAccount(accountId) {
    try {
      const { error } = await supabase
        .from('instagram_accounts')
        .delete()
        .eq('id', accountId);

      if (error) throw error;
      return true;
    } catch (error) {
      logger.error('Error deleting account:', error);
      return false;
    }
  },

  // DM Templates
  async getDMTemplates(userId) {
    try {
      const { data, error } = await supabase
        .from('dm_templates')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting DM templates:', error);
      return [];
    }
  },

  async createDMTemplate(userId, name, message) {
    try {
      const { data, error } = await supabase
        .from('dm_templates')
        .insert({
          user_id: userId,
          name,
          message,
          is_active: true
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating DM template:', error);
      return null;
    }
  },

  // DM Campaigns
  async getDMCampaigns(accountId) {
    try {
      const { data, error } = await supabase
        .from('dm_campaigns')
        .select('*')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting DM campaigns:', error);
      return [];
    }
  },

  async createDMCampaign(accountId, templateId, targetList, settings) {
    try {
      const { data, error } = await supabase
        .from('dm_campaigns')
        .insert({
          account_id: accountId,
          template_id: templateId,
          target_list: targetList,
          settings,
          status: 'active',
          sent_count: 0
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating DM campaign:', error);
      return null;
    }
  },

  // Analytics
  async getAnalytics(accountId, days = 7) {
    try {
      const { data, error } = await supabase
        .from('analytics')
        .select('*')
        .eq('account_id', accountId)
        .order('date', { ascending: false })
        .limit(days);

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting analytics:', error);
      return [];
    }
  },

  // Action Logs
  async getActionLogs(accountId, limit = 50) {
    try {
      const { data, error } = await supabase
        .from('action_logs')
        .select('*')
        .eq('account_id', accountId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting action logs:', error);
      return [];
    }
  },

  // Payments
  async createPayment(userId, plan, amount, method) {
    try {
      const { data, error } = await supabase
        .from('payments')
        .insert({
          user_id: userId,
          plan,
          amount,
          method,
          status: 'pending'
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error creating payment:', error);
      return null;
    }
  },

  async updatePayment(paymentId, updates) {
    try {
      const { data, error } = await supabase
        .from('payments')
        .update(updates)
        .eq('id', paymentId)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      logger.error('Error updating payment:', error);
      return null;
    }
  }
};
