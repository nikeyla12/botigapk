/**
 * Telegraf scenes for multi-step conversations
 */

import { Scenes } from 'telegraf';
import { db } from '../database/client.js';
import { instagramAPI } from '../services/instagram-api.js';
import { logger } from '../utils/logger.js';

const stage = new Scenes.Stage();

// Add account scene
const addAccountScene = new Scenes.BaseScene('add_account');

addAccountScene.enter(async (ctx) => {
  await ctx.reply('➕ Add Instagram Account\n\nPlease enter your Instagram username:');
});

addAccountScene.on('text', async (ctx) => {
  if (!ctx.scene.session.username) {
    ctx.scene.session.username = ctx.message.text.trim();
    await ctx.reply('🔐 Now enter your password:\n\n⚠️ Your password is encrypted and secure.');
  } else if (!ctx.scene.session.password) {
    ctx.scene.session.password = ctx.message.text.trim();

    await ctx.reply('⏳ Logging in to Instagram...');

    try {
      // Create account in database
      const account = await db.createAccount(
        ctx.state.user.id,
        ctx.scene.session.username,
        ctx.scene.session.password
      );

      // Login to Instagram
      const result = await instagramAPI.login(
        ctx.scene.session.username,
        ctx.scene.session.password
      );

      if (result.success) {
        await ctx.reply(
          `✅ Account @${ctx.scene.session.username} added successfully!\n\n` +
          `You can now use automation features with this account.`
        );
      } else if (result.challenge_required) {
        await ctx.reply(
          `⚠️ Instagram challenge required!\n\n` +
          `Please verify your account in the Instagram app and try again.`
        );
      } else {
        await ctx.reply(`❌ Login failed: ${result.message}`);
      }
    } catch (error) {
      logger.error('Add account error:', error);
      await ctx.reply(`❌ Error: ${error.message}`);
    }

    await ctx.scene.leave();
  }
});

stage.register(addAccountScene);

export function setupScenes(bot) {
  bot.use(stage.middleware());
  logger.info('Scenes registered successfully');
}
