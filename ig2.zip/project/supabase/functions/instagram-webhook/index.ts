import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    if (req.method === 'GET') {
      const url = new URL(req.url);
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');

      if (mode === 'subscribe' && token === 'instagram_webhook_token') {
        return new Response(challenge, {
          status: 200,
          headers: corsHeaders,
        });
      } else {
        return new Response('Forbidden', {
          status: 403,
          headers: corsHeaders,
        });
      }
    }

    if (req.method === 'POST') {
      const body = await req.json();

      for (const entry of body.entry || []) {
        for (const change of entry.changes || []) {
          if (change.field === 'messages') {
            const message = change.value.messages?.[0];
            if (!message) continue;

            const senderId = message.from.id;
            const senderUsername = message.from.username;
            const messageText = message.text || message.message || '';
            const messageType = 'dm';

            const { data: accounts } = await supabase
              .from('instagram_accounts')
              .select('*')
              .eq('account_id', entry.id)
              .eq('is_active', true)
              .maybeSingle();

            if (!accounts) continue;

            await supabase.from('messages').insert({
              instagram_account_id: accounts.id,
              sender_username: senderUsername,
              sender_id: senderId,
              message_type: messageType,
              message_text: messageText,
              status: 'received',
            });

            const { data: rules } = await supabase
              .from('auto_reply_rules')
              .select('*')
              .eq('instagram_account_id', accounts.id)
              .eq('is_active', true)
              .order('priority', { ascending: true });

            if (!rules || rules.length === 0) continue;

            let matchedRule = null;
            for (const rule of rules) {
              if (rule.trigger_type === messageType || rule.trigger_type === 'all') {
                if (!rule.keyword || messageText.toLowerCase().includes(rule.keyword.toLowerCase())) {
                  matchedRule = rule;
                  break;
                }
              }
            }

            if (matchedRule) {
              const instagramApiUrl = `https://graph.instagram.com/v12.0/me/messages`;
              const response = await fetch(instagramApiUrl, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${accounts.access_token}`,
                },
                body: JSON.stringify({
                  recipient: { id: senderId },
                  message: { text: matchedRule.reply_message },
                }),
              });

              if (response.ok) {
                await supabase
                  .from('messages')
                  .update({
                    reply_text: matchedRule.reply_message,
                    rule_id: matchedRule.id,
                    status: 'replied',
                    replied_at: new Date().toISOString(),
                  })
                  .eq('sender_id', senderId)
                  .eq('instagram_account_id', accounts.id)
                  .order('received_at', { ascending: false })
                  .limit(1);

                const today = new Date().toISOString().split('T')[0];
                const { data: existingAnalytics } = await supabase
                  .from('analytics')
                  .select('*')
                  .eq('instagram_account_id', accounts.id)
                  .eq('date', today)
                  .maybeSingle();

                if (existingAnalytics) {
                  await supabase
                    .from('analytics')
                    .update({
                      total_messages: existingAnalytics.total_messages + 1,
                      total_replies: existingAnalytics.total_replies + 1,
                      total_dms: existingAnalytics.total_dms + (messageType === 'dm' ? 1 : 0),
                    })
                    .eq('id', existingAnalytics.id);
                } else {
                  await supabase.from('analytics').insert({
                    instagram_account_id: accounts.id,
                    date: today,
                    total_messages: 1,
                    total_replies: 1,
                    total_dms: messageType === 'dm' ? 1 : 0,
                    total_comments: 0,
                    total_mentions: 0,
                  });
                }
              } else {
                await supabase
                  .from('messages')
                  .update({ status: 'failed' })
                  .eq('sender_id', senderId)
                  .eq('instagram_account_id', accounts.id)
                  .order('received_at', { ascending: false })
                  .limit(1);
              }
            }
          }
        }
      }

      return new Response(
        JSON.stringify({ success: true }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        },
      );
    }

    return new Response('Method not allowed', {
      status: 405,
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});
