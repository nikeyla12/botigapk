/*
  # Telegram Bot Tables for Instagram Automation

  1. New Tables
    - `users` - Telegram bot users with subscription info
    - `dm_templates` - DM message templates
    - `payments` - Payment records
    - `payment_proofs` - Payment proof uploads

  2. Security
    - Enable RLS on all tables
    - Add policies for user data access
*/

-- Users table (for Telegram bot users)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id bigint NOT NULL UNIQUE,
  telegram_username text,
  first_name text,
  last_name text,
  language_code text DEFAULT 'id',
  subscription_status text DEFAULT 'trial' CHECK (subscription_status IN ('trial', 'basic', 'pro', 'enterprise', 'expired')),
  subscription_expires_at timestamptz,
  is_admin boolean DEFAULT false,
  is_active boolean DEFAULT true,
  last_activity_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- DM Templates
CREATE TABLE IF NOT EXISTS dm_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name text NOT NULL,
  message text NOT NULL,
  variables jsonb DEFAULT '[]'::jsonb,
  category text,
  is_active boolean DEFAULT true,
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payments
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan text NOT NULL CHECK (plan IN ('basic', 'pro', 'enterprise')),
  amount integer NOT NULL,
  method text NOT NULL CHECK (method IN ('midtrans', 'manual')),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'expired')),
  midtrans_order_id text,
  midtrans_transaction_id text,
  midtrans_payment_type text,
  payment_url text,
  paid_at timestamptz,
  expires_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payment Proofs (for manual bank transfers)
CREATE TABLE IF NOT EXISTS payment_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  file_url text NOT NULL,
  file_type text,
  verified boolean DEFAULT false,
  verified_by bigint,
  verified_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_dm_templates_user_id ON dm_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payment_proofs_payment_id ON payment_proofs(payment_id);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE dm_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_proofs ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Simplified for service role key access from bot

-- Users
CREATE POLICY "Service can manage users" ON users FOR ALL USING (true) WITH CHECK (true);

-- DM Templates
CREATE POLICY "Service can manage templates" ON dm_templates FOR ALL USING (true) WITH CHECK (true);

-- Payments
CREATE POLICY "Service can manage payments" ON payments FOR ALL USING (true) WITH CHECK (true);

-- Payment Proofs
CREATE POLICY "Service can manage payment proofs" ON payment_proofs FOR ALL USING (true) WITH CHECK (true);

-- Triggers
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_dm_templates_updated_at BEFORE UPDATE ON dm_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
