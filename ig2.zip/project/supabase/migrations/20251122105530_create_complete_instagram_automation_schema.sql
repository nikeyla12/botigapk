/*
  ============================================================================
  INSTAGRAM AUTOMATION SUITE - COMPLETE DATABASE SCHEMA
  ============================================================================

  This schema supports ALL features including:
  - Multi-client management
  - All automation features (10+ tools)
  - Human behavior simulation
  - Subscription tiers
  - Advanced analytics
  - Safety & ban prevention

  ============================================================================
  
  1. New Tables
    - `user_profiles` - Extended user info with subscription tiers
    - `clients` - Agency client management
    - `instagram_accounts` - IG account credentials & metadata
    - `automation_settings` - Human behavior & limits config
    - `auto_reply_rules` - Auto reply rules with typing simulation
    - `messages` - Incoming messages log
    - `story_viewer_settings` - Story viewer configuration
    - `story_views` - Story view history
    - `auto_liker_settings` - Auto liker configuration
    - `post_likes` - Post like history
    - `auto_commenter_settings` - Auto commenter configuration
    - `post_comments` - Comment history
    - `auto_follow_settings` - Follow/unfollow configuration
    - `follow_actions` - Follow/unfollow history
    - `dm_campaigns` - DM campaign management
    - `dm_sequences` - DM sequence steps
    - `dm_sent_log` - DM sent history
    - `lead_lists` - Lead collection lists
    - `leads` - Collected leads
    - `hashtag_groups` - Hashtag group management
    - `hashtag_performance` - Hashtag analytics
    - `competitor_accounts` - Competitor tracking
    - `competitor_snapshots` - Competitor metrics snapshots
    - `competitor_posts` - Competitor post tracking
    - `scheduled_posts` - Content scheduler
    - `optimal_post_times` - Best posting times
    - `engagement_pods` - Engagement pod management
    - `pod_members` - Pod membership
    - `pod_activities` - Pod activities
    - `pod_engagement_log` - Pod engagement tracking
    - `analytics` - Daily analytics
    - `performance_metrics` - Performance tracking
    - `action_logs` - All automation actions log
    - `daily_action_limits` - Daily limit tracking
    - `ban_risk_scores` - Ban risk monitoring
    - `account_warnings` - Account warning system

  2. Security
    - Enable RLS on ALL tables
    - Restrictive policies checking auth.uid()
    - Helper function for account ownership checks
    - Separate policies for SELECT, INSERT, UPDATE, DELETE

  3. Important Notes
    - Comprehensive schema for full automation suite
    - Human behavior simulation support
    - Ban prevention & safety features
    - Multi-client agency support
    - Advanced analytics & reporting

  ============================================================================
*/

-- ============================================================================
-- 1. USER & CLIENT MANAGEMENT
-- ============================================================================

-- Extended user profiles
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  company_name text,
  phone text,
  avatar_url text,
  subscription_tier text DEFAULT 'free' CHECK (subscription_tier IN ('free', 'pro', 'agency')),
  subscription_status text DEFAULT 'active' CHECK (subscription_status IN ('active', 'cancelled', 'expired', 'trial')),
  subscription_start_date timestamptz,
  subscription_end_date timestamptz,
  trial_ends_at timestamptz,
  max_clients integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Clients (for agency users managing multiple client accounts)
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text,
  phone text,
  company text,
  niche text,
  notes text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 2. INSTAGRAM ACCOUNTS (Enhanced)
-- ============================================================================

CREATE TABLE IF NOT EXISTS instagram_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  username text NOT NULL,
  access_token text NOT NULL,
  account_id text NOT NULL,
  password_encrypted text,
  session_id text,
  cookies jsonb,
  is_active boolean DEFAULT true,
  is_business_account boolean DEFAULT false,
  account_age_days integer DEFAULT 0,
  follower_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  post_count integer DEFAULT 0,
  bio text,
  profile_pic_url text,
  last_synced_at timestamptz,
  warmup_mode boolean DEFAULT true,
  warmup_start_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, username)
);

-- ============================================================================
-- 3. AUTOMATION SETTINGS (Human Behavior Configuration)
-- ============================================================================

CREATE TABLE IF NOT EXISTS automation_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT true,
  active_hours_start integer DEFAULT 8,
  active_hours_end integer DEFAULT 22,
  timezone text DEFAULT 'UTC',
  typing_speed_wpm integer DEFAULT 60,
  typing_speed_variance integer DEFAULT 20,
  view_duration_min integer DEFAULT 3,
  view_duration_max integer DEFAULT 8,
  action_delay_min integer DEFAULT 3,
  action_delay_max integer DEFAULT 15,
  scroll_delay_min integer DEFAULT 2,
  scroll_delay_max integer DEFAULT 5,
  rest_duration_minutes integer DEFAULT 45,
  rest_frequency_minutes integer DEFAULT 120,
  daily_active_hours integer DEFAULT 8,
  warmup_enabled boolean DEFAULT true,
  warmup_duration_days integer DEFAULT 7,
  warmup_day_current integer DEFAULT 1,
  daily_story_views_limit integer DEFAULT 300,
  daily_likes_limit integer DEFAULT 300,
  daily_comments_limit integer DEFAULT 30,
  daily_follows_limit integer DEFAULT 50,
  daily_unfollows_limit integer DEFAULT 50,
  daily_dms_limit integer DEFAULT 20,
  unfollow_after_days integer DEFAULT 3,
  maintain_follow_ratio boolean DEFAULT true,
  max_follow_ratio decimal DEFAULT 1.5,
  never_unfollow_followers boolean DEFAULT true,
  auto_pause_on_high_risk boolean DEFAULT true,
  risk_threshold integer DEFAULT 70,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id)
);

-- ============================================================================
-- 4. AUTO REPLY (Enhanced with typing simulation)
-- ============================================================================

CREATE TABLE IF NOT EXISTS auto_reply_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  trigger_type text NOT NULL CHECK (trigger_type IN ('dm', 'comment', 'mention', 'all')),
  keyword text,
  reply_message text NOT NULL,
  reply_variations jsonb,
  simulate_typing boolean DEFAULT true,
  typing_delay_seconds integer DEFAULT 3,
  mark_as_seen_delay_seconds integer DEFAULT 2,
  is_active boolean DEFAULT true,
  priority integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  sender_username text NOT NULL,
  sender_id text NOT NULL,
  message_type text NOT NULL CHECK (message_type IN ('dm', 'comment', 'mention')),
  message_text text NOT NULL,
  reply_text text,
  rule_id uuid REFERENCES auto_reply_rules(id) ON DELETE SET NULL,
  status text DEFAULT 'received' CHECK (status IN ('received', 'replied', 'failed', 'ignored')),
  received_at timestamptz DEFAULT now(),
  replied_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 5. AUTO STORY VIEWER
-- ============================================================================

CREATE TABLE IF NOT EXISTS story_viewer_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false,
  target_type text DEFAULT 'followers' CHECK (target_type IN ('followers', 'following', 'both', 'custom_list')),
  custom_usernames text[],
  view_duration_min integer DEFAULT 3,
  view_duration_max integer DEFAULT 8,
  skip_already_viewed boolean DEFAULT true,
  randomize_order boolean DEFAULT true,
  daily_limit integer DEFAULT 300,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id)
);

CREATE TABLE IF NOT EXISTS story_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  story_owner_username text NOT NULL,
  story_owner_id text NOT NULL,
  story_id text NOT NULL,
  viewed_at timestamptz DEFAULT now(),
  view_duration_seconds integer,
  created_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, story_id)
);

-- ============================================================================
-- 6. AUTO LIKER
-- ============================================================================

CREATE TABLE IF NOT EXISTS auto_liker_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false,
  target_type text DEFAULT 'hashtags' CHECK (target_type IN ('hashtags', 'users', 'locations', 'explore', 'followers', 'following')),
  target_hashtags text[],
  target_usernames text[],
  target_locations text[],
  like_ratio decimal DEFAULT 0.6,
  scroll_before_like boolean DEFAULT true,
  view_duration_seconds integer DEFAULT 5,
  skip_already_liked boolean DEFAULT true,
  daily_limit integer DEFAULT 300,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id)
);

CREATE TABLE IF NOT EXISTS post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  post_owner_username text NOT NULL,
  post_owner_id text NOT NULL,
  post_id text NOT NULL,
  post_url text,
  liked_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, post_id)
);

-- ============================================================================
-- 7. AUTO COMMENTER
-- ============================================================================

CREATE TABLE IF NOT EXISTS auto_commenter_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false,
  target_type text DEFAULT 'hashtags' CHECK (target_type IN ('hashtags', 'users', 'followers', 'following')),
  target_hashtags text[],
  target_usernames text[],
  comment_templates jsonb,
  simulate_typing boolean DEFAULT true,
  include_emojis boolean DEFAULT true,
  reply_to_own_posts boolean DEFAULT true,
  avoid_duplicate_comments boolean DEFAULT true,
  daily_limit integer DEFAULT 30,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id)
);

CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  post_owner_username text NOT NULL,
  post_owner_id text NOT NULL,
  post_id text NOT NULL,
  comment_text text NOT NULL,
  comment_id text,
  commented_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 8. AUTO FOLLOW/UNFOLLOW
-- ============================================================================

CREATE TABLE IF NOT EXISTS auto_follow_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false,
  source_type text DEFAULT 'hashtags' CHECK (source_type IN ('hashtags', 'locations', 'competitor_followers', 'competitor_following', 'post_likers', 'post_commenters')),
  source_hashtags text[],
  source_locations text[],
  source_usernames text[],
  whitelist_usernames text[],
  skip_verified_accounts boolean DEFAULT false,
  skip_business_accounts boolean DEFAULT false,
  min_followers integer DEFAULT 100,
  max_followers integer DEFAULT 50000,
  min_following integer DEFAULT 50,
  max_following integer,
  daily_follow_limit integer DEFAULT 50,
  daily_unfollow_limit integer DEFAULT 50,
  unfollow_after_days integer DEFAULT 3,
  never_unfollow_followers boolean DEFAULT true,
  grace_period_hours integer DEFAULT 48,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id)
);

CREATE TABLE IF NOT EXISTS follow_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  target_username text NOT NULL,
  target_user_id text NOT NULL,
  action_type text NOT NULL CHECK (action_type IN ('follow', 'unfollow')),
  source_type text,
  is_follower boolean DEFAULT false,
  followed_back boolean DEFAULT false,
  whitelisted boolean DEFAULT false,
  followed_at timestamptz,
  unfollowed_at timestamptz,
  eligible_for_unfollow_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 9. DM SCHEDULER & SEQUENCES
-- ============================================================================

CREATE TABLE IF NOT EXISTS dm_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text DEFAULT 'single' CHECK (type IN ('single', 'bulk', 'sequence')),
  message_template text NOT NULL,
  personalization_fields jsonb,
  target_usernames text[],
  target_csv_data jsonb,
  schedule_type text DEFAULT 'immediate' CHECK (schedule_type IN ('immediate', 'scheduled', 'drip')),
  scheduled_at timestamptz,
  simulate_typing boolean DEFAULT true,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'paused', 'completed')),
  total_recipients integer DEFAULT 0,
  sent_count integer DEFAULT 0,
  failed_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dm_sequences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES dm_campaigns(id) ON DELETE CASCADE,
  sequence_order integer NOT NULL,
  delay_days integer DEFAULT 0,
  message_template text NOT NULL,
  condition_type text CHECK (condition_type IN ('no_reply', 'replied', 'always')),
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dm_sent_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES dm_campaigns(id) ON DELETE CASCADE,
  sequence_id uuid REFERENCES dm_sequences(id) ON DELETE SET NULL,
  recipient_username text NOT NULL,
  recipient_user_id text,
  message_text text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'replied')),
  sent_at timestamptz,
  replied_at timestamptz,
  reply_text text,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 10. LEAD COLLECTION
-- ============================================================================

CREATE TABLE IF NOT EXISTS lead_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  source_type text CHECK (source_type IN ('hashtag_search', 'location_search', 'competitor_followers', 'competitor_following', 'post_likers', 'post_commenters')),
  source_value text,
  total_leads integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_id uuid NOT NULL REFERENCES lead_lists(id) ON DELETE CASCADE,
  username text NOT NULL,
  user_id text NOT NULL,
  full_name text,
  bio text,
  email text,
  follower_count integer,
  following_count integer,
  post_count integer,
  is_verified boolean DEFAULT false,
  is_business boolean DEFAULT false,
  is_private boolean DEFAULT false,
  profile_pic_url text,
  engagement_rate decimal,
  tags text[],
  notes text,
  collected_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(list_id, user_id)
);

-- ============================================================================
-- 11. HASHTAG ANALYZER
-- ============================================================================

CREATE TABLE IF NOT EXISTS hashtag_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  name text NOT NULL,
  hashtags text[] NOT NULL,
  niche text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hashtag_performance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  hashtag text NOT NULL,
  post_count integer DEFAULT 0,
  avg_likes integer DEFAULT 0,
  avg_comments integer DEFAULT 0,
  engagement_rate decimal DEFAULT 0,
  difficulty_score integer DEFAULT 0,
  trending_score integer DEFAULT 0,
  last_analyzed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, hashtag)
);

-- ============================================================================
-- 12. COMPETITOR MONITORING
-- ============================================================================

CREATE TABLE IF NOT EXISTS competitor_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  competitor_username text NOT NULL,
  competitor_user_id text NOT NULL,
  niche text,
  notes text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, competitor_username)
);

CREATE TABLE IF NOT EXISTS competitor_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_account_id uuid NOT NULL REFERENCES competitor_accounts(id) ON DELETE CASCADE,
  follower_count integer,
  following_count integer,
  post_count integer,
  avg_likes integer,
  avg_comments integer,
  engagement_rate decimal,
  posting_frequency decimal,
  snapshot_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(competitor_account_id, snapshot_date)
);

CREATE TABLE IF NOT EXISTS competitor_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_account_id uuid NOT NULL REFERENCES competitor_accounts(id) ON DELETE CASCADE,
  post_id text NOT NULL,
  post_url text,
  caption text,
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  posted_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(competitor_account_id, post_id)
);

-- ============================================================================
-- 13. CONTENT SCHEDULER
-- ============================================================================

CREATE TABLE IF NOT EXISTS scheduled_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  post_type text DEFAULT 'feed' CHECK (post_type IN ('feed', 'story', 'reel', 'carousel')),
  caption text,
  hashtags text[],
  location text,
  media_urls text[] NOT NULL,
  scheduled_time timestamptz NOT NULL,
  optimal_time boolean DEFAULT false,
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'published', 'failed', 'cancelled')),
  published_at timestamptz,
  post_id text,
  post_url text,
  error_message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS optimal_post_times (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  day_of_week integer NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  hour_of_day integer NOT NULL CHECK (hour_of_day BETWEEN 0 AND 23),
  engagement_score decimal DEFAULT 0,
  calculated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, day_of_week, hour_of_day)
);

-- ============================================================================
-- 14. ENGAGEMENT PODS
-- ============================================================================

CREATE TABLE IF NOT EXISTS engagement_pods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  max_members integer DEFAULT 20,
  rules text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pod_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pod_id uuid NOT NULL REFERENCES engagement_pods(id) ON DELETE CASCADE,
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  role text DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  auto_engage boolean DEFAULT true,
  joined_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(pod_id, instagram_account_id)
);

CREATE TABLE IF NOT EXISTS pod_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pod_id uuid NOT NULL REFERENCES engagement_pods(id) ON DELETE CASCADE,
  posted_by uuid NOT NULL REFERENCES pod_members(id) ON DELETE CASCADE,
  post_url text NOT NULL,
  post_id text NOT NULL,
  required_actions text[] DEFAULT ARRAY['like', 'comment'],
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pod_engagement_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  activity_id uuid NOT NULL REFERENCES pod_activities(id) ON DELETE CASCADE,
  member_id uuid NOT NULL REFERENCES pod_members(id) ON DELETE CASCADE,
  action_type text NOT NULL CHECK (action_type IN ('like', 'comment', 'save')),
  completed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(activity_id, member_id, action_type)
);

-- ============================================================================
-- 15. ANALYTICS & PERFORMANCE TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  date date NOT NULL,
  follower_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  follower_growth integer DEFAULT 0,
  following_growth integer DEFAULT 0,
  total_likes integer DEFAULT 0,
  total_comments integer DEFAULT 0,
  total_saves integer DEFAULT 0,
  total_shares integer DEFAULT 0,
  engagement_rate decimal DEFAULT 0,
  reach integer DEFAULT 0,
  impressions integer DEFAULT 0,
  profile_visits integer DEFAULT 0,
  website_clicks integer DEFAULT 0,
  total_messages integer DEFAULT 0,
  total_replies integer DEFAULT 0,
  total_dms integer DEFAULT 0,
  total_comments_received integer DEFAULT 0,
  total_mentions integer DEFAULT 0,
  stories_viewed integer DEFAULT 0,
  posts_liked integer DEFAULT 0,
  comments_posted integer DEFAULT 0,
  follows_done integer DEFAULT 0,
  unfollows_done integer DEFAULT 0,
  dms_sent integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, date)
);

CREATE TABLE IF NOT EXISTS performance_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  metric_type text NOT NULL CHECK (metric_type IN ('follower_growth_rate', 'engagement_rate', 'reach_rate', 'conversion_rate', 'response_rate')),
  value decimal NOT NULL,
  period text DEFAULT 'daily' CHECK (period IN ('daily', 'weekly', 'monthly')),
  calculated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 16. SAFETY & BAN PREVENTION
-- ============================================================================

CREATE TABLE IF NOT EXISTS action_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  action_type text NOT NULL CHECK (action_type IN ('story_view', 'like', 'comment', 'follow', 'unfollow', 'dm', 'post')),
  target_username text,
  target_user_id text,
  status text DEFAULT 'success' CHECK (status IN ('success', 'failed', 'blocked', 'rate_limited')),
  response_code text,
  error_message text,
  executed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_action_logs_account_time ON action_logs(instagram_account_id, executed_at DESC);

CREATE TABLE IF NOT EXISTS daily_action_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  date date NOT NULL,
  action_type text NOT NULL,
  current_count integer DEFAULT 0,
  limit_count integer NOT NULL,
  last_action_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(instagram_account_id, date, action_type)
);

CREATE TABLE IF NOT EXISTS ban_risk_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  risk_score integer DEFAULT 0 CHECK (risk_score BETWEEN 0 AND 100),
  risk_level text DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  factors jsonb,
  calculated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS account_warnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_account_id uuid NOT NULL REFERENCES instagram_accounts(id) ON DELETE CASCADE,
  warning_type text NOT NULL CHECK (warning_type IN ('rate_limit', 'action_blocked', 'temporary_ban', 'suspicious_activity')),
  severity text DEFAULT 'warning' CHECK (severity IN ('info', 'warning', 'critical')),
  message text NOT NULL,
  auto_paused boolean DEFAULT false,
  acknowledged boolean DEFAULT false,
  occurred_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_instagram_accounts_user_id ON instagram_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_instagram_accounts_client_id ON instagram_accounts(client_id);
CREATE INDEX IF NOT EXISTS idx_clients_user_id ON clients(user_id);
CREATE INDEX IF NOT EXISTS idx_story_views_account_id ON story_views(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_account_id ON post_likes(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_post_comments_account_id ON post_comments(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_follow_actions_account_id ON follow_actions(instagram_account_id);
CREATE INDEX IF NOT EXISTS idx_leads_list_id ON leads(list_id);
CREATE INDEX IF NOT EXISTS idx_analytics_account_date ON analytics(instagram_account_id, date DESC);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE instagram_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_reply_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE story_viewer_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE story_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_liker_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_commenter_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_follow_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE follow_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE dm_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE dm_sequences ENABLE ROW LEVEL SECURITY;
ALTER TABLE dm_sent_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE hashtag_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE hashtag_performance ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE optimal_post_times ENABLE ROW LEVEL SECURITY;
ALTER TABLE engagement_pods ENABLE ROW LEVEL SECURITY;
ALTER TABLE pod_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE pod_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE pod_engagement_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE action_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_action_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE ban_risk_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE account_warnings ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- RLS POLICIES
-- ============================================================================

-- User Profiles
CREATE POLICY "Users can view own profile" ON user_profiles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON user_profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON user_profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Clients
CREATE POLICY "Users can view own clients" ON clients FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own clients" ON clients FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own clients" ON clients FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own clients" ON clients FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Instagram Accounts (user owns directly or through client)
CREATE POLICY "Users can view own IG accounts" ON instagram_accounts FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()));
CREATE POLICY "Users can insert own IG accounts" ON instagram_accounts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()));
CREATE POLICY "Users can update own IG accounts" ON instagram_accounts FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()))
  WITH CHECK (auth.uid() = user_id OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()));
CREATE POLICY "Users can delete own IG accounts" ON instagram_accounts FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()));

-- Helper function for checking account ownership
CREATE OR REPLACE FUNCTION user_owns_instagram_account(account_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM instagram_accounts
    WHERE id = account_id
    AND (user_id = auth.uid() OR client_id IN (SELECT id FROM clients WHERE user_id = auth.uid()))
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Generic policies for all automation tables (using helper function)
CREATE POLICY "Users can manage own automation settings" ON automation_settings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own auto reply rules" ON auto_reply_rules FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own messages" ON messages FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own story settings" ON story_viewer_settings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own story views" ON story_views FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own liker settings" ON auto_liker_settings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own post likes" ON post_likes FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own commenter settings" ON auto_commenter_settings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own post comments" ON post_comments FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own follow settings" ON auto_follow_settings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own follow actions" ON follow_actions FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own DM campaigns" ON dm_campaigns FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own lead lists" ON lead_lists FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own hashtag groups" ON hashtag_groups FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own hashtag performance" ON hashtag_performance FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own competitor accounts" ON competitor_accounts FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own scheduled posts" ON scheduled_posts FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own analytics" ON analytics FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own action logs" ON action_logs FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own daily limits" ON daily_action_limits FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own risk scores" ON ban_risk_scores FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own warnings" ON account_warnings FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can manage own performance metrics" ON performance_metrics FOR ALL TO authenticated
  USING (user_owns_instagram_account(instagram_account_id)) WITH CHECK (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Users can view leads in own lists" ON leads FOR SELECT TO authenticated
  USING (list_id IN (SELECT id FROM lead_lists WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can insert leads in own lists" ON leads FOR INSERT TO authenticated
  WITH CHECK (list_id IN (SELECT id FROM lead_lists WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can update leads in own lists" ON leads FOR UPDATE TO authenticated
  USING (list_id IN (SELECT id FROM lead_lists WHERE user_owns_instagram_account(instagram_account_id)))
  WITH CHECK (list_id IN (SELECT id FROM lead_lists WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can delete leads in own lists" ON leads FOR DELETE TO authenticated
  USING (list_id IN (SELECT id FROM lead_lists WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Users can view DM sequences in own campaigns" ON dm_sequences FOR SELECT TO authenticated
  USING (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can insert DM sequences in own campaigns" ON dm_sequences FOR INSERT TO authenticated
  WITH CHECK (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can update DM sequences in own campaigns" ON dm_sequences FOR UPDATE TO authenticated
  USING (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)))
  WITH CHECK (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can delete DM sequences in own campaigns" ON dm_sequences FOR DELETE TO authenticated
  USING (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Users can view DM logs in own campaigns" ON dm_sent_log FOR SELECT TO authenticated
  USING (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can insert DM logs in own campaigns" ON dm_sent_log FOR INSERT TO authenticated
  WITH CHECK (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can update DM logs in own campaigns" ON dm_sent_log FOR UPDATE TO authenticated
  USING (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)))
  WITH CHECK (campaign_id IN (SELECT id FROM dm_campaigns WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Users can view competitor snapshots" ON competitor_snapshots FOR SELECT TO authenticated
  USING (competitor_account_id IN (SELECT id FROM competitor_accounts WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can insert competitor snapshots" ON competitor_snapshots FOR INSERT TO authenticated
  WITH CHECK (competitor_account_id IN (SELECT id FROM competitor_accounts WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Users can view competitor posts" ON competitor_posts FOR SELECT TO authenticated
  USING (competitor_account_id IN (SELECT id FROM competitor_accounts WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Users can insert competitor posts" ON competitor_posts FOR INSERT TO authenticated
  WITH CHECK (competitor_account_id IN (SELECT id FROM competitor_accounts WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Users can view optimal times for own accounts" ON optimal_post_times FOR SELECT TO authenticated
  USING (user_owns_instagram_account(instagram_account_id));
CREATE POLICY "Users can insert optimal times for own accounts" ON optimal_post_times FOR INSERT TO authenticated
  WITH CHECK (user_owns_instagram_account(instagram_account_id));
CREATE POLICY "Users can update optimal times for own accounts" ON optimal_post_times FOR UPDATE TO authenticated
  USING (user_owns_instagram_account(instagram_account_id))
  WITH CHECK (user_owns_instagram_account(instagram_account_id));

-- Engagement Pods (public visibility for discovery)
CREATE POLICY "Anyone can view pods" ON engagement_pods FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert own pods" ON engagement_pods FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Users can update own pods" ON engagement_pods FOR UPDATE TO authenticated
  USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Users can delete own pods" ON engagement_pods FOR DELETE TO authenticated USING (auth.uid() = created_by);

CREATE POLICY "Users can view pod members in accessible pods" ON pod_members FOR SELECT TO authenticated
  USING (pod_id IN (SELECT id FROM engagement_pods) OR user_owns_instagram_account(instagram_account_id));
CREATE POLICY "Users can insert pod members with own accounts" ON pod_members FOR INSERT TO authenticated
  WITH CHECK (user_owns_instagram_account(instagram_account_id));
CREATE POLICY "Users can update own pod memberships" ON pod_members FOR UPDATE TO authenticated
  USING (user_owns_instagram_account(instagram_account_id))
  WITH CHECK (user_owns_instagram_account(instagram_account_id));
CREATE POLICY "Users can delete own pod memberships" ON pod_members FOR DELETE TO authenticated
  USING (user_owns_instagram_account(instagram_account_id));

CREATE POLICY "Pod members can view activities" ON pod_activities FOR SELECT TO authenticated
  USING (pod_id IN (SELECT pod_id FROM pod_members WHERE user_owns_instagram_account(instagram_account_id)));
CREATE POLICY "Pod members can insert activities" ON pod_activities FOR INSERT TO authenticated
  WITH CHECK (posted_by IN (SELECT id FROM pod_members WHERE user_owns_instagram_account(instagram_account_id)));

CREATE POLICY "Pod members can view engagement log" ON pod_engagement_log FOR SELECT TO authenticated
  USING (activity_id IN (SELECT id FROM pod_activities WHERE pod_id IN (SELECT pod_id FROM pod_members WHERE user_owns_instagram_account(instagram_account_id))));
CREATE POLICY "Pod members can insert engagement log" ON pod_engagement_log FOR INSERT TO authenticated
  WITH CHECK (member_id IN (SELECT id FROM pod_members WHERE user_owns_instagram_account(instagram_account_id)));

-- ============================================================================
-- TRIGGERS
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_instagram_accounts_updated_at BEFORE UPDATE ON instagram_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_automation_settings_updated_at BEFORE UPDATE ON automation_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_auto_reply_rules_updated_at BEFORE UPDATE ON auto_reply_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_analytics_updated_at BEFORE UPDATE ON analytics FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- INITIAL DATA / DEFAULTS
-- ============================================================================

-- Function to create default automation settings when new IG account is added
CREATE OR REPLACE FUNCTION create_default_automation_settings()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO automation_settings (instagram_account_id)
  VALUES (NEW.id)
  ON CONFLICT (instagram_account_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_create_default_automation_settings
  AFTER INSERT ON instagram_accounts
  FOR EACH ROW
  EXECUTE FUNCTION create_default_automation_settings();