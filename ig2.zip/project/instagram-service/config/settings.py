"""
Application settings loaded from environment variables
"""

from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # API Configuration
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_WORKERS: int = 4

    # Supabase Configuration
    SUPABASE_URL: str
    SUPABASE_ANON_KEY: str
    SUPABASE_SERVICE_ROLE_KEY: str

    # Instagram Configuration
    INSTAGRAM_SESSION_DIR: str = "./sessions"
    INSTAGRAM_PROXY_ENABLED: bool = False
    INSTAGRAM_PROXY_LIST: Optional[str] = None

    # Safety Limits (per day)
    MAX_FOLLOWS_PER_DAY: int = 200
    MAX_UNFOLLOWS_PER_DAY: int = 200
    MAX_LIKES_PER_DAY: int = 500
    MAX_COMMENTS_PER_DAY: int = 100
    MAX_DMS_PER_DAY: int = 50
    MAX_STORY_VIEWS_PER_DAY: int = 300

    # Delays (in seconds)
    MIN_DELAY_BETWEEN_ACTIONS: int = 30
    MAX_DELAY_BETWEEN_ACTIONS: int = 120
    MIN_DELAY_BETWEEN_FOLLOWS: int = 60
    MAX_DELAY_BETWEEN_FOLLOWS: int = 180

    # Warmup Configuration
    WARMUP_ENABLED: bool = True
    WARMUP_DAYS: int = 7
    WARMUP_MULTIPLIER: float = 0.3

    # Application Configuration
    ENVIRONMENT: str = "development"
    LOG_LEVEL: str = "INFO"
    CORS_ORIGINS: str = "*"

    # Redis Configuration
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: Optional[str] = None

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
