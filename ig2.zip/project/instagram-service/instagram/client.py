"""
Instagram client wrapper using Instagrapi
Handles Instagram API operations with session management
"""

from instagrapi import Client
from instagrapi.exceptions import LoginRequired, ChallengeRequired, TwoFactorRequired, PleaseWaitFewMinutes
from config.settings import settings
from config.logger import setup_logger
from typing import Optional, Dict, List
import os
import json

logger = setup_logger(__name__)

class InstagramClient:
    """Wrapper for Instagrapi client with session management"""

    def __init__(self, username: str):
        self.username = username
        self.client = Client()
        self.session_file = os.path.join(settings.INSTAGRAM_SESSION_DIR, f"{username}.json")

        # Ensure session directory exists
        os.makedirs(settings.INSTAGRAM_SESSION_DIR, exist_ok=True)

        # Configure client settings
        self.client.delay_range = [settings.MIN_DELAY_BETWEEN_ACTIONS, settings.MAX_DELAY_BETWEEN_ACTIONS]

    def login(self, password: str, verification_code: Optional[str] = None) -> Dict[str, any]:
        """
        Login to Instagram account
        Returns: {"success": bool, "message": str, "challenge_required": bool}
        """
        try:
            # Try to load existing session
            if os.path.exists(self.session_file):
                try:
                    self.client.load_settings(self.session_file)
                    self.client.login(self.username, password)
                    logger.info(f"Logged in with existing session: {self.username}")
                    return {"success": True, "message": "Logged in successfully", "challenge_required": False}
                except Exception as e:
                    logger.warning(f"Failed to use existing session, logging in fresh: {e}")

            # Fresh login
            self.client.login(self.username, password, verification_code=verification_code)

            # Save session
            self.client.dump_settings(self.session_file)
            logger.info(f"Fresh login successful: {self.username}")

            return {"success": True, "message": "Logged in successfully", "challenge_required": False}

        except TwoFactorRequired:
            logger.warning(f"2FA required for {self.username}")
            return {"success": False, "message": "Two-factor authentication required", "challenge_required": True, "challenge_type": "2fa"}

        except ChallengeRequired as e:
            logger.warning(f"Challenge required for {self.username}")
            return {"success": False, "message": "Challenge required - verify account in Instagram app", "challenge_required": True, "challenge_type": "challenge"}

        except PleaseWaitFewMinutes:
            logger.error(f"Rate limit hit for {self.username}")
            return {"success": False, "message": "Too many login attempts. Please wait a few minutes.", "challenge_required": False}

        except Exception as e:
            logger.error(f"Login failed for {self.username}: {e}")
            return {"success": False, "message": f"Login failed: {str(e)}", "challenge_required": False}

    def logout(self):
        """Logout and remove session"""
        try:
            if os.path.exists(self.session_file):
                os.remove(self.session_file)
            logger.info(f"Logged out: {self.username}")
        except Exception as e:
            logger.error(f"Logout error: {e}")

    def get_user_info(self, username: str) -> Optional[Dict]:
        """Get user information by username"""
        try:
            user_id = self.client.user_id_from_username(username)
            user_info = self.client.user_info(user_id)
            return {
                "pk": user_info.pk,
                "username": user_info.username,
                "full_name": user_info.full_name,
                "biography": user_info.biography,
                "follower_count": user_info.follower_count,
                "following_count": user_info.following_count,
                "media_count": user_info.media_count,
                "is_private": user_info.is_private,
                "is_verified": user_info.is_verified,
                "profile_pic_url": user_info.profile_pic_url_hd or user_info.profile_pic_url,
            }
        except Exception as e:
            logger.error(f"Error getting user info for {username}: {e}")
            return None

    def get_own_info(self) -> Optional[Dict]:
        """Get own account information"""
        try:
            user_info = self.client.account_info()
            return {
                "pk": user_info.pk,
                "username": user_info.username,
                "full_name": user_info.full_name,
                "biography": user_info.biography,
                "follower_count": user_info.follower_count,
                "following_count": user_info.following_count,
                "media_count": user_info.media_count,
                "is_private": user_info.is_private,
                "is_business": user_info.is_business,
                "profile_pic_url": user_info.profile_pic_url_hd or user_info.profile_pic_url,
            }
        except Exception as e:
            logger.error(f"Error getting own info: {e}")
            return None

    def follow_user(self, user_id: int) -> bool:
        """Follow a user"""
        try:
            self.client.user_follow(user_id)
            logger.info(f"Followed user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error following user {user_id}: {e}")
            return False

    def unfollow_user(self, user_id: int) -> bool:
        """Unfollow a user"""
        try:
            self.client.user_unfollow(user_id)
            logger.info(f"Unfollowed user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error unfollowing user {user_id}: {e}")
            return False

    def like_media(self, media_id: str) -> bool:
        """Like a media post"""
        try:
            self.client.media_like(media_id)
            logger.info(f"Liked media {media_id}")
            return True
        except Exception as e:
            logger.error(f"Error liking media {media_id}: {e}")
            return False

    def comment_media(self, media_id: str, text: str) -> bool:
        """Comment on a media post"""
        try:
            self.client.media_comment(media_id, text)
            logger.info(f"Commented on media {media_id}")
            return True
        except Exception as e:
            logger.error(f"Error commenting on media {media_id}: {e}")
            return False

    def send_direct_message(self, user_ids: List[int], text: str) -> bool:
        """Send direct message to users"""
        try:
            self.client.direct_send(text, user_ids)
            logger.info(f"Sent DM to {len(user_ids)} users")
            return True
        except Exception as e:
            logger.error(f"Error sending DM: {e}")
            return False

    def get_direct_threads(self, amount: int = 20) -> List[Dict]:
        """Get direct message threads"""
        try:
            threads = self.client.direct_threads(amount=amount)
            return [
                {
                    "thread_id": thread.id,
                    "users": [{"user_id": user.pk, "username": user.username} for user in thread.users],
                    "last_activity": thread.last_activity_at,
                    "has_unread": thread.read_state == 0
                }
                for thread in threads
            ]
        except Exception as e:
            logger.error(f"Error getting direct threads: {e}")
            return []

    def get_direct_messages(self, thread_id: str, amount: int = 20) -> List[Dict]:
        """Get messages from a thread"""
        try:
            messages = self.client.direct_messages(thread_id, amount=amount)
            return [
                {
                    "message_id": msg.id,
                    "user_id": msg.user_id,
                    "text": msg.text,
                    "timestamp": msg.timestamp
                }
                for msg in messages
            ]
        except Exception as e:
            logger.error(f"Error getting messages from thread {thread_id}: {e}")
            return []

    def view_story(self, user_id: int) -> bool:
        """View user's story"""
        try:
            stories = self.client.user_stories(user_id)
            if stories:
                for story in stories:
                    self.client.story_seen([story.pk])
                logger.info(f"Viewed {len(stories)} stories from user {user_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error viewing story for user {user_id}: {e}")
            return False

    def get_user_followers(self, user_id: int, amount: int = 0) -> List[Dict]:
        """Get user's followers"""
        try:
            followers = self.client.user_followers(user_id, amount=amount)
            return [
                {
                    "pk": user.pk,
                    "username": user.username,
                    "full_name": user.full_name,
                    "is_private": user.is_private,
                    "is_verified": user.is_verified
                }
                for user_id, user in followers.items()
            ]
        except Exception as e:
            logger.error(f"Error getting followers for user {user_id}: {e}")
            return []

    def get_user_following(self, user_id: int, amount: int = 0) -> List[Dict]:
        """Get users that user is following"""
        try:
            following = self.client.user_following(user_id, amount=amount)
            return [
                {
                    "pk": user.pk,
                    "username": user.username,
                    "full_name": user.full_name,
                    "is_private": user.is_private,
                    "is_verified": user.is_verified
                }
                for user_id, user in following.items()
            ]
        except Exception as e:
            logger.error(f"Error getting following for user {user_id}: {e}")
            return []

    def get_user_medias(self, user_id: int, amount: int = 20) -> List[Dict]:
        """Get user's media posts"""
        try:
            medias = self.client.user_medias(user_id, amount=amount)
            return [
                {
                    "pk": media.pk,
                    "id": media.id,
                    "code": media.code,
                    "caption": media.caption_text,
                    "like_count": media.like_count,
                    "comment_count": media.comment_count,
                    "media_type": media.media_type,
                    "thumbnail_url": media.thumbnail_url,
                }
                for media in medias
            ]
        except Exception as e:
            logger.error(f"Error getting medias for user {user_id}: {e}")
            return []

    def search_users(self, query: str) -> List[Dict]:
        """Search for users"""
        try:
            users = self.client.search_users(query)
            return [
                {
                    "pk": user.pk,
                    "username": user.username,
                    "full_name": user.full_name,
                    "is_private": user.is_private,
                    "is_verified": user.is_verified,
                    "follower_count": user.follower_count
                }
                for user in users
            ]
        except Exception as e:
            logger.error(f"Error searching users with query '{query}': {e}")
            return []

    def get_hashtag_medias(self, hashtag: str, amount: int = 20) -> List[Dict]:
        """Get recent medias for hashtag"""
        try:
            medias = self.client.hashtag_medias_recent(hashtag, amount=amount)
            return [
                {
                    "pk": media.pk,
                    "id": media.id,
                    "code": media.code,
                    "user": {"pk": media.user.pk, "username": media.user.username},
                    "caption": media.caption_text,
                    "like_count": media.like_count,
                    "comment_count": media.comment_count,
                }
                for media in medias
            ]
        except Exception as e:
            logger.error(f"Error getting medias for hashtag #{hashtag}: {e}")
            return []

# Client cache to reuse sessions
_client_cache: Dict[str, InstagramClient] = {}

def get_instagram_client(username: str) -> InstagramClient:
    """Get or create Instagram client for username"""
    if username not in _client_cache:
        _client_cache[username] = InstagramClient(username)
    return _client_cache[username]

def remove_instagram_client(username: str):
    """Remove client from cache"""
    if username in _client_cache:
        del _client_cache[username]
