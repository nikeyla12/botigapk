"""Database package"""
from database.client import db

__all__ = ["db"]
