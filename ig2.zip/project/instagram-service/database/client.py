"""
Supabase database client for Instagram service
"""

from supabase import create_client, Client
from config.settings import settings
from config.logger import setup_logger
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = setup_logger(__name__)

class DatabaseClient:
    """Supabase database operations"""

    def __init__(self):
        self.client: Client = create_client(
            settings.SUPABASE_URL,
            settings.SUPABASE_SERVICE_ROLE_KEY
        )

    # Instagram Accounts
    async def get_account(self, account_id: str) -> Optional[Dict]:
        """Get Instagram account by ID"""
        try:
            response = self.client.table("instagram_accounts").select("*").eq("id", account_id).maybe_single().execute()
            return response.data
        except Exception as e:
            logger.error(f"Error getting account {account_id}: {e}")
            return None

    async def get_account_by_username(self, username: str) -> Optional[Dict]:
        """Get Instagram account by username"""
        try:
            response = self.client.table("instagram_accounts").select("*").eq("username", username).maybe_single().execute()
            return response.data
        except Exception as e:
            logger.error(f"Error getting account by username {username}: {e}")
            return None

    async def update_account_status(self, account_id: str, status: str, error_message: Optional[str] = None):
        """Update account status"""
        try:
            data = {"status": status, "last_used_at": datetime.utcnow().isoformat()}
            if error_message:
                data["error_message"] = error_message
            self.client.table("instagram_accounts").update(data).eq("id", account_id).execute()
        except Exception as e:
            logger.error(f"Error updating account status: {e}")

    # Action Logs
    async def log_action(self, account_id: str, action_type: str, target_user: Optional[str] = None,
                        status: str = "success", details: Optional[Dict] = None):
        """Log an Instagram action"""
        try:
            data = {
                "account_id": account_id,
                "action_type": action_type,
                "target_user": target_user,
                "status": status,
                "details": details,
                "created_at": datetime.utcnow().isoformat()
            }
            self.client.table("action_logs").insert(data).execute()
        except Exception as e:
            logger.error(f"Error logging action: {e}")

    async def get_action_count_today(self, account_id: str, action_type: str) -> int:
        """Get count of actions performed today"""
        try:
            today = datetime.utcnow().date().isoformat()
            response = self.client.table("action_logs").select("id", count="exact").eq("account_id", account_id).eq("action_type", action_type).gte("created_at", today).execute()
            return response.count if response.count else 0
        except Exception as e:
            logger.error(f"Error getting action count: {e}")
            return 0

    # DM Templates
    async def get_dm_templates(self, user_id: str) -> List[Dict]:
        """Get DM templates for user"""
        try:
            response = self.client.table("dm_templates").select("*").eq("user_id", user_id).eq("is_active", True).execute()
            return response.data if response.data else []
        except Exception as e:
            logger.error(f"Error getting DM templates: {e}")
            return []

    # DM Campaigns
    async def get_active_campaigns(self, account_id: str) -> List[Dict]:
        """Get active DM campaigns for account"""
        try:
            response = self.client.table("dm_campaigns").select("*").eq("account_id", account_id).eq("status", "active").execute()
            return response.data if response.data else []
        except Exception as e:
            logger.error(f"Error getting active campaigns: {e}")
            return []

    async def update_campaign_stats(self, campaign_id: str, sent_count: int):
        """Update campaign sent count"""
        try:
            self.client.table("dm_campaigns").update({"sent_count": sent_count, "last_sent_at": datetime.utcnow().isoformat()}).eq("id", campaign_id).execute()
        except Exception as e:
            logger.error(f"Error updating campaign stats: {e}")

    # Analytics
    async def get_analytics(self, account_id: str, days: int = 7) -> Dict:
        """Get analytics for account"""
        try:
            response = self.client.table("analytics").select("*").eq("account_id", account_id).order("date", desc=True).limit(days).execute()
            return {"data": response.data if response.data else []}
        except Exception as e:
            logger.error(f"Error getting analytics: {e}")
            return {"data": []}

    async def save_analytics(self, account_id: str, date: str, metrics: Dict):
        """Save daily analytics"""
        try:
            data = {
                "account_id": account_id,
                "date": date,
                "followers_count": metrics.get("followers", 0),
                "following_count": metrics.get("following", 0),
                "posts_count": metrics.get("posts", 0),
                "engagement_rate": metrics.get("engagement_rate", 0),
                "created_at": datetime.utcnow().isoformat()
            }
            self.client.table("analytics").upsert(data, on_conflict="account_id,date").execute()
        except Exception as e:
            logger.error(f"Error saving analytics: {e}")

# Global database client instance
db = DatabaseClient()
