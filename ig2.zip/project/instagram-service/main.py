"""
Instagram Automation Service - FastAPI Application
Main entry point for the Instagram automation REST API
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn
import logging

from config.settings import settings
from config.logger import setup_logger
from api.routes import auth, actions, dm, story, scraper, upload, profile, health

# Setup logger
logger = setup_logger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Instagram Automation Service...")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"API Port: {settings.API_PORT}")
    yield
    logger.info("Shutting down Instagram Automation Service...")

# Initialize FastAPI app
app = FastAPI(
    title="Instagram Automation API",
    description="REST API for Instagram automation features",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, prefix="/api", tags=["Health"])
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(actions.router, prefix="/api/actions", tags=["Actions"])
app.include_router(dm.router, prefix="/api/dm", tags=["Direct Messages"])
app.include_router(story.router, prefix="/api/story", tags=["Stories"])
app.include_router(scraper.router, prefix="/api/scraper", tags=["Scraper"])
app.include_router(upload.router, prefix="/api/upload", tags=["Upload"])
app.include_router(profile.router, prefix="/api/profile", tags=["Profile"])

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Instagram Automation API",
        "version": "1.0.0",
        "status": "running"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        workers=settings.API_WORKERS,
        reload=settings.ENVIRONMENT == "development",
        log_level=settings.LOG_LEVEL.lower()
    )
