"""Authentication endpoints for Instagram accounts"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from instagram.client import get_instagram_client, remove_instagram_client
from database.client import db
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class LoginRequest(BaseModel):
    username: str
    password: str
    verification_code: Optional[str] = None

class LogoutRequest(BaseModel):
    username: str

@router.post("/login")
async def login(request: LoginRequest):
    """Login to Instagram account"""
    try:
        client = get_instagram_client(request.username)
        result = client.login(request.password, request.verification_code)

        if result["success"]:
            # Get account info
            account_info = client.get_own_info()

            if account_info:
                # Update account in database
                account = await db.get_account_by_username(request.username)
                if account:
                    await db.update_account_status(account["id"], "active")

                return {
                    "success": True,
                    "message": result["message"],
                    "account": account_info
                }

        return result

    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/logout")
async def logout(request: LogoutRequest):
    """Logout from Instagram account"""
    try:
        client = get_instagram_client(request.username)
        client.logout()
        remove_instagram_client(request.username)

        # Update account status in database
        account = await db.get_account_by_username(request.username)
        if account:
            await db.update_account_status(account["id"], "inactive")

        return {"success": True, "message": "Logged out successfully"}

    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/account-info/{username}")
async def get_account_info(username: str):
    """Get Instagram account information"""
    try:
        client = get_instagram_client(username)
        account_info = client.get_own_info()

        if not account_info:
            raise HTTPException(status_code=404, detail="Account not found or not logged in")

        return {"success": True, "account": account_info}

    except Exception as e:
        logger.error(f"Error getting account info: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/user-info/{username}/{target_username}")
async def get_user_info(username: str, target_username: str):
    """Get information about another Instagram user"""
    try:
        client = get_instagram_client(username)
        user_info = client.get_user_info(target_username)

        if not user_info:
            raise HTTPException(status_code=404, detail="User not found")

        return {"success": True, "user": user_info}

    except Exception as e:
        logger.error(f"Error getting user info: {e}")
        raise HTTPException(status_code=500, detail=str(e))
