"""Direct message endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from instagram.client import get_instagram_client
from database.client import db
from safety.limits import safety_limits
from safety.behavior import human_behavior
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class SendDMRequest(BaseModel):
    username: str
    target_usernames: List[str]
    message: str

class GetInboxRequest(BaseModel):
    username: str
    amount: int = 20

class GetMessagesRequest(BaseModel):
    username: str
    thread_id: str
    amount: int = 20

class ReplyDMRequest(BaseModel):
    username: str
    thread_id: str
    message: str

@router.post("/send")
async def send_dm(request: SendDMRequest):
    """Send direct message to users"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "dm")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get user IDs from usernames
        user_ids = []
        for target_username in request.target_usernames:
            user_info = client.get_user_info(target_username)
            if user_info:
                user_ids.append(user_info["pk"])

        if not user_ids:
            raise HTTPException(status_code=404, detail="No valid target users found")

        # Human behavior delay
        await human_behavior.random_delay()

        # Send DM
        success = client.send_direct_message(user_ids, request.message)

        if success:
            # Log action for each recipient
            for target_username in request.target_usernames:
                await db.log_action(
                    account["id"],
                    "dm",
                    target_username,
                    "success",
                    {"message": request.message}
                )

            return {
                "success": True,
                "message": f"DM sent to {len(user_ids)} users",
                "recipients": request.target_usernames,
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to send DM")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Send DM error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/inbox")
async def get_inbox(request: GetInboxRequest):
    """Get direct message inbox"""
    try:
        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get threads
        threads = client.get_direct_threads(request.amount)

        return {
            "success": True,
            "threads": threads,
            "count": len(threads)
        }

    except Exception as e:
        logger.error(f"Get inbox error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/messages")
async def get_messages(request: GetMessagesRequest):
    """Get messages from a thread"""
    try:
        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get messages
        messages = client.get_direct_messages(request.thread_id, request.amount)

        return {
            "success": True,
            "messages": messages,
            "count": len(messages)
        }

    except Exception as e:
        logger.error(f"Get messages error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/reply")
async def reply_dm(request: ReplyDMRequest):
    """Reply to a DM thread"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "dm")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Human behavior delay
        await human_behavior.random_delay()

        # Send reply
        success = client.send_direct_message([request.thread_id], request.message)

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "dm",
                None,
                "success",
                {"thread_id": request.thread_id, "message": request.message}
            )

            return {
                "success": True,
                "message": "Reply sent successfully",
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to send reply")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reply DM error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
