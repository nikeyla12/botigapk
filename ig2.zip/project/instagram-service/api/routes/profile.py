"""Profile management endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from instagram.client import get_instagram_client
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class UpdateBioRequest(BaseModel):
    username: str
    biography: str

class UpdateProfileRequest(BaseModel):
    username: str
    full_name: Optional[str] = None
    biography: Optional[str] = None
    external_url: Optional[str] = None

@router.post("/update-bio")
async def update_bio(request: UpdateBioRequest):
    """Update account biography"""
    try:
        client = get_instagram_client(request.username)

        # Update bio
        client.client.account_set_biography(request.biography)

        return {
            "success": True,
            "message": "Biography updated successfully"
        }

    except Exception as e:
        logger.error(f"Update bio error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/update")
async def update_profile(request: UpdateProfileRequest):
    """Update profile information"""
    try:
        client = get_instagram_client(request.username)

        # Get current info
        current_info = client.get_own_info()
        if not current_info:
            raise HTTPException(status_code=404, detail="Failed to get current profile info")

        # Update with new values or keep current
        full_name = request.full_name if request.full_name else current_info.get("full_name", "")
        biography = request.biography if request.biography else current_info.get("biography", "")
        external_url = request.external_url if request.external_url else ""

        # Edit profile
        client.client.account_edit(
            full_name=full_name,
            biography=biography,
            external_url=external_url
        )

        return {
            "success": True,
            "message": "Profile updated successfully"
        }

    except Exception as e:
        logger.error(f"Update profile error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
