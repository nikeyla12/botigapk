"""Instagram action endpoints (follow, unfollow, like, comment)"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from instagram.client import get_instagram_client
from database.client import db
from safety.limits import safety_limits
from safety.behavior import human_behavior
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class FollowRequest(BaseModel):
    username: str
    target_username: str

class UnfollowRequest(BaseModel):
    username: str
    target_username: str

class LikeRequest(BaseModel):
    username: str
    media_id: str

class CommentRequest(BaseModel):
    username: str
    media_id: str
    text: str

class BulkFollowRequest(BaseModel):
    username: str
    target_usernames: List[str]
    respect_limits: bool = True

@router.post("/follow")
async def follow_user(request: FollowRequest):
    """Follow a user"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "follow")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get target user info
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Human behavior delay
        await human_behavior.follow_delay()

        # Follow user
        success = client.follow_user(target_user["pk"])

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "follow",
                request.target_username,
                "success",
                {"user_id": target_user["pk"]}
            )

            return {
                "success": True,
                "message": f"Successfully followed @{request.target_username}",
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to follow user")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Follow error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/unfollow")
async def unfollow_user(request: UnfollowRequest):
    """Unfollow a user"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "unfollow")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get target user info
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Human behavior delay
        await human_behavior.random_delay()

        # Unfollow user
        success = client.unfollow_user(target_user["pk"])

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "unfollow",
                request.target_username,
                "success",
                {"user_id": target_user["pk"]}
            )

            return {
                "success": True,
                "message": f"Successfully unfollowed @{request.target_username}",
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to unfollow user")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unfollow error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/like")
async def like_media(request: LikeRequest):
    """Like a media post"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "like")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Human behavior delay
        await human_behavior.random_delay()

        # Like media
        success = client.like_media(request.media_id)

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "like",
                None,
                "success",
                {"media_id": request.media_id}
            )

            return {
                "success": True,
                "message": "Successfully liked media",
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to like media")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Like error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/comment")
async def comment_media(request: CommentRequest):
    """Comment on a media post"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "comment")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Human behavior delay
        await human_behavior.random_delay()

        # Comment on media
        success = client.comment_media(request.media_id, request.text)

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "comment",
                None,
                "success",
                {"media_id": request.media_id, "text": request.text}
            )

            return {
                "success": True,
                "message": "Successfully commented on media",
                "limits": limit_check
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to comment on media")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Comment error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/bulk-follow")
async def bulk_follow(request: BulkFollowRequest):
    """Follow multiple users in bulk"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Get Instagram client
        client = get_instagram_client(request.username)

        results = []
        successful = 0
        failed = 0

        for target_username in request.target_usernames:
            try:
                # Check limits if enabled
                if request.respect_limits:
                    limit_check = await safety_limits.check_limit(account["id"], "follow")
                    if not limit_check["allowed"]:
                        results.append({
                            "username": target_username,
                            "success": False,
                            "reason": "Daily limit reached"
                        })
                        failed += 1
                        continue

                # Get target user
                target_user = client.get_user_info(target_username)
                if not target_user:
                    results.append({
                        "username": target_username,
                        "success": False,
                        "reason": "User not found"
                    })
                    failed += 1
                    continue

                # Human behavior delay
                await human_behavior.follow_delay()

                # Follow
                success = client.follow_user(target_user["pk"])

                if success:
                    await db.log_action(account["id"], "follow", target_username, "success")
                    results.append({"username": target_username, "success": True})
                    successful += 1
                else:
                    results.append({
                        "username": target_username,
                        "success": False,
                        "reason": "Follow failed"
                    })
                    failed += 1

                # Random long pause
                if human_behavior.should_pause():
                    await human_behavior.long_pause()

            except Exception as e:
                logger.error(f"Error following {target_username}: {e}")
                results.append({
                    "username": target_username,
                    "success": False,
                    "reason": str(e)
                })
                failed += 1

        return {
            "success": True,
            "total": len(request.target_usernames),
            "successful": successful,
            "failed": failed,
            "results": results
        }

    except Exception as e:
        logger.error(f"Bulk follow error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/limits/{username}")
async def get_limits(username: str):
    """Get current action limits for account"""
    try:
        account = await db.get_account_by_username(username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        limits = await safety_limits.get_all_limits(account["id"])

        return {"success": True, "limits": limits}

    except Exception as e:
        logger.error(f"Error getting limits: {e}")
        raise HTTPException(status_code=500, detail=str(e))
