"""Story viewing and upload endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from instagram.client import get_instagram_client
from database.client import db
from safety.limits import safety_limits
from safety.behavior import human_behavior
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class ViewStoryRequest(BaseModel):
    username: str
    target_username: str

class BulkViewStoryRequest(BaseModel):
    username: str
    target_usernames: List[str]

@router.post("/view")
async def view_story(request: ViewStoryRequest):
    """View a user's story"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Check safety limits
        limit_check = await safety_limits.check_limit(account["id"], "story_view")
        if not limit_check["allowed"]:
            raise HTTPException(status_code=429, detail=limit_check["message"])

        # Get Instagram client
        client = get_instagram_client(request.username)

        # Get target user info
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Human behavior delay
        await human_behavior.random_delay()

        # View story
        success = client.view_story(target_user["pk"])

        if success:
            # Log action
            await db.log_action(
                account["id"],
                "story_view",
                request.target_username,
                "success",
                {"user_id": target_user["pk"]}
            )

            return {
                "success": True,
                "message": f"Viewed story of @{request.target_username}",
                "limits": limit_check
            }
        else:
            return {
                "success": False,
                "message": f"No active stories from @{request.target_username}"
            }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"View story error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/bulk-view")
async def bulk_view_stories(request: BulkViewStoryRequest):
    """View stories from multiple users"""
    try:
        # Get account
        account = await db.get_account_by_username(request.username)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")

        # Get Instagram client
        client = get_instagram_client(request.username)

        results = []
        successful = 0
        failed = 0

        for target_username in request.target_usernames:
            try:
                # Check limits
                limit_check = await safety_limits.check_limit(account["id"], "story_view")
                if not limit_check["allowed"]:
                    results.append({
                        "username": target_username,
                        "success": False,
                        "reason": "Daily limit reached"
                    })
                    failed += 1
                    continue

                # Get target user
                target_user = client.get_user_info(target_username)
                if not target_user:
                    results.append({
                        "username": target_username,
                        "success": False,
                        "reason": "User not found"
                    })
                    failed += 1
                    continue

                # Human behavior delay
                await human_behavior.random_delay()

                # View story
                success = client.view_story(target_user["pk"])

                if success:
                    await db.log_action(account["id"], "story_view", target_username, "success")
                    results.append({"username": target_username, "success": True})
                    successful += 1
                else:
                    results.append({
                        "username": target_username,
                        "success": False,
                        "reason": "No active stories"
                    })
                    failed += 1

                # Random long pause
                if human_behavior.should_pause():
                    await human_behavior.long_pause()

            except Exception as e:
                logger.error(f"Error viewing story of {target_username}: {e}")
                results.append({
                    "username": target_username,
                    "success": False,
                    "reason": str(e)
                })
                failed += 1

        return {
            "success": True,
            "total": len(request.target_usernames),
            "successful": successful,
            "failed": failed,
            "results": results
        }

    except Exception as e:
        logger.error(f"Bulk view stories error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
