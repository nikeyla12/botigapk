"""Upload endpoints for photos, videos, stories"""

from fastapi import APIRouter, HTTPException, File, UploadFile, Form
from typing import Optional
from instagram.client import get_instagram_client
from config.logger import setup_logger
import tempfile
import os

logger = setup_logger(__name__)
router = APIRouter()

@router.post("/photo")
async def upload_photo(
    username: str = Form(...),
    caption: Optional[str] = Form(None),
    file: UploadFile = File(...)
):
    """Upload a photo post"""
    try:
        client = get_instagram_client(username)

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_file_path = tmp_file.name

        try:
            # Upload photo
            media = client.client.photo_upload(tmp_file_path, caption or "")

            return {
                "success": True,
                "message": "Photo uploaded successfully",
                "media_id": media.pk,
                "media_code": media.code
            }

        finally:
            # Clean up temp file
            if os.path.exists(tmp_file_path):
                os.remove(tmp_file_path)

    except Exception as e:
        logger.error(f"Upload photo error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/story")
async def upload_story(
    username: str = Form(...),
    file: UploadFile = File(...)
):
    """Upload a story"""
    try:
        client = get_instagram_client(username)

        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_file_path = tmp_file.name

        try:
            # Upload story
            story = client.client.photo_upload_to_story(tmp_file_path)

            return {
                "success": True,
                "message": "Story uploaded successfully",
                "story_id": story.pk
            }

        finally:
            # Clean up temp file
            if os.path.exists(tmp_file_path):
                os.remove(tmp_file_path)

    except Exception as e:
        logger.error(f"Upload story error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
