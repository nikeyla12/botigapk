"""Scraper endpoints for followers, hashtags, etc."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from instagram.client import get_instagram_client
from config.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()

class GetFollowersRequest(BaseModel):
    username: str
    target_username: str
    amount: int = 100

class GetFollowingRequest(BaseModel):
    username: str
    target_username: str
    amount: int = 100

class GetMediasRequest(BaseModel):
    username: str
    target_username: str
    amount: int = 20

class SearchUsersRequest(BaseModel):
    username: str
    query: str

class GetHashtagMediasRequest(BaseModel):
    username: str
    hashtag: str
    amount: int = 20

@router.post("/followers")
async def get_followers(request: GetFollowersRequest):
    """Get followers of a user"""
    try:
        client = get_instagram_client(request.username)

        # Get target user
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Get followers
        followers = client.get_user_followers(target_user["pk"], request.amount)

        return {
            "success": True,
            "username": request.target_username,
            "followers": followers,
            "count": len(followers)
        }

    except Exception as e:
        logger.error(f"Get followers error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/following")
async def get_following(request: GetFollowingRequest):
    """Get users that target user is following"""
    try:
        client = get_instagram_client(request.username)

        # Get target user
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Get following
        following = client.get_user_following(target_user["pk"], request.amount)

        return {
            "success": True,
            "username": request.target_username,
            "following": following,
            "count": len(following)
        }

    except Exception as e:
        logger.error(f"Get following error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/medias")
async def get_medias(request: GetMediasRequest):
    """Get media posts from a user"""
    try:
        client = get_instagram_client(request.username)

        # Get target user
        target_user = client.get_user_info(request.target_username)
        if not target_user:
            raise HTTPException(status_code=404, detail="Target user not found")

        # Get medias
        medias = client.get_user_medias(target_user["pk"], request.amount)

        return {
            "success": True,
            "username": request.target_username,
            "medias": medias,
            "count": len(medias)
        }

    except Exception as e:
        logger.error(f"Get medias error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/search-users")
async def search_users(request: SearchUsersRequest):
    """Search for users"""
    try:
        client = get_instagram_client(request.username)

        # Search users
        users = client.search_users(request.query)

        return {
            "success": True,
            "query": request.query,
            "users": users,
            "count": len(users)
        }

    except Exception as e:
        logger.error(f"Search users error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/hashtag-medias")
async def get_hashtag_medias(request: GetHashtagMediasRequest):
    """Get recent medias for a hashtag"""
    try:
        client = get_instagram_client(request.username)

        # Get medias
        medias = client.get_hashtag_medias(request.hashtag, request.amount)

        return {
            "success": True,
            "hashtag": request.hashtag,
            "medias": medias,
            "count": len(medias)
        }

    except Exception as e:
        logger.error(f"Get hashtag medias error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
