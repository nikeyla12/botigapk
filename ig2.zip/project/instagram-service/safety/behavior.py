"""
Human behavior simulation to avoid detection
Implements random delays and natural patterns
"""

import random
import asyncio
from config.settings import settings
from config.logger import setup_logger

logger = setup_logger(__name__)

class HumanBehavior:
    """Simulate human-like behavior patterns"""

    @staticmethod
    async def random_delay(min_seconds: int = None, max_seconds: int = None):
        """Add random delay between actions"""
        min_delay = min_seconds or settings.MIN_DELAY_BETWEEN_ACTIONS
        max_delay = max_seconds or settings.MAX_DELAY_BETWEEN_ACTIONS

        delay = random.uniform(min_delay, max_delay)
        logger.debug(f"Waiting {delay:.2f} seconds (human behavior simulation)")
        await asyncio.sleep(delay)

    @staticmethod
    async def follow_delay():
        """Delay specifically for follow actions (longer)"""
        await HumanBehavior.random_delay(
            settings.MIN_DELAY_BETWEEN_FOLLOWS,
            settings.MAX_DELAY_BETWEEN_FOLLOWS
        )

    @staticmethod
    def should_pause() -> bool:
        """Randomly decide if should take a longer pause (10% chance)"""
        return random.random() < 0.1

    @staticmethod
    async def long_pause():
        """Take a longer pause (5-15 minutes)"""
        pause_minutes = random.uniform(5, 15)
        logger.info(f"Taking a long pause: {pause_minutes:.2f} minutes")
        await asyncio.sleep(pause_minutes * 60)

    @staticmethod
    def get_active_hours() -> tuple:
        """Get random active hours that seem human (7 AM - 11 PM)"""
        start_hour = random.randint(7, 10)
        end_hour = random.randint(21, 23)
        return (start_hour, end_hour)

    @staticmethod
    def is_within_active_hours(start_hour: int = 7, end_hour: int = 23) -> bool:
        """Check if current time is within active hours"""
        from datetime import datetime
        current_hour = datetime.now().hour
        return start_hour <= current_hour <= end_hour

human_behavior = HumanBehavior()
