"""Safety package for Instagram automation"""
from safety.limits import safety_limits
from safety.behavior import human_behavior

__all__ = ["safety_limits", "human_behavior"]
