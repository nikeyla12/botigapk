"""
Safety limits and rate limiting for Instagram actions
Prevents account bans by enforcing daily limits
"""

from config.settings import settings
from config.logger import setup_logger
from database.client import db
from datetime import datetime, timedelta
from typing import Dict

logger = setup_logger(__name__)

class SafetyLimits:
    """Manage action limits to prevent Instagram bans"""

    LIMITS = {
        "follow": settings.MAX_FOLLOWS_PER_DAY,
        "unfollow": settings.MAX_UNFOLLOWS_PER_DAY,
        "like": settings.MAX_LIKES_PER_DAY,
        "comment": settings.MAX_COMMENTS_PER_DAY,
        "dm": settings.MAX_DMS_PER_DAY,
        "story_view": settings.MAX_STORY_VIEWS_PER_DAY,
    }

    @staticmethod
    async def check_limit(account_id: str, action_type: str) -> Dict[str, any]:
        """
        Check if action is within daily limit
        Returns: {"allowed": bool, "remaining": int, "limit": int, "message": str}
        """
        try:
            # Get action count for today
            count_today = await db.get_action_count_today(account_id, action_type)

            # Get limit for this action type
            limit = SafetyLimits.LIMITS.get(action_type, 100)

            # Check warmup period
            account = await db.get_account(account_id)
            if account and settings.WARMUP_ENABLED:
                created_at = datetime.fromisoformat(account["created_at"].replace("Z", "+00:00"))
                days_old = (datetime.now(created_at.tzinfo) - created_at).days

                if days_old < settings.WARMUP_DAYS:
                    # Reduce limit during warmup period
                    limit = int(limit * settings.WARMUP_MULTIPLIER)
                    logger.info(f"Warmup mode active for account {account_id}: {days_old}/{settings.WARMUP_DAYS} days, limit reduced to {limit}")

            remaining = max(0, limit - count_today)
            allowed = count_today < limit

            message = f"Action allowed. {remaining}/{limit} remaining today." if allowed else f"Daily limit reached for {action_type}. Try again tomorrow."

            return {
                "allowed": allowed,
                "remaining": remaining,
                "limit": limit,
                "count_today": count_today,
                "message": message
            }

        except Exception as e:
            logger.error(f"Error checking limit: {e}")
            # Allow action if check fails (fail-open)
            return {"allowed": True, "remaining": 0, "limit": 0, "message": "Limit check failed"}

    @staticmethod
    async def get_all_limits(account_id: str) -> Dict[str, Dict]:
        """Get all action limits and their current status"""
        result = {}
        for action_type in SafetyLimits.LIMITS.keys():
            result[action_type] = await SafetyLimits.check_limit(account_id, action_type)
        return result

safety_limits = SafetyLimits()
