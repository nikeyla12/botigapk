#!/bin/bash

# Instagram Automation - Complete Installation Script
# This script will install all dependencies and setup the project

set -e  # Exit on error

echo "╔═══════════════════════════════════════════════════════╗"
echo "║   Instagram Automation - Installation Script          ║"
echo "║   Telegram Bot + Instagram Service                    ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -eq 0 ]; then
   echo -e "${RED}❌ Please do not run as root${NC}"
   exit 1
fi

echo -e "${YELLOW}📋 Checking system requirements...${NC}"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found. Installing...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    echo -e "${GREEN}✅ Node.js found: $(node --version)${NC}"
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python not found. Installing...${NC}"
    sudo apt-get install -y python3 python3-pip
else
    echo -e "${GREEN}✅ Python found: $(python3 --version)${NC}"
fi

# Check Redis
if ! command -v redis-cli &> /dev/null; then
    echo -e "${RED}❌ Redis not found. Installing...${NC}"
    sudo apt-get install -y redis-server
    sudo systemctl start redis
    sudo systemctl enable redis
else
    echo -e "${GREEN}✅ Redis found${NC}"
fi

# Check PM2
if ! command -v pm2 &> /dev/null; then
    echo -e "${YELLOW}⚙️  Installing PM2...${NC}"
    sudo npm install -g pm2
else
    echo -e "${GREEN}✅ PM2 found: $(pm2 --version)${NC}"
fi

echo ""
echo -e "${YELLOW}📦 Installing project dependencies...${NC}"
echo ""

# Install Telegram Bot dependencies
echo -e "${YELLOW}Installing Telegram Bot dependencies...${NC}"
cd telegram-bot
npm install
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Telegram Bot dependencies installed${NC}"
else
    echo -e "${RED}❌ Failed to install Telegram Bot dependencies${NC}"
    exit 1
fi
cd ..

# Install Instagram Service dependencies
echo -e "${YELLOW}Installing Instagram Service dependencies...${NC}"
cd instagram-service
pip3 install -r requirements.txt
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Instagram Service dependencies installed${NC}"
else
    echo -e "${RED}❌ Failed to install Instagram Service dependencies${NC}"
    exit 1
fi
cd ..

echo ""
echo -e "${YELLOW}⚙️  Setting up environment files...${NC}"
echo ""

# Setup Telegram Bot .env
if [ ! -f telegram-bot/.env ]; then
    cp telegram-bot/.env.example telegram-bot/.env
    echo -e "${GREEN}✅ Created telegram-bot/.env${NC}"
    echo -e "${YELLOW}⚠️  Please edit telegram-bot/.env with your credentials${NC}"
else
    echo -e "${YELLOW}⚠️  telegram-bot/.env already exists${NC}"
fi

# Setup Instagram Service .env
if [ ! -f instagram-service/.env ]; then
    cp instagram-service/.env.example instagram-service/.env
    echo -e "${GREEN}✅ Created instagram-service/.env${NC}"
    echo -e "${YELLOW}⚠️  Please edit instagram-service/.env with your credentials${NC}"
else
    echo -e "${YELLOW}⚠️  instagram-service/.env already exists${NC}"
fi

# Create logs directory
mkdir -p logs
mkdir -p telegram-bot/logs
mkdir -p instagram-service/sessions

echo ""
echo "╔═══════════════════════════════════════════════════════╗"
echo "║           ✅ Installation Complete!                   ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""
echo -e "${GREEN}Next steps:${NC}"
echo ""
echo "1. Edit environment files:"
echo "   - telegram-bot/.env"
echo "   - instagram-service/.env"
echo ""
echo "2. Required credentials:"
echo "   - TELEGRAM_BOT_TOKEN (from @BotFather)"
echo "   - SUPABASE_URL"
echo "   - SUPABASE_ANON_KEY"
echo "   - SUPABASE_SERVICE_ROLE_KEY"
echo ""
echo "3. Start services:"
echo "   ${YELLOW}pm2 start ecosystem.config.js${NC}"
echo ""
echo "4. View status:"
echo "   ${YELLOW}pm2 status${NC}"
echo ""
echo "5. View logs:"
echo "   ${YELLOW}pm2 logs${NC}"
echo ""
echo -e "${GREEN}📚 Documentation:${NC}"
echo "   - README_TELEGRAM_BOT.md (Overview)"
echo "   - QUICK_START_TELEGRAM_BOT.md (Quick setup)"
echo "   - TELEGRAM_BOT_COMPLETE_SETUP.md (Full guide)"
echo ""
echo -e "${GREEN}Happy automating! 🚀${NC}"
