# 📖 PANDUAN LENGKAP - Instagram Telegram Bot

## 🎯 DAFTAR ISI
1. [Cara Buat Bot Telegram](#1-cara-buat-bot-telegram)
2. [Setup di Laptop/Termux](#2-setup-di-laptoptermux)
3. [Fitur & Cara Penggunaan](#3-fitur--cara-penggunaan)
4. [Limit & Keamanan](#4-limit--keamanan)
5. [FAQ & Troubleshooting](#5-faq--troubleshooting)

---

## 1️⃣ CARA BUAT BOT TELEGRAM

### Step 1: Chat BotFather

1. **Buka Telegram**, cari `@BotFather`
2. Ketik: `/start`
3. Ketik: `/newbot`

### Step 2: Kasih Nama Bot

BotFather bakal tanya 2 hal:

**1. Display Name** (nama yang keliatan):
```
Contoh: Instagram Auto Bot
```

**2. Username** (harus unik & akhiran "bot"):
```
Contoh: myinstagramauto_bot
```

### Step 3: Simpan Token

BotFather bakal kasih **token** kayak gini:
```
123456789:ABCdefGHIjklMNOpqrSTUvwxYZ1234567890
```

**⚠️ SIMPAN INI! LU BUTUH NANTI!**

### Step 4: Dapetin User ID Lu

1. Chat `@userinfobot`
2. Bot langsung kasih ID lu (contoh: `123456789`)
3. **Simpan ini juga!**

---

## 2️⃣ SETUP DI LAPTOP/TERMUX

### 🪟 **WINDOWS:**

#### A. Install Software

**1. Node.js:**
- Download: https://nodejs.org
- Install (pilih yang "LTS")
- Restart PowerShell setelah install

**2. Python:**
- Download: https://python.org
- Install
- **✅ CENTANG "Add Python to PATH"** ← PENTING!
- Restart PowerShell

#### B. Setup Bot

```powershell
# 1. Download project (extract ke folder)
cd C:\Users\NAMALUU\Downloads\project

# 2. Setup otomatis (install semua)
.\setup.ps1

# 3. Edit config (WAJIB!)
notepad telegram-bot\.env
```

**Edit 3 baris ini di `.env`:**
```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHI...    ← Token dari BotFather
BOT_USERNAME=myinstagramauto_bot             ← Username bot lu
ADMIN_TELEGRAM_IDS=123456789                 ← User ID dari @userinfobot
```

**Save & Close** (Ctrl+S, Alt+F4)

```powershell
# 4. Start bot!
.\start.ps1
```

#### C. Verify Bot Jalan

1. **Check API**: Buka browser → http://localhost:8000/health
   - Harusnya muncul: `{"status":"healthy"}`

2. **Test Bot**:
   - Buka Telegram
   - Cari bot lu (username yang tadi lu bikin)
   - Ketik: `/start`
   - Bot harusnya reply!

---

### 📱 **TERMUX (Android):**

#### A. Install Termux

1. Download **Termux** dari F-Droid (bukan dari Play Store!)
   - Link: https://f-droid.org/en/packages/com.termux/

2. Buka Termux, ketik:
```bash
# Update packages
pkg update && pkg upgrade -y

# Install dependencies
pkg install nodejs python git -y
```

#### B. Download Project

```bash
# Pindah ke storage (optional)
cd /sdcard/Download

# Atau tetap di home
cd ~

# Upload project ke Termux (via file manager atau git)
# Asumsi project ada di: ~/project
cd project
```

#### C. Setup Bot

```bash
# 1. Setup otomatis
bash setup.sh

# 2. Edit config (WAJIB!)
nano telegram-bot/.env
```

**Edit 3 baris ini:**
```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHI...    ← Token dari BotFather
BOT_USERNAME=myinstagramauto_bot             ← Username bot lu
ADMIN_TELEGRAM_IDS=123456789                 ← User ID lu
```

**Save:**
- Ctrl+X
- Tekan Y
- Enter

```bash
# 3. Start bot!
bash start.sh
```

#### D. Tips Termux

**Biar Bot Ga Mati Pas Layar Sleep:**

1. **Install Termux:Boot** (dari F-Droid)
2. **Atau pake screen:**
```bash
# Install screen
pkg install screen -y

# Start bot di screen session
screen -S bot
bash start.sh

# Lepas screen (bot tetap jalan):
# Tekan: Ctrl+A, lalu D

# Kembali lagi:
screen -r bot
```

3. **Matiin battery optimization** untuk Termux di Android Settings

---

### 🐧 **LINUX (Ubuntu/Debian):**

```bash
# 1. Install dependencies
sudo apt update
sudo apt install nodejs npm python3 python3-pip -y

# 2. Setup
cd project
bash setup.sh

# 3. Edit config
nano telegram-bot/.env
# (edit 3 baris: TOKEN, USERNAME, ADMIN_IDS)

# 4. Start
bash start.sh
```

---

## 3️⃣ FITUR & CARA PENGGUNAAN

### 📱 **1. MANAJEMEN AKUN INSTAGRAM**

#### Tambah Akun
```
/start → 📱 Accounts → ➕ Add Account
```

**Format:**
```
Username: instagramlu
Password: passwordlu
```

**⚠️ PENTING:**
- Password di-encrypt & aman
- Kalau IG minta challenge (verifikasi), buka IG app dulu
- Support **2FA** (two-factor authentication)

**Limits:**
- **Trial**: 1 akun
- **Basic**: 3 akun
- **Pro**: 10 akun
- **Enterprise**: Unlimited

---

### 🤖 **2. AUTO FOLLOW/UNFOLLOW**

#### Cara Aktifkan:
```
/start → 🤖 Automation → Auto Follow
```

**Setup:**
1. Pilih akun Instagram
2. Masukkan target username (yang follower-nya mau lu ambil)
3. Set jumlah follow (max sesuai limit harian)
4. Start!

**Contoh Use Case:**
- Target: `@influencer_fitnes`
- Bot bakal follow follower-nya dia (orang yang interest fitness)
- Auto unfollow yang ga follow balik setelah 3 hari

**Limits Harian:**
| Action | Trial | Basic | Pro | Enterprise |
|--------|-------|-------|-----|------------|
| Follow | 50 | 200 | 500 | 1000 |
| Unfollow | 50 | 200 | 500 | 1000 |

**⚠️ Safety:**
- **Warmup Mode**: Akun baru (< 7 hari) limit dikurangi 70%
  - Contoh: Follow max 200 → jadi 60 di hari 1-7
- **Delay antar action**: 30-120 detik (random, biar natural)
- **Auto pause** kalau Instagram rate limit

---

### ❤️ **3. AUTO LIKE & COMMENT**

#### Cara Aktifkan:
```
/start → 🤖 Automation → Auto Like
```

**Setup:**
1. Pilih target:
   - **Hashtag** (contoh: `#fitness`)
   - **Location** (contoh: `Jakarta`)
   - **User posts** (like post user tertentu)
2. Set jumlah like per hari
3. (Optional) Tambah auto comment

**Template Comment:**
```
Setup di: /start → ⚙️ Settings → Comment Templates

Contoh:
- Nice post! 🔥
- Amazing content! 👏
- Love this! ❤️
```

**Limits Harian:**
| Action | Trial | Basic | Pro | Enterprise |
|--------|-------|-------|-----|------------|
| Likes | 100 | 500 | 1000 | 2000 |
| Comments | 20 | 100 | 200 | 500 |

**⚠️ Tips:**
- Jangan pake comment generik (bisa kena spam flag)
- Variasi emoji & kata-kata
- Like + Comment = lebih natural

---

### 💬 **4. DM AUTOMATION**

#### Cara Aktifkan:
```
/start → 🤖 Automation → Auto DM
```

**Use Case:**
1. **Welcome DM**: Auto DM ke new follower
2. **Lead Generation**: DM ke follower dari kompetitor
3. **Re-engagement**: DM ke follower lama yang ga aktif

**Setup:**
```
1. Pilih trigger:
   - New followers
   - Target user's followers
   - Custom list

2. Buat template:
   Hi {name}! 👋
   Thanks for following!
   Check out our latest product: {link}

3. Set delay (jarak antar DM): 60-300 detik
```

**Variables:**
- `{name}` → Username mereka
- `{link}` → Link lu
- `{account}` → Nama akun IG lu

**Limits Harian:**
| Plan | Max DM/day |
|------|------------|
| Trial | 10 |
| Basic | 50 |
| Pro | 150 |
| Enterprise | 500 |

**⚠️ HATI-HATI:**
- Jangan spam!
- DM rate limit paling ketat di IG
- Kena spam flag = akun bisa kena ban

---

### 👁️ **5. AUTO STORY VIEWER**

#### Cara Aktifkan:
```
/start → 🤖 Automation → Story Viewer
```

**Cara Kerja:**
- Bot auto view story dari:
  - Followers lu
  - Target user's followers
  - Hashtag/location

**Why?** Orang liat lu view story → mereka notice lu → tingkat engagement naik

**Limits:**
| Plan | Stories/day |
|------|-------------|
| Trial | 50 |
| Basic | 300 |
| Pro | 800 |
| Enterprise | 2000 |

---

### 📊 **6. ANALYTICS & REPORTS**

#### Lihat Statistik:
```
/start → 📊 Analytics
```

**Data yang dilacak:**
- Follower growth (pertumbuhan follower)
- Engagement rate (like, comment, share)
- Best posting time (waktu terbaik post)
- Hashtag performance
- Action history (semua action bot)

**Export Report:**
- Daily report (via bot, otomatis jam 10 pagi)
- Weekly summary
- Export CSV/PDF (Pro & Enterprise)

---

## 4️⃣ LIMIT & KEAMANAN

### 🛡️ **Kenapa Ada Limit?**

Instagram punya **anti-spam system**. Kalau lu:
- Follow terlalu banyak dalam waktu singkat
- Like/comment terlalu cepat
- DM spam

→ **Akun lu bisa kena:**
- ⚠️ Shadowban (post ga keliatan di hashtag)
- ⏸️ Action block (ga bisa follow/like 24-48 jam)
- ❌ Permanent ban

**Bot ini punya safety features:**

### 🔒 **1. Warmup Mode**

**Untuk akun baru** (< 7 hari di bot):
- Limit otomatis dikurangi 70%
- Delay antar action lebih lama
- Gradual increase tiap hari

**Contoh:**
- Hari 1: 60 follows (30% dari 200)
- Hari 2: 80 follows
- Hari 3: 100 follows
- ...
- Hari 7+: 200 follows (full limit)

### ⏱️ **2. Smart Delays**

Bot ga langsung action, ada delay random:

| Action | Min Delay | Max Delay |
|--------|-----------|-----------|
| Follow/Unfollow | 60s | 180s |
| Like | 30s | 90s |
| Comment | 120s | 300s |
| DM | 180s | 600s |

**Kenapa random?** Biar keliatan kayak manusia beneran!

### 📊 **3. Real-time Monitoring**

Bot auto track:
- Action count per jam/hari
- Error rate (challenge, rate limit)
- Auto pause kalau detect masalah

**Check limit lu:**
```
/start → 📊 Analytics → Daily Limits
```

Output:
```
📊 Today's Usage (Account: @yourname)

✅ Follows: 45/200 (155 remaining)
✅ Likes: 120/500 (380 remaining)
⚠️ DMs: 48/50 (2 remaining) ← Hampir limit!
✅ Story Views: 30/300 (270 remaining)

Next reset: 12 hours
```

### 🚨 **4. Error Handling**

Bot auto handle:

**Challenge Required:**
```
⚠️ Instagram wants to verify your account.
Please login to Instagram app and complete verification.
Bot will retry in 1 hour.
```

**Rate Limit:**
```
⏸️ Hit Instagram rate limit.
Auto-paused for 30 minutes.
```

**Login Issue:**
```
❌ Session expired. Please re-login.
/start → 📱 Accounts → Re-login
```

---

## 5️⃣ FAQ & TROUBLESHOOTING

### ❓ **PERTANYAAN UMUM**

#### Q: Aman ga sih pake bot? Akun ga ke-ban?
**A:** Aman kalau ikutin limit & safety rules:
- ✅ Jangan maksain limit harian
- ✅ Pake warmup mode untuk akun baru
- ✅ Variasi template DM/comment
- ❌ Jangan follow/unfollow user yang sama berkali-kali
- ❌ Jangan pake akun utama buat testing

**Tips:** Bikin akun baru dulu untuk testing!

---

#### Q: Kenapa follow/like gua ga banyak?
**A:** Kemungkinan:
1. **Warmup mode aktif** → cek di Analytics
2. **Limit harian tercapai** → tunggu reset (midnight)
3. **Akun kena action block** → bot auto pause
4. **Target user private/restricted**

**Solusi:** Check logs di bot: `/logs`

---

#### Q: Bot tiba-tiba mati/ga respon?
**A:** Cek:

**Windows:**
```powershell
# Lihat logs
Get-Content logs\telegram-bot.log -Tail 50
Get-Content logs\instagram-service.log -Tail 50
```

**Linux/Termux:**
```bash
# Lihat logs
tail -f logs/telegram-bot.log
tail -f logs/instagram-service.log
```

**Common issues:**
- ❌ Internet putus → restart bot
- ❌ IG session expired → re-login di bot
- ❌ API service down → restart service

---

#### Q: Bisa jalan di VPS ga?
**A:** Bisa! Malah recommended!

**Rekomendasi VPS:**
- **DigitalOcean** ($5/month)
- **Vultr** ($5/month)
- **Contabo** ($4/month)
- **AWS/GCP** (pake free tier)

**Setup di VPS:**
```bash
# Clone project
git clone your-repo-url
cd project

# Setup
bash setup.sh

# Edit .env
nano telegram-bot/.env

# Start dengan PM2 (auto-restart)
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

#### Q: Cara upgrade subscription?
**A:**
```
/start → 💳 Subscription → 💎 Upgrade Plan
```

**Metode payment:**
1. **Bank Transfer** (BCA, Mandiri, dll)
   - Transfer → kirim bukti → tunggu verifikasi (< 24 jam)

2. **Midtrans** (Credit Card / GoPay / OVO)
   - Instant activation!

---

#### Q: Akun IG gua kena challenge, gimana?
**A:**
```
1. Buka Instagram app di HP
2. Login dengan akun yang kena challenge
3. Ikutin instruksi verifikasi (biasanya:)
   - Verifikasi email/phone
   - Atau selfie verification
4. Setelah selesai, tunggu 1 jam
5. Di bot: /start → 📱 Accounts → Re-login
```

---

#### Q: Bot error "Cannot find module"?
**A:**
```bash
# Reinstall dependencies
cd telegram-bot
npm install

cd ../instagram-service
pip3 install -r requirements.txt
```

---

#### Q: Python/Node ga ke-detect di Windows?
**A:** Restart PowerShell setelah install!

Kalau masih error:
```powershell
# Check instalasi
node -v
python --version

# Kalau ga ada, tambah ke PATH manually:
# 1. Search "Environment Variables" di Windows
# 2. Edit "Path"
# 3. Add:
#    C:\Program Files\nodejs\
#    C:\Python311\  (sesuaikan versi Python lu)
```

---

### 🆘 **MASIH ERROR?**

**Hubungi Support:**
1. Screenshot error nya
2. Share file log:
   - `logs/telegram-bot.log`
   - `logs/instagram-service.log`
3. Bilang di step mana stuck

**Contact:**
- Telegram: @your_support_username
- Email: support@yourdomain.com

---

## 📞 BUTUH BANTUAN LEBIH?

**Dokumentasi:**
- `README_SIMPLE.md` → Quick start guide
- `SETUP_WINDOWS.md` → Windows specific
- File ini → Complete guide

**Video Tutorial** (coming soon):
- Setup di Windows
- Setup di Termux
- Cara pake semua fitur

---

## 🎉 SELAMAT AUTOMASI!

Setup udah kelar? Bot udah jalan? **CONGRATS!** 🎊

**Next Steps:**
1. Tambah akun Instagram pertama
2. Setup auto follow dari kompetitor
3. Bikin DM template untuk welcome message
4. Monitor analytics tiap hari
5. Adjust strategy berdasarkan hasil!

**Tips Pro:**
- Jangan rush! Start slow, increase gradually
- Test fitur pake akun dummy dulu
- Monitor analytics tiap hari
- Variasi targeting (jangan fokus 1 user terus)

**GUA BANTUIN SAMPE SUKSES!** 🔥🚀
