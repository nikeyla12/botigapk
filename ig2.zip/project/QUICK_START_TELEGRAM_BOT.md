# 🚀 Quick Start - Instagram Automation Telegram Bot

## 5 Menit Setup!

### Step 1: Install Dependencies

```bash
# Install Node.js, Python, Redis
sudo apt update
sudo apt install -y nodejs npm python3 python3-pip redis-server
sudo npm install -g pm2

# Install project dependencies
cd telegram-bot && npm install
cd ../instagram-service && pip3 install -r requirements.txt
```

### Step 2: Create Telegram Bot

1. Buka [@BotFather](https://t.me/botfather) di Telegram
2. Kirim `/newbot`
3. Ikuti instruksi
4. **Simpan BOT_TOKEN yang diberikan**

### Step 3: Setup Environment

**Telegram Bot (.env):**
```bash
cd telegram-bot
cp .env.example .env
```

Edit `.env` dengan nilai ini:
```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
INSTAGRAM_SERVICE_URL=http://localhost:8000
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
REDIS_HOST=localhost
ADMIN_TELEGRAM_IDS=your_telegram_id
```

**Instagram Service (.env):**
```bash
cd ../instagram-service
cp .env.example .env
```

Edit dengan Supabase credentials yang sama.

### Step 4: Start Services

```bash
# Dari root project
pm2 start ecosystem.config.js

# Cek status
pm2 status
```

### Step 5: Test Bot

1. Buka Telegram
2. Cari bot kamu
3. Kirim `/start`
4. Klik "Add Account"
5. Masukkan username & password Instagram
6. ✅ Done!

---

## 🎮 Cara Pakai

### Tambah Akun Instagram
```
/start → My Accounts → Add Account
```

### Setup Automasi
```
/start → Automation → Pilih fitur
```

### Lihat Analytics
```
/analytics
```

### Payment/Langganan
```
/payment
```

---

## 💡 Tips Cepat

1. **Warmup Mode:** Otomatis aktif 7 hari pertama untuk akun baru
2. **Daily Limits:** Cek dengan `/limits` untuk lihat sisa aksi hari ini
3. **Safety First:** Jangan over-automate, follow limits
4. **Monitor:** Cek logs dengan `pm2 logs`

---

## ⚠️ Troubleshooting Cepat

**Bot tidak respon?**
```bash
pm2 restart telegram-bot
pm2 logs telegram-bot
```

**Instagram login gagal?**
- Login manual di HP Instagram kamu
- Selesaikan challenge kalau ada
- Coba lagi di bot

**Actions tidak jalan?**
- Cek daily limits
- Pastikan akun status "Active"
- Restart: `pm2 restart all`

---

## 📚 Dokumentasi Lengkap

Lihat `TELEGRAM_BOT_COMPLETE_SETUP.md` untuk:
- Penjelasan lengkap semua fitur
- Konfigurasi advanced
- Admin commands
- Payment integration
- Dan banyak lagi!

---

**Selamat menggunakan! 🎉**
