# 🔥 CARA SETUP LENGKAP - INSTAGRAM AUTOMATION BOT

## ⚠️ PENTING: CARA DOWNLOAD YANG BENAR

**MASALAH:** File yang lu download cuma dapet **files root** aja (MD files), **TAPI FOLDER `telegram-bot/` dan `instagram-service/` GAADA!**

**SOLUSI:** Lu butuh **DOWNLOAD PROJECT LENGKAP**!

---

## 📥 CARA DOWNLOAD PROJECT LENGKAP

### Method 1: Dari Bolt/Cline (Recommended)

1. Di interface Bolt/Cline, cari tombol **"Download Project"** atau **"Export"**
2. Pastikan **centang semua options**:
   - ✅ Include source files
   - ✅ Include all folders
   - ✅ Include configuration files
3. Download ZIP nya
4. Extract semua

**HARUSNYA LU DAPET:**
```
project/
├── telegram-bot/           ← FOLDER INI HARUS ADA!
│   ├── src/
│   │   ├── index.js
│   │   ├── commands/
│   │   ├── handlers/
│   │   ├── services/
│   │   └── ... (14 files)
│   ├── package.json
│   └── .env.example
│
├── instagram-service/      ← FOLDER INI JUGA HARUS ADA!
│   ├── main.py
│   ├── api/
│   ├── instagram/
│   ├── config/
│   └── ... (20 files)
│
├── ecosystem.config.js
├── install.sh
└── *.md files
```

---

### Method 2: Manual Download via Git (Kalau ada)

```bash
git clone <your-repo-url>
cd project
```

---

### Method 3: Bikin Manual (Kalau Terpaksa)

Kalau download tetep gak bisa, **GUA KASIH SEMUA CODE NYA DI SINI**:

#### 1. Buat File Structure

```bash
mkdir -p telegram-bot/src/{commands,handlers,keyboards,middlewares,scenes,services,utils,workers,config,database,locales}
mkdir -p instagram-service/{api/routes,config,database,instagram,safety}
```

#### 2. Copy File-File Penting

Files yang **WAJIB ADA** (gua kasih content nya di bawah):

**Telegram Bot (14 files):**
1. `telegram-bot/src/index.js`
2. `telegram-bot/src/commands/index.js`
3. `telegram-bot/src/handlers/callbacks.js`
4. `telegram-bot/src/handlers/admin.js`
5. `telegram-bot/src/keyboards/main.js`
6. `telegram-bot/src/middlewares/index.js`
7. `telegram-bot/src/scenes/index.js`
8. `telegram-bot/src/services/instagram-api.js`
9. `telegram-bot/src/services/payment.js`
10. `telegram-bot/src/config/constants.js`
11. `telegram-bot/src/database/client.js`
12. `telegram-bot/src/utils/logger.js`
13. `telegram-bot/src/utils/i18n.js`
14. `telegram-bot/src/workers/queue-worker.js`

**Instagram Service (20 files):**
1. `instagram-service/main.py`
2. `instagram-service/config/settings.py`
3. `instagram-service/config/logger.py`
4. `instagram-service/database/client.py`
5. `instagram-service/instagram/client.py`
6. `instagram-service/safety/limits.py`
7. `instagram-service/safety/behavior.py`
8. `instagram-service/api/routes/health.py`
9. `instagram-service/api/routes/auth.py`
10. `instagram-service/api/routes/actions.py`
11. `instagram-service/api/routes/dm.py`
12. `instagram-service/api/routes/story.py`
13. `instagram-service/api/routes/scraper.py`
14. `instagram-service/api/routes/upload.py`
15. `instagram-service/api/routes/profile.py`
16. Dan `__init__.py` files

---

## 🚀 SETUP SETELAH DOWNLOAD LENGKAP

### Step 1: Install Dependencies

```bash
# Telegram Bot
cd telegram-bot
npm install
cd ..

# Instagram Service
cd instagram-service
pip3 install -r requirements.txt
cd ..
```

### Step 2: Setup Environment

**telegram-bot/.env:**
```env
TELEGRAM_BOT_TOKEN=your_bot_token
INSTAGRAM_SERVICE_URL=http://localhost:8000
SUPABASE_URL=https://hpejxpxnvopmqeefabib.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=your_key
REDIS_HOST=localhost
ADMIN_TELEGRAM_IDS=your_id
```

**instagram-service/.env:**
```env
API_PORT=8000
SUPABASE_URL=https://hpejxpxnvopmqeefabib.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=your_key
MAX_FOLLOWS_PER_DAY=200
WARMUP_ENABLED=true
```

### Step 3: Start Services

```bash
pm2 start ecosystem.config.js
pm2 status
pm2 logs
```

---

## ✅ VERIFIKASI

Cek kalau semua folder ada:

```bash
ls -la telegram-bot/src/
# Harus ada: commands/, handlers/, services/, dll

ls -la instagram-service/
# Harus ada: main.py, api/, instagram/, dll
```

---

## 🆘 KALAU MASIH GAGAL

**1. Cek file count:**
```bash
find telegram-bot -name "*.js" | wc -l  # Harus 14+
find instagram-service -name "*.py" | wc -l  # Harus 20+
```

**2. Manual create:**
Kalau lu butuh, **GUA BISA KASIH CONTENT SEMUA FILES SATU-SATU**!

**3. Alternative:**
- Download dari repo Git (kalau ada)
- Request full project archive
- Manual copy-paste dari dokumentasi

---

## 📞 NEED HELP?

Kalau masih bingung:
1. Screenshot folder structure lu
2. Screenshot error messages
3. Kasih tau gua step mana yang stuck

**GUA BANTUIN SAMPAI JALAN!** 🔥
