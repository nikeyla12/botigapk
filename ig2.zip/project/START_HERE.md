# 🚀 START HERE - SUPER SIMPLE!

## 🎯 3 LANGKAH DOANG!

### 1️⃣ **BUAT BOT TELEGRAM**

1. Chat `@BotFather` di Telegram
2. Ketik: `/newbot`
3. Kasih nama bot (contoh: `My Instagram Bot`)
4. Kasih username (contoh: `myinstagram_bot`)
5. **SAVE TOKEN** yang dikasih! (contoh: `123456:ABCdef...`)

**Dapet User ID lu:**
- Chat `@userinfobot`
- Simpan ID nya (contoh: `123456789`)

---

### 2️⃣ **SETUP FILES**

#### A. Edit Config

**File: `telegram-bot/.env`**

Cari & ganti 3 baris ini:
```env
TELEGRAM_BOT_TOKEN=123456:ABCdef...     ← Paste token dari BotFather
BOT_USERNAME=myinstagram_bot            ← Username bot lu
ADMIN_TELEGRAM_IDS=123456789            ← User ID lu dari @userinfobot
```

**File: `instagram-service/.env`**

Udah auto-filled, **ga perlu di-edit!**

---

### 3️⃣ **JALANIN BOT**

#### **Windows (PowerShell):**

```powershell
# Install dependencies (1x aja pas pertama kali)
cd telegram-bot
npm install
cd ..

cd instagram-service
pip install -r requirements.txt
cd ..

# Jalanin bot (2 terminal/tab)
# Terminal 1:
cd instagram-service
python main.py

# Terminal 2:
cd telegram-bot
node src/index.js
```

#### **Linux / Mac:**

```bash
# Install dependencies (1x aja pas pertama kali)
cd telegram-bot
npm install
cd ..

cd instagram-service
pip3 install -r requirements.txt
cd ..

# Jalanin bot (2 terminal/tab)
# Terminal 1:
cd instagram-service
python3 main.py

# Terminal 2:
cd telegram-bot
node src/index.js
```

#### **Termux (Android):**

```bash
# Install packages dulu (1x aja)
pkg install nodejs python git -y

# Install dependencies
cd telegram-bot
npm install
cd ..

cd instagram-service
pip install -r requirements.txt
cd ..

# Jalanin bot (pake screen biar ga mati)
screen -S bot

# Terminal 1:
cd instagram-service
python main.py

# Buka tab baru (Ctrl+A lalu C)
cd telegram-bot
node src/index.js

# Lepas screen: Ctrl+A lalu D
# Balik lagi: screen -r bot
```

---

## ✅ **VERIFY BOT JALAN**

### 1. Check API Service:
- Buka browser → `http://localhost:8000/health`
- Harusnya muncul: `{"status":"healthy"}`

### 2. Test Bot:
- Buka Telegram
- Cari bot lu (username yang tadi)
- Ketik: `/start`
- Bot reply = **SUCCESS!** 🎉

---

## 🔥 **ATAU PAKE SCRIPT AUTO** (optional)

Kalau mau lebih simple, pake script yang udah gua bikin:

### **Windows:**
```powershell
.\setup.ps1    # Install semua
.\start.ps1    # Start bot
.\stop.ps1     # Stop bot
```

### **Linux/Mac/Termux:**
```bash
bash setup.sh   # Install semua
bash start.sh   # Start bot
# Stop: Ctrl+C
```

---

## 🆘 **TROUBLESHOOTING**

### ❌ "Cannot find module"
```bash
cd telegram-bot
npm install
```

### ❌ "No module named 'fastapi'"
```bash
cd instagram-service
pip install -r requirements.txt
# atau pip3 install -r requirements.txt
```

### ❌ "node: command not found"
**Install Node.js:**
- **Windows**: https://nodejs.org (download & install)
- **Linux**: `sudo apt install nodejs npm`
- **Termux**: `pkg install nodejs`

### ❌ "python: command not found"
**Install Python:**
- **Windows**: https://python.org (centang "Add to PATH"!)
- **Linux**: `sudo apt install python3 python3-pip`
- **Termux**: `pkg install python`

### ❌ Bot ga respon?
1. Cek token bener di `.env`
2. Cek kedua service jalan (Python + Node)
3. Cek internet
4. Restart bot

---

## 📚 **DOKUMENTASI LENGKAP**

Baca ini untuk penjelasan detail semua fitur:
- **PANDUAN_LENGKAP.md** - Complete guide (fitur, limits, safety)
- **README_SIMPLE.md** - Platform-specific setup

---

## 🎮 **COMMAND BOT**

Di Telegram bot:
- `/start` - Main menu
- `/help` - Bantuan
- `/features` - Lihat semua fitur & limits
- `/limits` - Check usage hari ini
- `/guide` - Tutorial lengkap

---

## 🎉 **DONE!**

Bot udah jalan? **SELAMAT!** 🔥

**Next:**
1. Tambah akun Instagram: `/start` → 📱 Accounts
2. Setup automation: `/start` → 🤖 Automation
3. Monitor stats: `/start` → 📊 Analytics

**HAPPY AUTOMATING!** 🚀
